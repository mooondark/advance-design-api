from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .close_project.close_project_request_builder import CloseProjectRequestBuilder
    from .close_session.close_session_request_builder import CloseSessionRequestBuilder
    from .new_project.new_project_request_builder import NewProjectRequestBuilder
    from .open_project.open_project_request_builder import OpenProjectRequestBuilder

class ManagementRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/management
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ManagementRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/management", path_parameters)
    
    @property
    def close_project(self) -> CloseProjectRequestBuilder:
        """
        The CloseProject property
        """
        from .close_project.close_project_request_builder import CloseProjectRequestBuilder

        return CloseProjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def close_session(self) -> CloseSessionRequestBuilder:
        """
        The CloseSession property
        """
        from .close_session.close_session_request_builder import CloseSessionRequestBuilder

        return CloseSessionRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def new_project(self) -> NewProjectRequestBuilder:
        """
        The NewProject property
        """
        from .new_project.new_project_request_builder import NewProjectRequestBuilder

        return NewProjectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def open_project(self) -> OpenProjectRequestBuilder:
        """
        The OpenProject property
        """
        from .open_project.open_project_request_builder import OpenProjectRequestBuilder

        return OpenProjectRequestBuilder(self.request_adapter, self.path_parameters)
    

