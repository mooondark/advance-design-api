from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .create_section.create_section_request_builder import CreateSectionRequestBuilder
    from .get_list_sections.get_list_sections_request_builder import GetListSectionsRequestBuilder
    from .get_sections.get_sections_request_builder import GetSectionsRequestBuilder

class SectionsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/sections
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new SectionsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/sections", path_parameters)
    
    @property
    def create_section(self) -> CreateSectionRequestBuilder:
        """
        The CreateSection property
        """
        from .create_section.create_section_request_builder import CreateSectionRequestBuilder

        return CreateSectionRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_list_sections(self) -> GetListSectionsRequestBuilder:
        """
        The GetListSections property
        """
        from .get_list_sections.get_list_sections_request_builder import GetListSectionsRequestBuilder

        return GetListSectionsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def get_sections(self) -> GetSectionsRequestBuilder:
        """
        The GetSections property
        """
        from .get_sections.get_sections_request_builder import GetSectionsRequestBuilder

        return GetSectionsRequestBuilder(self.request_adapter, self.path_parameters)
    

