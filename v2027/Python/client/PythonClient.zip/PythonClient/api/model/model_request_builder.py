from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .actions.actions_request_builder import ActionsRequestBuilder
    from .analysis.analysis_request_builder import AnalysisRequestBuilder
    from .combinations.combinations_request_builder import CombinationsRequestBuilder
    from .elements.elements_request_builder import ElementsRequestBuilder
    from .management.management_request_builder import ManagementRequestBuilder
    from .materials.materials_request_builder import MaterialsRequestBuilder
    from .sections.sections_request_builder import SectionsRequestBuilder

class ModelRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ModelRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model", path_parameters)
    
    @property
    def actions(self) -> ActionsRequestBuilder:
        """
        The actions property
        """
        from .actions.actions_request_builder import ActionsRequestBuilder

        return ActionsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def analysis(self) -> AnalysisRequestBuilder:
        """
        The analysis property
        """
        from .analysis.analysis_request_builder import AnalysisRequestBuilder

        return AnalysisRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def combinations(self) -> CombinationsRequestBuilder:
        """
        The combinations property
        """
        from .combinations.combinations_request_builder import CombinationsRequestBuilder

        return CombinationsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def elements(self) -> ElementsRequestBuilder:
        """
        The elements property
        """
        from .elements.elements_request_builder import ElementsRequestBuilder

        return ElementsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def management(self) -> ManagementRequestBuilder:
        """
        The management property
        """
        from .management.management_request_builder import ManagementRequestBuilder

        return ManagementRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def materials(self) -> MaterialsRequestBuilder:
        """
        The materials property
        """
        from .materials.materials_request_builder import MaterialsRequestBuilder

        return MaterialsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def sections(self) -> SectionsRequestBuilder:
        """
        The sections property
        """
        from .sections.sections_request_builder import SectionsRequestBuilder

        return SectionsRequestBuilder(self.request_adapter, self.path_parameters)
    

