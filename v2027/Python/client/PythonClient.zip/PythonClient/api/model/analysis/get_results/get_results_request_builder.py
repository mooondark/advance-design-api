from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.res_base_list_api_response import ResBaseListApiResponse

class GetResultsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/Model/analysis/GetResults
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new GetResultsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/Model/analysis/GetResults{?IDAnalysisCase*,eResType*}", path_parameters)
    
    async def post(self,body: list[int], request_configuration: Optional[RequestConfiguration[GetResultsRequestBuilderPostQueryParameters]] = None) -> Optional[ResBaseListApiResponse]:
        """
        Get finite element results for specified result type and element EIDs (analysis model)
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ResBaseListApiResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.res_base_list_api_response import ResBaseListApiResponse

        return await self.request_adapter.send_async(request_info, ResBaseListApiResponse, None)
    
    def to_post_request_information(self,body: list[int], request_configuration: Optional[RequestConfiguration[GetResultsRequestBuilderPostQueryParameters]] = None) -> RequestInformation:
        """
        Get finite element results for specified result type and element EIDs (analysis model)
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        request_info.set_content_from_scalar(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> GetResultsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: GetResultsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return GetResultsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class GetResultsRequestBuilderPostQueryParameters():
        """
        Get finite element results for specified result type and element EIDs (analysis model)
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "e_res_type":
                return "eResType"
            if original_name == "i_d_analysis_case":
                return "IDAnalysisCase"
            return original_name
        
        # Analysis result type<p>Possible values:</p><ul><li><b>0 - displacement</b>: Analysis displacement</li><li><b>1 - forces</b>: Analysis stresses</li><li><b>2 - stresses</b>: Analysis efforts</li><li><b>4 - resultantforces</b>: Analysis resultant forces</li></ul>
        e_res_type: Optional[str] = None

        i_d_analysis_case: Optional[int] = None

    
    @dataclass
    class GetResultsRequestBuilderPostRequestConfiguration(RequestConfiguration[GetResultsRequestBuilderPostQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

