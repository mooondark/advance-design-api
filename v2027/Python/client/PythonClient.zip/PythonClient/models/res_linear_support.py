from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_base import ResBase
    from .res_node import ResNode

from .res_base import ResBase

@dataclass
class ResLinearSupport(ResBase, AdditionalDataHolder, Parsable):
    """
    Represents the results of a linear support analysis, including the collection of associated nodes and thecalculated resultant forces and moments.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Gets or sets the collection of resource nodes associated with this element.
    res_nodes: Optional[list[ResNode]] = None
    # The torsorsFx property
    torsors_fx: Optional[float] = None
    # The torsorsFy property
    torsors_fy: Optional[float] = None
    # The torsorsFz property
    torsors_fz: Optional[float] = None
    # The torsorsMx property
    torsors_mx: Optional[float] = None
    # The torsorsMy property
    torsors_my: Optional[float] = None
    # The torsorsMz property
    torsors_mz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResLinearSupport:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResLinearSupport
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResLinearSupport()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_base import ResBase
        from .res_node import ResNode

        from .res_base import ResBase
        from .res_node import ResNode

        fields: dict[str, Callable[[Any], None]] = {
            "resNodes": lambda n : setattr(self, 'res_nodes', n.get_collection_of_object_values(ResNode)),
            "torsorsFx": lambda n : setattr(self, 'torsors_fx', n.get_float_value()),
            "torsorsFy": lambda n : setattr(self, 'torsors_fy', n.get_float_value()),
            "torsorsFz": lambda n : setattr(self, 'torsors_fz', n.get_float_value()),
            "torsorsMx": lambda n : setattr(self, 'torsors_mx', n.get_float_value()),
            "torsorsMy": lambda n : setattr(self, 'torsors_my', n.get_float_value()),
            "torsorsMz": lambda n : setattr(self, 'torsors_mz', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_collection_of_object_values("resNodes", self.res_nodes)
        writer.write_float_value("torsorsFx", self.torsors_fx)
        writer.write_float_value("torsorsFy", self.torsors_fy)
        writer.write_float_value("torsorsFz", self.torsors_fz)
        writer.write_float_value("torsorsMx", self.torsors_mx)
        writer.write_float_value("torsorsMy", self.torsors_my)
        writer.write_float_value("torsorsMz", self.torsors_mz)
        writer.write_additional_data_value(self.additional_data)
    

