from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PushOverIncrementationConfig(Parsable):
    """
    Push over incrementation configuration
    """
    # First step lateral load typeePushOverLateralLoadPercentage = 0, ePushOverLateralLoadSeismBaseShearX = 1,    ePushOverLateralLoadSeismBaseShearY = 2,    ePushOverLateralLoadImposedValue = 3Default: Percentage (0)
    first_step_lateral_load: Optional[int] = None
    # Imposed value for first stepUnit: kNDefault: 0.0
    imposed_first_step_value: Optional[float] = None
    # Imposed force valueUnit: kNDefault: 0.0
    imposed_force_value: Optional[float] = None
    # Maximum total lateral load typeePushOverLateralLoadPercentage = 0, ePushOverLateralLoadSeismBaseShearX = 1,    ePushOverLateralLoadSeismBaseShearY = 2,    ePushOverLateralLoadImposedValue = 3 Default: Percentage (0)
    maximum_total_lateral_load: Optional[int] = None
    # Percentage value for first stepUnit: %Default: 30.0
    percentage_first_step: Optional[float] = None
    # Percentage value for maximum lateral loadUnit: %Default: 200.0
    percentage_value: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverIncrementationConfig:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverIncrementationConfig
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverIncrementationConfig()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "firstStepLateralLoad": lambda n : setattr(self, 'first_step_lateral_load', n.get_int_value()),
            "imposedFirstStepValue": lambda n : setattr(self, 'imposed_first_step_value', n.get_float_value()),
            "imposedForceValue": lambda n : setattr(self, 'imposed_force_value', n.get_float_value()),
            "maximumTotalLateralLoad": lambda n : setattr(self, 'maximum_total_lateral_load', n.get_int_value()),
            "percentageFirstStep": lambda n : setattr(self, 'percentage_first_step', n.get_float_value()),
            "percentageValue": lambda n : setattr(self, 'percentage_value', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("firstStepLateralLoad", self.first_step_lateral_load)
        writer.write_float_value("imposedFirstStepValue", self.imposed_first_step_value)
        writer.write_float_value("imposedForceValue", self.imposed_force_value)
        writer.write_int_value("maximumTotalLateralLoad", self.maximum_total_lateral_load)
        writer.write_float_value("percentageFirstStep", self.percentage_first_step)
        writer.write_float_value("percentageValue", self.percentage_value)
    

