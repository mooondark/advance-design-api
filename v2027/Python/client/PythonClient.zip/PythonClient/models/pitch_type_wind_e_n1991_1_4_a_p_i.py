from enum import Enum

class PitchType_Wind_EN1991_1_4_API(str, Enum):
    PITCH_TYPE_MONO = "PITCH_TYPE_MONO",
    PITCH_TYPE_DUO = "PITCH_TYPE_DUO",

