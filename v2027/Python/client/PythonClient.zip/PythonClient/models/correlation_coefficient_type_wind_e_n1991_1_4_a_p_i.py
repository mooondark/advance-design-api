from enum import Enum

class CorrelationCoefficientType_Wind_EN1991_1_4_API(str, Enum):
    CORREL_AUTO = "CORREL_AUTO",
    CORREL_IMPOSED = "CORREL_IMPOSED",

