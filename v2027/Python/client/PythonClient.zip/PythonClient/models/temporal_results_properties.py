from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class TemporalResultsProperties(Parsable):
    """
    Results extraction properties for temporal analysis
    """
    # List of selected points (comma-separated IDs)Only used when Selection = SELECTED_POINTSDefault: empty string
    points_list: Optional[str] = None
    # Selection mode for result points0 = ALL_POINTS1 = SELECTED_POINTSUnit: dimensionlessDefault: 0 (ALL_POINTS)
    selection: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TemporalResultsProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TemporalResultsProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TemporalResultsProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "pointsList": lambda n : setattr(self, 'points_list', n.get_str_value()),
            "selection": lambda n : setattr(self, 'selection', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("pointsList", self.points_list)
        writer.write_int_value("selection", self.selection)
    

