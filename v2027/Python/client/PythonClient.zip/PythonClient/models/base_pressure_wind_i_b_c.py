from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .exposure_category_wind_i_b_c_a_p_i import ExposureCategory_WindIBC_API
    from .risk_category_wind_i_b_c_a_p_i import RiskCategory_WindIBC_API

@dataclass
class BasePressureWindIBC(Parsable):
    """
    Base pressure parameters for Wind IBC/ASCE 7-22
    """
    from .exposure_category_wind_i_b_c_a_p_i import ExposureCategory_WindIBC_API

    # Exposure categoryUnit: -Default: WINDIBCWd2015_EXPOSURE_B
    exposure_category: Optional[ExposureCategory_WindIBC_API] = ExposureCategory_WindIBC_API("WINDIBCWd2015_EXPOSURE_B")
    from .risk_category_wind_i_b_c_a_p_i import RiskCategory_WindIBC_API

    # Risk categoryUnit: -Default: CLIMATIC_IBC2015_RISK_I
    risk_category: Optional[RiskCategory_WindIBC_API] = RiskCategory_WindIBC_API("CLIMATIC_IBC2015_RISK_I")
    # Gust effect factorUnit: -Default: 0.85
    d_gust: Optional[float] = None
    # Height of structure base considered from the groundUnit: lengthDefault: 0.0
    height_of_structure_base: Optional[float] = None
    # Directionality factor KdUnit: -Default: 0.85
    kd: Optional[float] = None
    # Ground elevation factor KeUnit: -Default: 1.0
    ke: Optional[float] = None
    # Topographic factor KztUnit: -Default: 1.0
    kzt: Optional[float] = None
    # Reduction factor RiUnit: -Default: 1.0
    ri: Optional[float] = None
    # Torsional load casesUnit: -Default: false
    torsional_load_cases: Optional[bool] = None
    # Basic wind speed VUnit: speedDefault: 67.0
    v: Optional[float] = None
    # Wind design methodUnit: -Default: 0 for chapter 28 ENVELOPPE_LOW_RISE_BUIILDING ; 1 for scaffolding
    wind_design: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> BasePressureWindIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: BasePressureWindIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return BasePressureWindIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .exposure_category_wind_i_b_c_a_p_i import ExposureCategory_WindIBC_API
        from .risk_category_wind_i_b_c_a_p_i import RiskCategory_WindIBC_API

        from .exposure_category_wind_i_b_c_a_p_i import ExposureCategory_WindIBC_API
        from .risk_category_wind_i_b_c_a_p_i import RiskCategory_WindIBC_API

        fields: dict[str, Callable[[Any], None]] = {
            "dGust": lambda n : setattr(self, 'd_gust', n.get_float_value()),
            "exposureCategory": lambda n : setattr(self, 'exposure_category', n.get_enum_value(ExposureCategory_WindIBC_API)),
            "heightOfStructureBase": lambda n : setattr(self, 'height_of_structure_base', n.get_float_value()),
            "kd": lambda n : setattr(self, 'kd', n.get_float_value()),
            "ke": lambda n : setattr(self, 'ke', n.get_float_value()),
            "kzt": lambda n : setattr(self, 'kzt', n.get_float_value()),
            "ri": lambda n : setattr(self, 'ri', n.get_float_value()),
            "riskCategory": lambda n : setattr(self, 'risk_category', n.get_enum_value(RiskCategory_WindIBC_API)),
            "torsionalLoadCases": lambda n : setattr(self, 'torsional_load_cases', n.get_bool_value()),
            "v": lambda n : setattr(self, 'v', n.get_float_value()),
            "windDesign": lambda n : setattr(self, 'wind_design', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("dGust", self.d_gust)
        writer.write_enum_value("exposureCategory", self.exposure_category)
        writer.write_float_value("heightOfStructureBase", self.height_of_structure_base)
        writer.write_float_value("kd", self.kd)
        writer.write_float_value("ke", self.ke)
        writer.write_float_value("kzt", self.kzt)
        writer.write_float_value("ri", self.ri)
        writer.write_enum_value("riskCategory", self.risk_category)
        writer.write_bool_value("torsionalLoadCases", self.torsional_load_cases)
        writer.write_float_value("v", self.v)
        writer.write_int_value("windDesign", self.wind_design)
    

