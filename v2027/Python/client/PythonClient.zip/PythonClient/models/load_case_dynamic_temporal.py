from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .equivalent_static_case_properties import EquivalentStaticCaseProperties
    from .function import Function
    from .function_harmonique import FunctionHarmonique
    from .load_case import LoadCase
    from .temporal_results_properties import TemporalResultsProperties
    from .temporal_variation_properties import TemporalVariationProperties

from .load_case import LoadCase

@dataclass
class LoadCase_DynamicTemporal(LoadCase, AdditionalDataHolder, Parsable):
    """
    Dynamic temporal load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Function data referenceThis property holds the function definition for temporal loading.Set to null to allow engine defaults
    function: Optional[Function] = None
    # Harmonic functions for temporal analysisSet to null to allow engine defaults
    harmoniques: Optional[list[FunctionHarmonique]] = None
    # Results extraction propertiesSet to null to allow engine defaults
    results_properties: Optional[TemporalResultsProperties] = None
    # Time interval definition propertiesSet to null to allow engine defaults
    time_interval_properties: Optional[EquivalentStaticCaseProperties] = None
    # Temporal load variation propertiesSet to null to allow engine defaults
    variation_properties: Optional[TemporalVariationProperties] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_DynamicTemporal:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_DynamicTemporal
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_DynamicTemporal()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .equivalent_static_case_properties import EquivalentStaticCaseProperties
        from .function import Function
        from .function_harmonique import FunctionHarmonique
        from .load_case import LoadCase
        from .temporal_results_properties import TemporalResultsProperties
        from .temporal_variation_properties import TemporalVariationProperties

        from .equivalent_static_case_properties import EquivalentStaticCaseProperties
        from .function import Function
        from .function_harmonique import FunctionHarmonique
        from .load_case import LoadCase
        from .temporal_results_properties import TemporalResultsProperties
        from .temporal_variation_properties import TemporalVariationProperties

        fields: dict[str, Callable[[Any], None]] = {
            "function": lambda n : setattr(self, 'function', n.get_object_value(Function)),
            "harmoniques": lambda n : setattr(self, 'harmoniques', n.get_collection_of_object_values(FunctionHarmonique)),
            "resultsProperties": lambda n : setattr(self, 'results_properties', n.get_object_value(TemporalResultsProperties)),
            "timeIntervalProperties": lambda n : setattr(self, 'time_interval_properties', n.get_object_value(EquivalentStaticCaseProperties)),
            "variationProperties": lambda n : setattr(self, 'variation_properties', n.get_object_value(TemporalVariationProperties)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("function", self.function)
        writer.write_collection_of_object_values("harmoniques", self.harmoniques)
        writer.write_object_value("resultsProperties", self.results_properties)
        writer.write_object_value("timeIntervalProperties", self.time_interval_properties)
        writer.write_object_value("variationProperties", self.variation_properties)
        writer.write_additional_data_value(self.additional_data)
    

