from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .punching_shape_type import PunchingShapeType

@dataclass
class ImpactingSurface(Parsable):
    """
    Impacting surface data extracted from former punchingShape/punchingA/punchingB fields.
    """
    from .punching_shape_type import PunchingShapeType

    # Punching shape (raw enum value).Unit: no unit Default value : 0
    punching_shape: Optional[PunchingShapeType] = PunchingShapeType("Rectangular")
    # Punching dimension A (punchingA).Unit: m Default value : 0.2
    punching_a: Optional[float] = None
    # Punching dimension B (punchingB).Unit: m Default value : 0.3
    punching_b: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImpactingSurface:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImpactingSurface
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImpactingSurface()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .punching_shape_type import PunchingShapeType

        from .punching_shape_type import PunchingShapeType

        fields: dict[str, Callable[[Any], None]] = {
            "punchingA": lambda n : setattr(self, 'punching_a', n.get_float_value()),
            "punchingB": lambda n : setattr(self, 'punching_b', n.get_float_value()),
            "punchingShape": lambda n : setattr(self, 'punching_shape', n.get_enum_value(PunchingShapeType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("punchingA", self.punching_a)
        writer.write_float_value("punchingB", self.punching_b)
        writer.write_enum_value("punchingShape", self.punching_shape)
    

