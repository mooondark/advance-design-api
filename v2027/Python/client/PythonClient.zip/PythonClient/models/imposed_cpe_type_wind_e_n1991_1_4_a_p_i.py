from enum import Enum

class ImposedCpeType_Wind_EN1991_1_4_API(str, Enum):
    E_CPE_MODE_default = "e_CPE_MODE_default",
    E_CPE_MODE_FORCE = "e_CPE_MODE_FORCE",

