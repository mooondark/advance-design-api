from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .calcul_method_a_p_i import CalculMethod_API

@dataclass
class CalculationMethodIBC(Parsable):
    """
    Calculation method configuration for IBC seismic
    """
    from .calcul_method_a_p_i import CalculMethod_API

    # Calculation method (SRSS, CQC, ABS)Default: CalculMethod_API.CQC
    calcul_method: Optional[CalculMethod_API] = CalculMethod_API("CQC")
    # Residual mode considerationDefault: false
    residual_mode: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CalculationMethodIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CalculationMethodIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CalculationMethodIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .calcul_method_a_p_i import CalculMethod_API

        from .calcul_method_a_p_i import CalculMethod_API

        fields: dict[str, Callable[[Any], None]] = {
            "calculMethod": lambda n : setattr(self, 'calcul_method', n.get_enum_value(CalculMethod_API)),
            "residualMode": lambda n : setattr(self, 'residual_mode', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("calculMethod", self.calcul_method)
        writer.write_bool_value("residualMode", self.residual_mode)
    

