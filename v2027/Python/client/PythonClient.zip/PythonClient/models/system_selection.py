from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SystemSelection(Parsable):
    """
    System selection defining which systems the load case applies to
    """
    # Comma-separated list of system names/identifiers when Selection is LIST_OF_SYSTEMS.    Default: empty string
    list_: Optional[str] = None
    # Selection mode: ALL_SYSTEMS (0), LIST_OF_SYSTEMS (1) or none(2).Unit: -Default: ALL_SYSTEMS (0)
    selection: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SystemSelection:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SystemSelection
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SystemSelection()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "list": lambda n : setattr(self, 'list_', n.get_str_value()),
            "selection": lambda n : setattr(self, 'selection', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("list", self.list_)
        writer.write_int_value("selection", self.selection)
    

