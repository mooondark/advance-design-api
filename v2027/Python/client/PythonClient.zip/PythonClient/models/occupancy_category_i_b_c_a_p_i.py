from enum import Enum

class OccupancyCategoryIBC_API(str, Enum):
    I = "I",
    II = "II",
    III = "III",
    IV = "IV",

