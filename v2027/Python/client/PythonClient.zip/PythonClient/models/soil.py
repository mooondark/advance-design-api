from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .soil_type import SoilType

@dataclass
class Soil(Parsable):
    """
    Soil properties 
    """
    # Name of the soil.Unit: no unit Default value: "DefaultSoil"
    soil_name: Optional[str] = "DefaultSoil"
    from .soil_type import SoilType

    # Type of the soil.Unit: no unit Default value: SoilType.eSoilType_Peat
    type: Optional[SoilType] = SoilType("eSoilType_Peat")
    # Cohesion of the soil [kPa].Unit: kPa Default value: 0.0
    soil_cohesion: Optional[float] = None
    # Density of the soil [kg/m3].Unit: kg/m3 Default value: 2000.0
    soil_density: Optional[float] = None
    # Elastic modulus of the soil [kPa].Unit: kPa Default value: 10000.0
    soil_elastic_modulus: Optional[float] = None
    # Internal angle of friction of the soil [deg].Unit: degrees Default value: 30.0
    soil_internal_angle: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Soil:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Soil
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Soil()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .soil_type import SoilType

        from .soil_type import SoilType

        fields: dict[str, Callable[[Any], None]] = {
            "soilCohesion": lambda n : setattr(self, 'soil_cohesion', n.get_float_value()),
            "soilDensity": lambda n : setattr(self, 'soil_density', n.get_float_value()),
            "soilElasticModulus": lambda n : setattr(self, 'soil_elastic_modulus', n.get_float_value()),
            "soilInternalAngle": lambda n : setattr(self, 'soil_internal_angle', n.get_float_value()),
            "soilName": lambda n : setattr(self, 'soil_name', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(SoilType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("soilCohesion", self.soil_cohesion)
        writer.write_float_value("soilDensity", self.soil_density)
        writer.write_float_value("soilElasticModulus", self.soil_elastic_modulus)
        writer.write_float_value("soilInternalAngle", self.soil_internal_angle)
        writer.write_str_value("soilName", self.soil_name)
        writer.write_enum_value("type", self.type)
    

