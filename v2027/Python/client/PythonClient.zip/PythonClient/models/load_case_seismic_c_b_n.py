from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .direction_seismic_c_b_n import DirectionSeismicCBN
    from .direction_vector_seismic_c_b_n import DirectionVectorSeismicCBN
    from .ductility_factors_c_b_n import DuctilityFactorsCBN
    from .load_case_seismic import LoadCase_Seismic
    from .structure_type_seismic_c_b_n import StructureTypeSeismicCBN

from .load_case_seismic import LoadCase_Seismic

@dataclass
class LoadCase_SeismicCBN(LoadCase_Seismic, AdditionalDataHolder, Parsable):
    """
    Seismic CBN load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Direction parameters (direction choice, sign, mode)
    direction: Optional[DirectionSeismicCBN] = None
    # Direction vector components
    direction_vector: Optional[DirectionVectorSeismicCBN] = None
    # Ductility factors (Rd, Ro, calibration)
    ductility_factors: Optional[DuctilityFactorsCBN] = None
    # Structure type and SFRS configuration
    structure_type: Optional[StructureTypeSeismicCBN] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_SeismicCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_SeismicCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_SeismicCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .direction_seismic_c_b_n import DirectionSeismicCBN
        from .direction_vector_seismic_c_b_n import DirectionVectorSeismicCBN
        from .ductility_factors_c_b_n import DuctilityFactorsCBN
        from .load_case_seismic import LoadCase_Seismic
        from .structure_type_seismic_c_b_n import StructureTypeSeismicCBN

        from .direction_seismic_c_b_n import DirectionSeismicCBN
        from .direction_vector_seismic_c_b_n import DirectionVectorSeismicCBN
        from .ductility_factors_c_b_n import DuctilityFactorsCBN
        from .load_case_seismic import LoadCase_Seismic
        from .structure_type_seismic_c_b_n import StructureTypeSeismicCBN

        fields: dict[str, Callable[[Any], None]] = {
            "direction": lambda n : setattr(self, 'direction', n.get_object_value(DirectionSeismicCBN)),
            "directionVector": lambda n : setattr(self, 'direction_vector', n.get_object_value(DirectionVectorSeismicCBN)),
            "ductilityFactors": lambda n : setattr(self, 'ductility_factors', n.get_object_value(DuctilityFactorsCBN)),
            "structureType": lambda n : setattr(self, 'structure_type', n.get_object_value(StructureTypeSeismicCBN)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("direction", self.direction)
        writer.write_object_value("directionVector", self.direction_vector)
        writer.write_object_value("ductilityFactors", self.ductility_factors)
        writer.write_object_value("structureType", self.structure_type)
        writer.write_additional_data_value(self.additional_data)
    

