from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PushOverBaseProperties(Parsable):
    """
    Push over base properties
    """
    # Number of computed stepsDefault: 0
    computed_steps: Optional[int] = None
    # Internal management - is automaticDefault: false
    is_automatic: Optional[bool] = None
    # Internal management - is updatedDefault: false
    is_updated: Optional[bool] = None
    # Load type parentDefault: None (0)
    load_type_parent: Optional[int] = None
    # Structure behavior typeDefault: Type A (0)
    structure_behavior: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverBaseProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverBaseProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverBaseProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "computedSteps": lambda n : setattr(self, 'computed_steps', n.get_int_value()),
            "isAutomatic": lambda n : setattr(self, 'is_automatic', n.get_bool_value()),
            "isUpdated": lambda n : setattr(self, 'is_updated', n.get_bool_value()),
            "loadTypeParent": lambda n : setattr(self, 'load_type_parent', n.get_int_value()),
            "structureBehavior": lambda n : setattr(self, 'structure_behavior', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("computedSteps", self.computed_steps)
        writer.write_bool_value("isAutomatic", self.is_automatic)
        writer.write_bool_value("isUpdated", self.is_updated)
        writer.write_int_value("loadTypeParent", self.load_type_parent)
        writer.write_int_value("structureBehavior", self.structure_behavior)
    

