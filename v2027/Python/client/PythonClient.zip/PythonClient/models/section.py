from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .section_type_a_p_i import SectionType_API

@dataclass
class Section(Parsable):
    from .section_type_a_p_i import SectionType_API

    # Section typeDefault value: SectionType_API.st_UNKNOWN
    type: Optional[SectionType_API] = SectionType_API("st_UNKNOWN")
    # Catalog nameDefault value: empty string
    catalog_name: Optional[str] = None
    # Family codeDefault value: empty string
    family_code: Optional[str] = None
    # Section nameDefault value: empty string
    name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Section:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Section
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Section()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .section_type_a_p_i import SectionType_API

        from .section_type_a_p_i import SectionType_API

        fields: dict[str, Callable[[Any], None]] = {
            "catalogName": lambda n : setattr(self, 'catalog_name', n.get_str_value()),
            "familyCode": lambda n : setattr(self, 'family_code', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(SectionType_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("catalogName", self.catalog_name)
        writer.write_str_value("familyCode", self.family_code)
        writer.write_str_value("name", self.name)
        writer.write_enum_value("type", self.type)
    

