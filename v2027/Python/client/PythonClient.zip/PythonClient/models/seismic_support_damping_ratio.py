from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SeismicSupportDampingRatio(Parsable):
    """
    Damping associated to each degree of freedom
    """
    # Damping associated to the rotational degree of freedom about the Y axis of the coordinate systemUnit: - Default value : 0.0
    rx: Optional[float] = None
    # Damping associated to the rotational degree of freedom about the X axis of the coordinate systemUnit: - Default value : 0.0
    ry: Optional[float] = None
    # Damping associated to the rotational degree of freedom about the Z axis of the coordinate systemUnit: - Default value : 0.0
    rz: Optional[float] = None
    # Damping associated to the translational degree of freedom along the X axis of the coordinate system.Unit: - Default value : 0.0
    tx: Optional[float] = None
    # Damping associated to the translational degree of freedom along the Y axis of the coordinate system.Unit: - Default value : 0.0
    ty: Optional[float] = None
    # Damping associated to the translational degree of freedom along the Z axis of the coordinate system.Unit: - Default value : 0.0
    tz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SeismicSupportDampingRatio:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SeismicSupportDampingRatio
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SeismicSupportDampingRatio()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "rx": lambda n : setattr(self, 'rx', n.get_float_value()),
            "ry": lambda n : setattr(self, 'ry', n.get_float_value()),
            "rz": lambda n : setattr(self, 'rz', n.get_float_value()),
            "tx": lambda n : setattr(self, 'tx', n.get_float_value()),
            "ty": lambda n : setattr(self, 'ty', n.get_float_value()),
            "tz": lambda n : setattr(self, 'tz', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("rx", self.rx)
        writer.write_float_value("ry", self.ry)
        writer.write_float_value("rz", self.rz)
        writer.write_float_value("tx", self.tx)
        writer.write_float_value("ty", self.ty)
        writer.write_float_value("tz", self.tz)
    

