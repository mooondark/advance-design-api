from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LinearElementInnertia(Parsable):
    """
    Linear element inertia properties
    """
    # Cracked inertia coefficient for IyUnit: no unitDefault value: 1.0
    linear_coeff_cracked_inertia: Optional[float] = None
    # Cracked inertia coefficient for axial stiffness (A)Unit: no unitDefault value: 1.0
    linear_coeff_cracked_inertia_axial_stiff: Optional[float] = None
    # Cracked inertia coefficient for IzUnit: no unitDefault value: 1.0
    linear_coeff_cracked_inertia_iz: Optional[float] = None
    # Cracked inertia coefficient for torsion (J)Unit: no unitDefault value: 1.0
    linear_coeff_cracked_inertia_torsion: Optional[float] = None
    # Concrete inertia type0 auto calulation, 1 manual set coefficients Default value: 0 (auto)
    linear_concrete_inertia_type: Optional[int] = None
    # Product of inertia Iyz equals zeroDefault value: false
    product_of_inertia_iyz0: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinearElementInnertia:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinearElementInnertia
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LinearElementInnertia()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "linearCoeffCrackedInertia": lambda n : setattr(self, 'linear_coeff_cracked_inertia', n.get_float_value()),
            "linearCoeffCrackedInertiaAxialStiff": lambda n : setattr(self, 'linear_coeff_cracked_inertia_axial_stiff', n.get_float_value()),
            "linearCoeffCrackedInertiaIz": lambda n : setattr(self, 'linear_coeff_cracked_inertia_iz', n.get_float_value()),
            "linearCoeffCrackedInertiaTorsion": lambda n : setattr(self, 'linear_coeff_cracked_inertia_torsion', n.get_float_value()),
            "linearConcreteInertiaType": lambda n : setattr(self, 'linear_concrete_inertia_type', n.get_int_value()),
            "productOfInertiaIyz0": lambda n : setattr(self, 'product_of_inertia_iyz0', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("linearCoeffCrackedInertia", self.linear_coeff_cracked_inertia)
        writer.write_float_value("linearCoeffCrackedInertiaAxialStiff", self.linear_coeff_cracked_inertia_axial_stiff)
        writer.write_float_value("linearCoeffCrackedInertiaIz", self.linear_coeff_cracked_inertia_iz)
        writer.write_float_value("linearCoeffCrackedInertiaTorsion", self.linear_coeff_cracked_inertia_torsion)
        writer.write_int_value("linearConcreteInertiaType", self.linear_concrete_inertia_type)
        writer.write_bool_value("productOfInertiaIyz0", self.product_of_inertia_iyz0)
    

