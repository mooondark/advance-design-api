from enum import Enum

class TypeStructureIBC_API(str, Enum):
    StructureResistMomentFrame = "StructureResistMomentFrame",
    StructureResistShearWall = "StructureResistShearWall",
    StructureResistBracedFrame = "StructureResistBracedFrame",
    StructureResistDualSystem = "StructureResistDualSystem",
    StructureResistOther = "StructureResistOther",

