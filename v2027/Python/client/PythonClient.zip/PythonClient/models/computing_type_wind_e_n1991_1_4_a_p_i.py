from enum import Enum

class ComputingType_Wind_EN1991_1_4_API(str, Enum):
    EComputingTypeAuto = "eComputingTypeAuto",
    EComputingTypeImposed = "eComputingTypeImposed",

