from enum import Enum

class SeismicCategory_API(str, Enum):
    SC1 = "SC1",
    SC2 = "SC2",
    SC3 = "SC3",
    SC4 = "SC4",

