from enum import Enum

class CeMode_WindCBN_API(str, Enum):
    WindCBNWd2010_CE_A = "WindCBNWd2010_CE_A",
    WindCBNWd2010_CE_B = "WindCBNWd2010_CE_B",
    WindCBNWd2010_CE_C_MANUAL = "WindCBNWd2010_CE_C_MANUAL",

