from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .material import Material
    from .material_behaviour_type import MaterialBehaviourType

from .material import Material

@dataclass
class MaterialRigid(Material, AdditionalDataHolder, Parsable):
    """
    Rigid material properties
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .material_behaviour_type import MaterialBehaviourType

    # Material behavior type Default value: MaterialBehaviourType.isotropic_behavior
    behavior_type: Optional[MaterialBehaviourType] = MaterialBehaviourType("isotropic_behavior")
    # Thermal dilatation (α)Unit: 1/°CDefault value: 0.00001 (10E-6)
    alpha: Optional[float] = None
    # Color (angle in degrees)Unit: degreesDefault value: 1.2566370614359172 (72 degrees in radians)
    color: Optional[float] = None
    # Damping coefficient (% of critical damping)Unit: no unitDefault value: 0.05 (5%)
    damping: Optional[float] = None
    # Diffusion angleUnit: radiansDefault value: 1.2566370614359172 (72 degrees)
    diffusion: Optional[float] = None
    # Longitudinal rigidity (E)Unit: PaDefault value: 30000000000.0 (30 GPa)
    e: Optional[float] = None
    # Ratio Ei/Ev (modular ratio for creep)Unit: no unitDefault value: 3.0
    ei_ev: Optional[float] = None
    # Characteristic compressive cylinder strength (fck)Unit: PaDefault value: 25000000.0 (25 MPa)
    fck: Optional[float] = None
    # Ultimate compressive strength (fcu)Unit: PaDefault value: 30000000.0 (30 MPa)
    fcu: Optional[float] = None
    # Characteristic yield strength of reinforcement (fyk)Unit: PaDefault value: 500000000.0 (500 MPa)
    fyk: Optional[float] = None
    # Characteristic yield strength of longitudinal reinforcement (fykl)Unit: PaDefault value: 500000000.0 (500 MPa)
    fykl: Optional[float] = None
    # Characteristic yield strength of transverse reinforcement (fykt)Unit: PaDefault value: 500000000.0 (500 MPa)
    fykt: Optional[float] = None
    # Transverse rigidity (G)Unit: PaDefault value: 0.0 (calculated from E and Nu if 0)
    g: Optional[float] = None
    # Surface massUnit: kg/m²Default value: 0.0
    ms: Optional[float] = None
    # Linear mass (for linear elements)Unit: kg/mDefault value: 0.0
    mu: Optional[float] = None
    # Poisson's ratio (ν)Unit: no unitDefault value: 0.2
    nu: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> MaterialRigid:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: MaterialRigid
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return MaterialRigid()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .material import Material
        from .material_behaviour_type import MaterialBehaviourType

        from .material import Material
        from .material_behaviour_type import MaterialBehaviourType

        fields: dict[str, Callable[[Any], None]] = {
            "alpha": lambda n : setattr(self, 'alpha', n.get_float_value()),
            "behaviorType": lambda n : setattr(self, 'behavior_type', n.get_enum_value(MaterialBehaviourType)),
            "color": lambda n : setattr(self, 'color', n.get_float_value()),
            "damping": lambda n : setattr(self, 'damping', n.get_float_value()),
            "diffusion": lambda n : setattr(self, 'diffusion', n.get_float_value()),
            "e": lambda n : setattr(self, 'e', n.get_float_value()),
            "eiEv": lambda n : setattr(self, 'ei_ev', n.get_float_value()),
            "fck": lambda n : setattr(self, 'fck', n.get_float_value()),
            "fcu": lambda n : setattr(self, 'fcu', n.get_float_value()),
            "fyk": lambda n : setattr(self, 'fyk', n.get_float_value()),
            "fykl": lambda n : setattr(self, 'fykl', n.get_float_value()),
            "fykt": lambda n : setattr(self, 'fykt', n.get_float_value()),
            "g": lambda n : setattr(self, 'g', n.get_float_value()),
            "ms": lambda n : setattr(self, 'ms', n.get_float_value()),
            "mu": lambda n : setattr(self, 'mu', n.get_float_value()),
            "nu": lambda n : setattr(self, 'nu', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("alpha", self.alpha)
        writer.write_enum_value("behaviorType", self.behavior_type)
        writer.write_float_value("color", self.color)
        writer.write_float_value("damping", self.damping)
        writer.write_float_value("diffusion", self.diffusion)
        writer.write_float_value("e", self.e)
        writer.write_float_value("eiEv", self.ei_ev)
        writer.write_float_value("fck", self.fck)
        writer.write_float_value("fcu", self.fcu)
        writer.write_float_value("fyk", self.fyk)
        writer.write_float_value("fykl", self.fykl)
        writer.write_float_value("fykt", self.fykt)
        writer.write_float_value("g", self.g)
        writer.write_float_value("ms", self.ms)
        writer.write_float_value("mu", self.mu)
        writer.write_float_value("nu", self.nu)
        writer.write_additional_data_value(self.additional_data)
    

