from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .informational_element_base import InformationalElementBase
    from .load_case_family_accidental import LoadCaseFamily_Accidental
    from .load_case_family_combinations_coefficients import LoadCaseFamilyCombinationsCoefficients
    from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads
    from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
    from .load_case_family_live_loads import LoadCaseFamily_LiveLoads
    from .load_case_family_other import LoadCaseFamily_Other
    from .load_case_family_push_over import LoadCaseFamily_PushOver
    from .load_case_family_seismic import LoadCaseFamily_Seismic
    from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
    from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
    from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
    from .load_case_family_snow import LoadCaseFamily_Snow
    from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
    from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
    from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
    from .load_case_family_thermic import LoadCaseFamily_Thermic
    from .load_case_family_wind import LoadCaseFamily_Wind
    from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
    from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
    from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC

from .informational_element_base import InformationalElementBase

@dataclass
class LoadCaseFamily(InformationalElementBase, AdditionalDataHolder, Parsable):
    """
    Load case family (parents of load cases)
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Combinations coefficients for this load case family Default value : null (initialized with default values)
    combinations_coefficients: Optional[LoadCaseFamilyCombinationsCoefficients] = None
    # user name for the load case
    name: Optional[str] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Accidental".casefold():
            from .load_case_family_accidental import LoadCaseFamily_Accidental

            return LoadCaseFamily_Accidental()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_DeadLoads".casefold():
            from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads

            return LoadCaseFamily_DeadLoads()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_DynamicTemporal".casefold():
            from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal

            return LoadCaseFamily_DynamicTemporal()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_LiveLoads".casefold():
            from .load_case_family_live_loads import LoadCaseFamily_LiveLoads

            return LoadCaseFamily_LiveLoads()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Other".casefold():
            from .load_case_family_other import LoadCaseFamily_Other

            return LoadCaseFamily_Other()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_PushOver".casefold():
            from .load_case_family_push_over import LoadCaseFamily_PushOver

            return LoadCaseFamily_PushOver()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Seismic".casefold():
            from .load_case_family_seismic import LoadCaseFamily_Seismic

            return LoadCaseFamily_Seismic()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicCBN".casefold():
            from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN

            return LoadCaseFamily_SeismicCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicEN_1998_1".casefold():
            from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1

            return LoadCaseFamily_SeismicEN_1998_1()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicIBC".casefold():
            from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC

            return LoadCaseFamily_SeismicIBC()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Snow".casefold():
            from .load_case_family_snow import LoadCaseFamily_Snow

            return LoadCaseFamily_Snow()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Snow_1991_1_3".casefold():
            from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3

            return LoadCaseFamily_Snow_1991_1_3()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowCBN".casefold():
            from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN

            return LoadCaseFamily_SnowCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowIBC".casefold():
            from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC

            return LoadCaseFamily_SnowIBC()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Thermic".casefold():
            from .load_case_family_thermic import LoadCaseFamily_Thermic

            return LoadCaseFamily_Thermic()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Wind".casefold():
            from .load_case_family_wind import LoadCaseFamily_Wind

            return LoadCaseFamily_Wind()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Wind_1991_1_4".casefold():
            from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4

            return LoadCaseFamily_Wind_1991_1_4()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_WindCBN".casefold():
            from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN

            return LoadCaseFamily_WindCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_WindIBC".casefold():
            from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC

            return LoadCaseFamily_WindIBC()
        return LoadCaseFamily()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .informational_element_base import InformationalElementBase
        from .load_case_family_accidental import LoadCaseFamily_Accidental
        from .load_case_family_combinations_coefficients import LoadCaseFamilyCombinationsCoefficients
        from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads
        from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
        from .load_case_family_live_loads import LoadCaseFamily_LiveLoads
        from .load_case_family_other import LoadCaseFamily_Other
        from .load_case_family_push_over import LoadCaseFamily_PushOver
        from .load_case_family_seismic import LoadCaseFamily_Seismic
        from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
        from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
        from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
        from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
        from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
        from .load_case_family_thermic import LoadCaseFamily_Thermic
        from .load_case_family_wind import LoadCaseFamily_Wind
        from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
        from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
        from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC

        from .informational_element_base import InformationalElementBase
        from .load_case_family_accidental import LoadCaseFamily_Accidental
        from .load_case_family_combinations_coefficients import LoadCaseFamilyCombinationsCoefficients
        from .load_case_family_dead_loads import LoadCaseFamily_DeadLoads
        from .load_case_family_dynamic_temporal import LoadCaseFamily_DynamicTemporal
        from .load_case_family_live_loads import LoadCaseFamily_LiveLoads
        from .load_case_family_other import LoadCaseFamily_Other
        from .load_case_family_push_over import LoadCaseFamily_PushOver
        from .load_case_family_seismic import LoadCaseFamily_Seismic
        from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
        from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
        from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
        from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
        from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC
        from .load_case_family_thermic import LoadCaseFamily_Thermic
        from .load_case_family_wind import LoadCaseFamily_Wind
        from .load_case_family_wind_1991_1_4 import LoadCaseFamily_Wind_1991_1_4
        from .load_case_family_wind_c_b_n import LoadCaseFamily_WindCBN
        from .load_case_family_wind_i_b_c import LoadCaseFamily_WindIBC

        fields: dict[str, Callable[[Any], None]] = {
            "combinationsCoefficients": lambda n : setattr(self, 'combinations_coefficients', n.get_object_value(LoadCaseFamilyCombinationsCoefficients)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("combinationsCoefficients", self.combinations_coefficients)
        writer.write_str_value("name", self.name)
        writer.write_additional_data_value(self.additional_data)
    

