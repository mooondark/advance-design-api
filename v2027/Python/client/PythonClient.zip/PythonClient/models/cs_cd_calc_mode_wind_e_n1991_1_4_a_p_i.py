from enum import Enum

class CsCdCalcMode_Wind_EN1991_1_4_API(str, Enum):
    CS_CD_AUTO = "CS_CD_AUTO",
    CS_CD_IMPOSED = "CS_CD_IMPOSED",

