from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_base import ElementBase
    from .e_i_d import EID
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementImposedDisplacement(ElementBase, AdditionalDataHolder, Parsable):
    """
    Imposed displacement element
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Action application point DX (m) Unit: m Default value : 0.0
    dx: Optional[float] = None
    # Action application point DY (m) Unit: m Default value : 0.0
    dy: Optional[float] = None
    # Action application point DZ (m) Unit: m Default value : 0.0
    dz: Optional[float] = None
    # gemetry point 3D (global repere).Unit: m Default value : (0, 0, 0)
    geom_pt: Optional[Pt3D] = None
    # EID of the load case already created
    load_case: Optional[EID] = None
    # Action application point RX (degree)Unit: degree Default value : 0.0
    rx: Optional[float] = None
    # Action application point RY (degree)Unit: degree Default value : 0.0
    ry: Optional[float] = None
    # Action application point RZ (degree)Unit: degree Default value : 0.0
    rz: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementImposedDisplacement:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementImposedDisplacement
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementImposedDisplacement()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_base import ElementBase
        from .e_i_d import EID
        from .pt3_d import Pt3D

        from .element_base import ElementBase
        from .e_i_d import EID
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "dx": lambda n : setattr(self, 'dx', n.get_float_value()),
            "dy": lambda n : setattr(self, 'dy', n.get_float_value()),
            "dz": lambda n : setattr(self, 'dz', n.get_float_value()),
            "geomPt": lambda n : setattr(self, 'geom_pt', n.get_object_value(Pt3D)),
            "loadCase": lambda n : setattr(self, 'load_case', n.get_object_value(EID)),
            "rx": lambda n : setattr(self, 'rx', n.get_float_value()),
            "ry": lambda n : setattr(self, 'ry', n.get_float_value()),
            "rz": lambda n : setattr(self, 'rz', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("dx", self.dx)
        writer.write_float_value("dy", self.dy)
        writer.write_float_value("dz", self.dz)
        writer.write_object_value("geomPt", self.geom_pt)
        writer.write_object_value("loadCase", self.load_case)
        writer.write_float_value("rx", self.rx)
        writer.write_float_value("ry", self.ry)
        writer.write_float_value("rz", self.rz)
        writer.write_additional_data_value(self.additional_data)
    

