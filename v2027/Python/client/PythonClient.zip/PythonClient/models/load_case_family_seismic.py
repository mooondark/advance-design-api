from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case_family import LoadCaseFamily
    from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
    from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
    from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
    from .spectrum_definitions import SpectrumDefinitions

from .load_case_family import LoadCaseFamily

@dataclass
class LoadCaseFamily_Seismic(LoadCaseFamily, AdditionalDataHolder, Parsable):
    """
    Seismic loads case family, load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Response spectrum definition
    response_spectrum_definitions: Optional[SpectrumDefinitions] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_Seismic:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_Seismic
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicCBN".casefold():
            from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN

            return LoadCaseFamily_SeismicCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicEN_1998_1".casefold():
            from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1

            return LoadCaseFamily_SeismicEN_1998_1()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SeismicIBC".casefold():
            from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC

            return LoadCaseFamily_SeismicIBC()
        return LoadCaseFamily_Seismic()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case_family import LoadCaseFamily
        from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
        from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
        from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
        from .spectrum_definitions import SpectrumDefinitions

        from .load_case_family import LoadCaseFamily
        from .load_case_family_seismic_c_b_n import LoadCaseFamily_SeismicCBN
        from .load_case_family_seismic_e_n_1998_1 import LoadCaseFamily_SeismicEN_1998_1
        from .load_case_family_seismic_i_b_c import LoadCaseFamily_SeismicIBC
        from .spectrum_definitions import SpectrumDefinitions

        fields: dict[str, Callable[[Any], None]] = {
            "responseSpectrumDefinitions": lambda n : setattr(self, 'response_spectrum_definitions', n.get_object_value(SpectrumDefinitions)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("responseSpectrumDefinitions", self.response_spectrum_definitions)
        writer.write_additional_data_value(self.additional_data)
    

