from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_area_opening_type import LoadArea_Opening_type
    from .load_area_type import Load_Area_Type

@dataclass
class LinearLoadAreaLoadTransfer(Parsable):
    """
    Linear element load area transfer properties
    """
    from .load_area_type import Load_Area_Type

    # Climatic Type - what type of structure is considered for 2D climatic calculationsDefault value : Load_Area_Type.CG_LOADAREA_BUILDING
    climatic_type: Optional[Load_Area_Type] = Load_Area_Type("CG_LOADAREA_BUILDING")
    from .load_area_opening_type import LoadArea_Opening_type

    # Opening type for climatic calculationsDefault value: LoadArea_Opening_type.CG_WINDWALL_OPENING_TYPE_CLOSED_NO_OPENINGS
    opening_type: Optional[LoadArea_Opening_type] = LoadArea_Opening_type("CG_WINDWALL_OPENING_TYPE_CLOSED_NO_OPENINGS")
    # 2D climatic linear elementDefault value: false
    climatic_l_e2_d: Optional[bool] = None
    # Continuity coefficientUnit: no unitDefault value: 1.0
    continuity_coeff: Optional[float] = None
    # Is scaffolding supportDefault value: false
    is_scaffolding_support: Optional[bool] = None
    # Is wind wall supportDefault value: true
    is_wind_wall_support: Optional[bool] = None
    # Load span behindUnit: mDefault value: 2.5
    load_span_behind: Optional[float] = None
    # Load span in frontUnit: mDefault value: 2.5
    load_span_front: Optional[float] = None
    # Openings value (m² for area, % for percentage)Unit: m² or %Default value: 0.0
    openings_value: Optional[float] = None
    # Snow guards for 2D elementsDefault value: false
    snow_guards2_d: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinearLoadAreaLoadTransfer:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinearLoadAreaLoadTransfer
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LinearLoadAreaLoadTransfer()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_area_opening_type import LoadArea_Opening_type
        from .load_area_type import Load_Area_Type

        from .load_area_opening_type import LoadArea_Opening_type
        from .load_area_type import Load_Area_Type

        fields: dict[str, Callable[[Any], None]] = {
            "climaticLE2D": lambda n : setattr(self, 'climatic_l_e2_d', n.get_bool_value()),
            "climaticType": lambda n : setattr(self, 'climatic_type', n.get_enum_value(Load_Area_Type)),
            "continuityCoeff": lambda n : setattr(self, 'continuity_coeff', n.get_float_value()),
            "isScaffoldingSupport": lambda n : setattr(self, 'is_scaffolding_support', n.get_bool_value()),
            "isWindWallSupport": lambda n : setattr(self, 'is_wind_wall_support', n.get_bool_value()),
            "loadSpanBehind": lambda n : setattr(self, 'load_span_behind', n.get_float_value()),
            "loadSpanFront": lambda n : setattr(self, 'load_span_front', n.get_float_value()),
            "openingType": lambda n : setattr(self, 'opening_type', n.get_enum_value(LoadArea_Opening_type)),
            "openingsValue": lambda n : setattr(self, 'openings_value', n.get_float_value()),
            "snowGuards2D": lambda n : setattr(self, 'snow_guards2_d', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("climaticLE2D", self.climatic_l_e2_d)
        writer.write_enum_value("climaticType", self.climatic_type)
        writer.write_float_value("continuityCoeff", self.continuity_coeff)
        writer.write_bool_value("isScaffoldingSupport", self.is_scaffolding_support)
        writer.write_bool_value("isWindWallSupport", self.is_wind_wall_support)
        writer.write_float_value("loadSpanBehind", self.load_span_behind)
        writer.write_float_value("loadSpanFront", self.load_span_front)
        writer.write_enum_value("openingType", self.opening_type)
        writer.write_float_value("openingsValue", self.openings_value)
        writer.write_bool_value("snowGuards2D", self.snow_guards2_d)
    

