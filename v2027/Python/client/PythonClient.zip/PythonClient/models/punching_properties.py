from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .punching_position import PunchingPosition

@dataclass
class PunchingProperties(Parsable):
    """
    Describes the Punching Object properties for a punctual support.
    """
    from .punching_position import PunchingPosition

    # Position of the punching perimeter.Unit: no unit Default value : PunchingPosition.Auto
    position: Optional[PunchingPosition] = PunchingPosition("Auto")
    # Reduction factor for punching perimeter (beta).Unit: no unit Default value : 0.0
    beta: Optional[float] = None
    # Choice of whether the length of the control perimeter u1 is determined automatically or imposed by the user (0 = auto, 1 = imposed).Unit: no unit Default value : 0
    control_perimeter: Optional[int] = None
    # Length of control perimeter u1 determined after calculations or entered by the user (m).Unit: m Default value : 0.0
    u1: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PunchingProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PunchingProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PunchingProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .punching_position import PunchingPosition

        from .punching_position import PunchingPosition

        fields: dict[str, Callable[[Any], None]] = {
            "beta": lambda n : setattr(self, 'beta', n.get_float_value()),
            "controlPerimeter": lambda n : setattr(self, 'control_perimeter', n.get_int_value()),
            "position": lambda n : setattr(self, 'position', n.get_enum_value(PunchingPosition)),
            "u1": lambda n : setattr(self, 'u1', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("beta", self.beta)
        writer.write_int_value("controlPerimeter", self.control_perimeter)
        writer.write_enum_value("position", self.position)
        writer.write_float_value("u1", self.u1)
    

