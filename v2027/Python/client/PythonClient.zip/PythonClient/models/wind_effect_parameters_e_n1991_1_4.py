from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .internal_pressure_wind_e_n1991_1_4_a_p_i import InternalPressure_Wind_EN1991_1_4_API
    from .loadings_case_type_wind import LoadingsCaseType_Wind
    from .wind_direction_wind_e_n1991_1_4_a_p_i import WindDirection_Wind_EN1991_1_4_API

@dataclass
class WindEffectParameters_EN1991_1_4(Parsable):
    """
    Wind load case effect parameters for EN 1991-1-4
    """
    from .internal_pressure_wind_e_n1991_1_4_a_p_i import InternalPressure_Wind_EN1991_1_4_API

    # Internal pressure typeUnit: -Default: WIND_SURPRESSION
    internal_pressure: Optional[InternalPressure_Wind_EN1991_1_4_API] = InternalPressure_Wind_EN1991_1_4_API("WIND_SURPRESSION")
    from .loadings_case_type_wind import LoadingsCaseType_Wind

    # Type of loadings caseUnit: -Default: NORMAL_TYPE_WIND
    type_of_loadings_case: Optional[LoadingsCaseType_Wind] = LoadingsCaseType_Wind("NORMAL_TYPE_WIND")
    from .wind_direction_wind_e_n1991_1_4_a_p_i import WindDirection_Wind_EN1991_1_4_API

    # Wind directionUnit: -Default: WIND_X_PLUS
    wind_direction: Optional[WindDirection_Wind_EN1991_1_4_API] = WindDirection_Wind_EN1991_1_4_API("WIND_X_PLUS")
    # Is automatic generationUnit: -Default: false
    is_automatic: Optional[bool] = None
    # Is partial mass consideredUnit: -Default: true
    is_partial_mass: Optional[bool] = None
    # Is updatedUnit: -Default: false
    is_updated: Optional[bool] = None
    # Partial mass coefficientUnit: -Default: 0.0
    partial_mass_coefficient: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WindEffectParameters_EN1991_1_4:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WindEffectParameters_EN1991_1_4
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WindEffectParameters_EN1991_1_4()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .internal_pressure_wind_e_n1991_1_4_a_p_i import InternalPressure_Wind_EN1991_1_4_API
        from .loadings_case_type_wind import LoadingsCaseType_Wind
        from .wind_direction_wind_e_n1991_1_4_a_p_i import WindDirection_Wind_EN1991_1_4_API

        from .internal_pressure_wind_e_n1991_1_4_a_p_i import InternalPressure_Wind_EN1991_1_4_API
        from .loadings_case_type_wind import LoadingsCaseType_Wind
        from .wind_direction_wind_e_n1991_1_4_a_p_i import WindDirection_Wind_EN1991_1_4_API

        fields: dict[str, Callable[[Any], None]] = {
            "internalPressure": lambda n : setattr(self, 'internal_pressure', n.get_enum_value(InternalPressure_Wind_EN1991_1_4_API)),
            "isAutomatic": lambda n : setattr(self, 'is_automatic', n.get_bool_value()),
            "isPartialMass": lambda n : setattr(self, 'is_partial_mass', n.get_bool_value()),
            "isUpdated": lambda n : setattr(self, 'is_updated', n.get_bool_value()),
            "partialMassCoefficient": lambda n : setattr(self, 'partial_mass_coefficient', n.get_float_value()),
            "typeOfLoadingsCase": lambda n : setattr(self, 'type_of_loadings_case', n.get_enum_value(LoadingsCaseType_Wind)),
            "windDirection": lambda n : setattr(self, 'wind_direction', n.get_enum_value(WindDirection_Wind_EN1991_1_4_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("internalPressure", self.internal_pressure)
        writer.write_bool_value("isAutomatic", self.is_automatic)
        writer.write_bool_value("isPartialMass", self.is_partial_mass)
        writer.write_bool_value("isUpdated", self.is_updated)
        writer.write_float_value("partialMassCoefficient", self.partial_mass_coefficient)
        writer.write_enum_value("typeOfLoadingsCase", self.type_of_loadings_case)
        writer.write_enum_value("windDirection", self.wind_direction)
    

