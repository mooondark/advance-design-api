from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case import LoadCase
    from .push_over_base_properties import PushOverBaseProperties
    from .push_over_direction_config import PushOverDirectionConfig
    from .push_over_incrementation_config import PushOverIncrementationConfig
    from .push_over_load_pattern_config import PushOverLoadPatternConfig
    from .push_over_position_config import PushOverPositionConfig
    from .push_over_target_displacement_config import PushOverTargetDisplacementConfig

from .load_case import LoadCase

@dataclass
class LoadCase_PushOver(LoadCase, AdditionalDataHolder, Parsable):
    """
    Push over load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Push over base properties IsUpdated, StructureBehavior, ComputedSteps, etc
    base_properties: Optional[PushOverBaseProperties] = None
    # Push over load direction configuration
    direction_config: Optional[PushOverDirectionConfig] = None
    # Push over incrementation configuration
    incrementation: Optional[PushOverIncrementationConfig] = None
    # Push over load pattern configuration
    load_pattern: Optional[PushOverLoadPatternConfig] = None
    # Push over load position configuration
    position_config: Optional[PushOverPositionConfig] = None
    # Push over target displacement configuration
    target_displacement: Optional[PushOverTargetDisplacementConfig] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_PushOver:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_PushOver
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_PushOver()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case import LoadCase
        from .push_over_base_properties import PushOverBaseProperties
        from .push_over_direction_config import PushOverDirectionConfig
        from .push_over_incrementation_config import PushOverIncrementationConfig
        from .push_over_load_pattern_config import PushOverLoadPatternConfig
        from .push_over_position_config import PushOverPositionConfig
        from .push_over_target_displacement_config import PushOverTargetDisplacementConfig

        from .load_case import LoadCase
        from .push_over_base_properties import PushOverBaseProperties
        from .push_over_direction_config import PushOverDirectionConfig
        from .push_over_incrementation_config import PushOverIncrementationConfig
        from .push_over_load_pattern_config import PushOverLoadPatternConfig
        from .push_over_position_config import PushOverPositionConfig
        from .push_over_target_displacement_config import PushOverTargetDisplacementConfig

        fields: dict[str, Callable[[Any], None]] = {
            "baseProperties": lambda n : setattr(self, 'base_properties', n.get_object_value(PushOverBaseProperties)),
            "directionConfig": lambda n : setattr(self, 'direction_config', n.get_object_value(PushOverDirectionConfig)),
            "incrementation": lambda n : setattr(self, 'incrementation', n.get_object_value(PushOverIncrementationConfig)),
            "loadPattern": lambda n : setattr(self, 'load_pattern', n.get_object_value(PushOverLoadPatternConfig)),
            "positionConfig": lambda n : setattr(self, 'position_config', n.get_object_value(PushOverPositionConfig)),
            "targetDisplacement": lambda n : setattr(self, 'target_displacement', n.get_object_value(PushOverTargetDisplacementConfig)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("baseProperties", self.base_properties)
        writer.write_object_value("directionConfig", self.direction_config)
        writer.write_object_value("incrementation", self.incrementation)
        writer.write_object_value("loadPattern", self.load_pattern)
        writer.write_object_value("positionConfig", self.position_config)
        writer.write_object_value("targetDisplacement", self.target_displacement)
        writer.write_additional_data_value(self.additional_data)
    

