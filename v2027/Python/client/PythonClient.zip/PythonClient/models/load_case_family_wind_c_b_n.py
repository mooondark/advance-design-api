from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .auto_generation_parameters_wind_c_b_n import AutoGenerationParametersWindCBN
    from .base_pressure_parameters_wind_c_b_n import BasePressureParametersWindCBN
    from .building2_d_parameters_wind_c_b_n import Building2DParametersWindCBN
    from .load_case_family_wind import LoadCaseFamily_Wind

from .load_case_family_wind import LoadCaseFamily_Wind

@dataclass
class LoadCaseFamily_WindCBN(LoadCaseFamily_Wind, AdditionalDataHolder, Parsable):
    """
    Wind loads case family for Canadian Building Code (NBC), load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Auto generation parameters
    auto_generation: Optional[AutoGenerationParametersWindCBN] = None
    # Base pressure parameters
    base_pressure: Optional[BasePressureParametersWindCBN] = None
    # 2D Building parameters
    building2_d: Optional[Building2DParametersWindCBN] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_WindCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_WindCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamily_WindCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .auto_generation_parameters_wind_c_b_n import AutoGenerationParametersWindCBN
        from .base_pressure_parameters_wind_c_b_n import BasePressureParametersWindCBN
        from .building2_d_parameters_wind_c_b_n import Building2DParametersWindCBN
        from .load_case_family_wind import LoadCaseFamily_Wind

        from .auto_generation_parameters_wind_c_b_n import AutoGenerationParametersWindCBN
        from .base_pressure_parameters_wind_c_b_n import BasePressureParametersWindCBN
        from .building2_d_parameters_wind_c_b_n import Building2DParametersWindCBN
        from .load_case_family_wind import LoadCaseFamily_Wind

        fields: dict[str, Callable[[Any], None]] = {
            "autoGeneration": lambda n : setattr(self, 'auto_generation', n.get_object_value(AutoGenerationParametersWindCBN)),
            "basePressure": lambda n : setattr(self, 'base_pressure', n.get_object_value(BasePressureParametersWindCBN)),
            "building2D": lambda n : setattr(self, 'building2_d', n.get_object_value(Building2DParametersWindCBN)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("autoGeneration", self.auto_generation)
        writer.write_object_value("basePressure", self.base_pressure)
        writer.write_object_value("building2D", self.building2_d)
        writer.write_additional_data_value(self.additional_data)
    

