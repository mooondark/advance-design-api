from enum import Enum

class HaunchLengthSizeType_API(str, Enum):
    Ratio = "ratio",
    Valeur_axe_local = "valeur_axe_local",
    Valeur_projete = "valeur_projete",
    Valeur = "valeur",

