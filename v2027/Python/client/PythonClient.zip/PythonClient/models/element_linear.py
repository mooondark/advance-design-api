from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .clipping_properties import ClippingProperties
    from .connection_elastique import ConnectionElastique
    from .connection_totale import ConnectionTotale
    from .element_base import ElementBase
    from .e_i_d import EID
    from .general_beam_type_a_p_i import GeneralBeamType_API
    from .haunch_properties import HaunchProperties
    from .initial_constraint import InitialConstraint
    from .linear_element_f_e_m_type_a_p_i import LinearElementFEMType_API
    from .linear_element_innertia import LinearElementInnertia
    from .linear_element_mesh_style import LinearElementMeshStyle
    from .linear_load_area_load_transfer import LinearLoadAreaLoadTransfer
    from .pt3_d import Pt3D
    from .section_offset_style import SectionOffsetStyle

from .element_base import ElementBase

@dataclass
class ElementLinear(ElementBase, AdditionalDataHolder, Parsable):
    """
    Linear element (column, beam, truss, cable)
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .general_beam_type_a_p_i import GeneralBeamType_API

    # General beam type (only used when LinearElementFEMType is General)Default value: GeneralBeamType_API.sbeam
    general_beam_type: Optional[GeneralBeamType_API] = GeneralBeamType_API("sbeam")
    from .linear_element_f_e_m_type_a_p_i import LinearElementFEMType_API

    # Linear element FEM type (General/Composite beam)Default value: LinearElementFEMType_API.eLinearElementFEMTypeGeneral
    linear_element_type: Optional[LinearElementFEMType_API] = LinearElementFEMType_API("eLinearElementFEMTypeGeneral")
    # Automatic mesh enabledDefault value: true
    auto_mesh: Optional[bool] = None
    # Clipping propertiesDefault value: optional nullable object
    clipping: Optional[ClippingProperties] = None
    # Mesh propertiesDefault value: optional nullable object
    detailed_mesh_properties: Optional[LinearElementMeshStyle] = None
    # Element active stateDefault value: true
    element_active: Optional[bool] = None
    # Extend element into wallDefault value: true
    extend_into_wall: Optional[bool] = None
    # end point 3D (global repere)
    geom_pt_end: Optional[Pt3D] = None
    # start point 3D (global repere)
    geom_pt_start: Optional[Pt3D] = None
    # End haunch propertiesDefault value: optional nullable object
    haunch_end: Optional[HaunchProperties] = None
    # Start haunch propertiesDefault value: optional nullable object
    haunch_start: Optional[HaunchProperties] = None
    # Inertia propertiesDefault value: optional nullable object
    inertia_properties: Optional[LinearElementInnertia] = None
    # Initial constraint propertiesDefault value: optional nullable object
    initial_constraint_properties: Optional[InitialConstraint] = None
    # Load area transfer propertiesDefault value: optional nullable object
    load_area_load_transfer_properties: Optional[LinearLoadAreaLoadTransfer] = None
    # EID of the material already created (required)
    material: Optional[EID] = None
    # Connection elastique propertiesDefault value: optional nullable object
    relaxation_elastique: Optional[ConnectionElastique] = None
    # Connection total releasesDefault value: optional nullable object
    relaxation_totale: Optional[ConnectionTotale] = None
    # EID of the section already created (required)
    section: Optional[EID] = None
    # Section excentration propertiesDefault value: optional nullable object
    section_excentration: Optional[SectionOffsetStyle] = None
    # Section orientation angleUnit: radiansDefault value: 0.0
    section_orientation_angle: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementLinear:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementLinear
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementLinear()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .clipping_properties import ClippingProperties
        from .connection_elastique import ConnectionElastique
        from .connection_totale import ConnectionTotale
        from .element_base import ElementBase
        from .e_i_d import EID
        from .general_beam_type_a_p_i import GeneralBeamType_API
        from .haunch_properties import HaunchProperties
        from .initial_constraint import InitialConstraint
        from .linear_element_f_e_m_type_a_p_i import LinearElementFEMType_API
        from .linear_element_innertia import LinearElementInnertia
        from .linear_element_mesh_style import LinearElementMeshStyle
        from .linear_load_area_load_transfer import LinearLoadAreaLoadTransfer
        from .pt3_d import Pt3D
        from .section_offset_style import SectionOffsetStyle

        from .clipping_properties import ClippingProperties
        from .connection_elastique import ConnectionElastique
        from .connection_totale import ConnectionTotale
        from .element_base import ElementBase
        from .e_i_d import EID
        from .general_beam_type_a_p_i import GeneralBeamType_API
        from .haunch_properties import HaunchProperties
        from .initial_constraint import InitialConstraint
        from .linear_element_f_e_m_type_a_p_i import LinearElementFEMType_API
        from .linear_element_innertia import LinearElementInnertia
        from .linear_element_mesh_style import LinearElementMeshStyle
        from .linear_load_area_load_transfer import LinearLoadAreaLoadTransfer
        from .pt3_d import Pt3D
        from .section_offset_style import SectionOffsetStyle

        fields: dict[str, Callable[[Any], None]] = {
            "autoMesh": lambda n : setattr(self, 'auto_mesh', n.get_bool_value()),
            "clipping": lambda n : setattr(self, 'clipping', n.get_object_value(ClippingProperties)),
            "detailedMeshProperties": lambda n : setattr(self, 'detailed_mesh_properties', n.get_object_value(LinearElementMeshStyle)),
            "elementActive": lambda n : setattr(self, 'element_active', n.get_bool_value()),
            "extendIntoWall": lambda n : setattr(self, 'extend_into_wall', n.get_bool_value()),
            "generalBeamType": lambda n : setattr(self, 'general_beam_type', n.get_enum_value(GeneralBeamType_API)),
            "geomPtEnd": lambda n : setattr(self, 'geom_pt_end', n.get_object_value(Pt3D)),
            "geomPtStart": lambda n : setattr(self, 'geom_pt_start', n.get_object_value(Pt3D)),
            "haunchEnd": lambda n : setattr(self, 'haunch_end', n.get_object_value(HaunchProperties)),
            "haunchStart": lambda n : setattr(self, 'haunch_start', n.get_object_value(HaunchProperties)),
            "inertiaProperties": lambda n : setattr(self, 'inertia_properties', n.get_object_value(LinearElementInnertia)),
            "initialConstraintProperties": lambda n : setattr(self, 'initial_constraint_properties', n.get_object_value(InitialConstraint)),
            "linearElementType": lambda n : setattr(self, 'linear_element_type', n.get_enum_value(LinearElementFEMType_API)),
            "loadAreaLoadTransferProperties": lambda n : setattr(self, 'load_area_load_transfer_properties', n.get_object_value(LinearLoadAreaLoadTransfer)),
            "material": lambda n : setattr(self, 'material', n.get_object_value(EID)),
            "relaxationElastique": lambda n : setattr(self, 'relaxation_elastique', n.get_object_value(ConnectionElastique)),
            "relaxationTotale": lambda n : setattr(self, 'relaxation_totale', n.get_object_value(ConnectionTotale)),
            "section": lambda n : setattr(self, 'section', n.get_object_value(EID)),
            "sectionExcentration": lambda n : setattr(self, 'section_excentration', n.get_object_value(SectionOffsetStyle)),
            "sectionOrientationAngle": lambda n : setattr(self, 'section_orientation_angle', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_bool_value("autoMesh", self.auto_mesh)
        writer.write_object_value("clipping", self.clipping)
        writer.write_object_value("detailedMeshProperties", self.detailed_mesh_properties)
        writer.write_bool_value("elementActive", self.element_active)
        writer.write_bool_value("extendIntoWall", self.extend_into_wall)
        writer.write_enum_value("generalBeamType", self.general_beam_type)
        writer.write_object_value("geomPtEnd", self.geom_pt_end)
        writer.write_object_value("geomPtStart", self.geom_pt_start)
        writer.write_object_value("haunchEnd", self.haunch_end)
        writer.write_object_value("haunchStart", self.haunch_start)
        writer.write_object_value("inertiaProperties", self.inertia_properties)
        writer.write_object_value("initialConstraintProperties", self.initial_constraint_properties)
        writer.write_enum_value("linearElementType", self.linear_element_type)
        writer.write_object_value("loadAreaLoadTransferProperties", self.load_area_load_transfer_properties)
        writer.write_object_value("material", self.material)
        writer.write_object_value("relaxationElastique", self.relaxation_elastique)
        writer.write_object_value("relaxationTotale", self.relaxation_totale)
        writer.write_object_value("section", self.section)
        writer.write_object_value("sectionExcentration", self.section_excentration)
        writer.write_float_value("sectionOrientationAngle", self.section_orientation_angle)
        writer.write_additional_data_value(self.additional_data)
    

