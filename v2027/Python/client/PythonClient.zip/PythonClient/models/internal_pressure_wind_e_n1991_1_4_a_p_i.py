from enum import Enum

class InternalPressure_Wind_EN1991_1_4_API(str, Enum):
    WIND_SURPRESSION = "WIND_SURPRESSION",
    WIND_DEPRESSION = "WIND_DEPRESSION",
    WIND_PRESSURE_COEFF = "WIND_PRESSURE_COEFF",

