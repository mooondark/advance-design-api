from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .e_i_d import EID
    from .query_info_model import QueryInfoModel

from .query_info_model import QueryInfoModel

@dataclass
class QueryInfoLoadCase(QueryInfoModel, AdditionalDataHolder, Parsable):
    """
    Query definition to extract the list of loads that are on a specific case (CaseFamilyId).
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Load case family ID to query.
    case_family_id: Optional[EID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> QueryInfoLoadCase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: QueryInfoLoadCase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return QueryInfoLoadCase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .e_i_d import EID
        from .query_info_model import QueryInfoModel

        from .e_i_d import EID
        from .query_info_model import QueryInfoModel

        fields: dict[str, Callable[[Any], None]] = {
            "caseFamilyId": lambda n : setattr(self, 'case_family_id', n.get_object_value(EID)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("caseFamilyId", self.case_family_id)
        writer.write_additional_data_value(self.additional_data)
    

