from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .function import Function

@dataclass
class SpectrumDefinitions(Parsable):
    """
    Response spectrum definition for Seismic CBN
    """
    # Function data referenceType: som.FunctionThis property holds the function definition for temporal loading.Set to null to allow engine defaults
    horizontal_spectrum_x: Optional[Function] = None
    # Function data referenceType: som.FunctionThis property holds the function definition for temporal loading.Set to null to allow engine defaults
    horizontal_spectrum_y: Optional[Function] = None
    # Function data referenceType: som.FunctionThis property holds the function definition for temporal loading.Set to null to allow engine defaults
    vertical_spectrum: Optional[Function] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SpectrumDefinitions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SpectrumDefinitions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SpectrumDefinitions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .function import Function

        from .function import Function

        fields: dict[str, Callable[[Any], None]] = {
            "horizontalSpectrumX": lambda n : setattr(self, 'horizontal_spectrum_x', n.get_object_value(Function)),
            "horizontalSpectrumY": lambda n : setattr(self, 'horizontal_spectrum_y', n.get_object_value(Function)),
            "verticalSpectrum": lambda n : setattr(self, 'vertical_spectrum', n.get_object_value(Function)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("horizontalSpectrumX", self.horizontal_spectrum_x)
        writer.write_object_value("horizontalSpectrumY", self.horizontal_spectrum_y)
        writer.write_object_value("verticalSpectrum", self.vertical_spectrum)
    

