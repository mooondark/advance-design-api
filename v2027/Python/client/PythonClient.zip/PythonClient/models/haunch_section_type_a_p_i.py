from enum import Enum

class HaunchSectionType_API(str, Enum):
    Identical = "identical",
    Suivant = "suivant",
    Precedent = "precedent",
    Imposee = "imposee",

