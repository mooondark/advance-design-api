from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .advanced_restraints_diagram_definitions import AdvancedRestraintsDiagramDefinitions
    from .advanced_restraints_options import AdvancedRestraintsOptions
    from .family_support_punctual import FamilySupportPunctual

from .family_support_punctual import FamilySupportPunctual

@dataclass
class ElementAdvancedPunctualSupport(FamilySupportPunctual, AdditionalDataHolder, Parsable):
    """
    Element Advanced Punctual Support (nonlinear/diagram per DOF)
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Advanced restraints diagram definitions, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    restraints_diagrams: Optional[AdvancedRestraintsDiagramDefinitions] = None
    # Advanced restraints optionsUnit: no unit Default value : optional nullable object
    restraints_options: Optional[AdvancedRestraintsOptions] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementAdvancedPunctualSupport:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementAdvancedPunctualSupport
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementAdvancedPunctualSupport()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .advanced_restraints_diagram_definitions import AdvancedRestraintsDiagramDefinitions
        from .advanced_restraints_options import AdvancedRestraintsOptions
        from .family_support_punctual import FamilySupportPunctual

        from .advanced_restraints_diagram_definitions import AdvancedRestraintsDiagramDefinitions
        from .advanced_restraints_options import AdvancedRestraintsOptions
        from .family_support_punctual import FamilySupportPunctual

        fields: dict[str, Callable[[Any], None]] = {
            "restraintsDiagrams": lambda n : setattr(self, 'restraints_diagrams', n.get_object_value(AdvancedRestraintsDiagramDefinitions)),
            "restraintsOptions": lambda n : setattr(self, 'restraints_options', n.get_object_value(AdvancedRestraintsOptions)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("restraintsDiagrams", self.restraints_diagrams)
        writer.write_object_value("restraintsOptions", self.restraints_options)
        writer.write_additional_data_value(self.additional_data)
    

