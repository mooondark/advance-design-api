from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .exposure_snow_a_s_c_e722_a_p_i import Exposure_SnowASCE722_API
    from .risk_category_snow_a_s_c_e722_a_p_i import RiskCategory_SnowASCE722_API
    from .snow_zone_a_s_c_e722_a_p_i import SnowZone_ASCE722_API
    from .terrain_category_snow_a_s_c_e722_a_p_i import TerrainCategory_SnowASCE722_API
    from .thermal_factor_ct_snow_a_s_c_e722_a_p_i import ThermalFactorCt_SnowASCE722_API

@dataclass
class ImplantationSnowASCE722(Parsable):
    """
    Implantation parameters for Snow ASCE 7-22 / IBC
    """
    from .thermal_factor_ct_snow_a_s_c_e722_a_p_i import ThermalFactorCt_SnowASCE722_API

    # Thermal factor CtUnit: -Default: SNOWIBCSn2015_CT_10 (1.0)
    ct: Optional[ThermalFactorCt_SnowASCE722_API] = ThermalFactorCt_SnowASCE722_API("SNOWIBCSn2015_CT_10")
    from .exposure_snow_a_s_c_e722_a_p_i import Exposure_SnowASCE722_API

    # Exposure conditionUnit: -Default: SNOWIBCSn2015_EXPOSURE_PARTIALLY
    exposure: Optional[Exposure_SnowASCE722_API] = Exposure_SnowASCE722_API("SNOWIBCSn2015_EXPOSURE_PARTIALLY")
    from .risk_category_snow_a_s_c_e722_a_p_i import RiskCategory_SnowASCE722_API

    # Risk categoryUnit: -Default: CLIMATIC_IBC2015_RISK_I
    risk_category: Optional[RiskCategory_SnowASCE722_API] = RiskCategory_SnowASCE722_API("CLIMATIC_IBC2015_RISK_I")
    from .snow_zone_a_s_c_e722_a_p_i import SnowZone_ASCE722_API

    # Snow zoneUnit: -Default: GRCG_ASCE_ZONE_0_OTHER
    snow_zone: Optional[SnowZone_ASCE722_API] = SnowZone_ASCE722_API("GRCG_ASCE_ZONE_0_OTHER")
    from .terrain_category_snow_a_s_c_e722_a_p_i import TerrainCategory_SnowASCE722_API

    # Terrain categoryUnit: -Default: SNOWIBCSn2015_TERRAIN_B
    terrain_category: Optional[TerrainCategory_SnowASCE722_API] = TerrainCategory_SnowASCE722_API("SNOWIBCSn2015_TERRAIN_B")
    # AltitudeUnit: Length (m or ft)Default: 0.0
    altitude: Optional[float] = None
    # Ground snow load PgUnit: Pressure (Pa or psf)Default: 2395
    pg: Optional[float] = None
    # Winter wind parameter W2 - Percent time wind speed is above 10 mph (4.6 m/s) during winter (October through April)Unit: Dimensionless (0 to 1)Default: GRCG_ASCE_WINTER_WIND_PARAMETRE_W2 (typically 0.5)
    w2: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImplantationSnowASCE722:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImplantationSnowASCE722
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImplantationSnowASCE722()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .exposure_snow_a_s_c_e722_a_p_i import Exposure_SnowASCE722_API
        from .risk_category_snow_a_s_c_e722_a_p_i import RiskCategory_SnowASCE722_API
        from .snow_zone_a_s_c_e722_a_p_i import SnowZone_ASCE722_API
        from .terrain_category_snow_a_s_c_e722_a_p_i import TerrainCategory_SnowASCE722_API
        from .thermal_factor_ct_snow_a_s_c_e722_a_p_i import ThermalFactorCt_SnowASCE722_API

        from .exposure_snow_a_s_c_e722_a_p_i import Exposure_SnowASCE722_API
        from .risk_category_snow_a_s_c_e722_a_p_i import RiskCategory_SnowASCE722_API
        from .snow_zone_a_s_c_e722_a_p_i import SnowZone_ASCE722_API
        from .terrain_category_snow_a_s_c_e722_a_p_i import TerrainCategory_SnowASCE722_API
        from .thermal_factor_ct_snow_a_s_c_e722_a_p_i import ThermalFactorCt_SnowASCE722_API

        fields: dict[str, Callable[[Any], None]] = {
            "altitude": lambda n : setattr(self, 'altitude', n.get_float_value()),
            "ct": lambda n : setattr(self, 'ct', n.get_enum_value(ThermalFactorCt_SnowASCE722_API)),
            "exposure": lambda n : setattr(self, 'exposure', n.get_enum_value(Exposure_SnowASCE722_API)),
            "pg": lambda n : setattr(self, 'pg', n.get_float_value()),
            "riskCategory": lambda n : setattr(self, 'risk_category', n.get_enum_value(RiskCategory_SnowASCE722_API)),
            "snowZone": lambda n : setattr(self, 'snow_zone', n.get_enum_value(SnowZone_ASCE722_API)),
            "terrainCategory": lambda n : setattr(self, 'terrain_category', n.get_enum_value(TerrainCategory_SnowASCE722_API)),
            "w2": lambda n : setattr(self, 'w2', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("altitude", self.altitude)
        writer.write_enum_value("ct", self.ct)
        writer.write_enum_value("exposure", self.exposure)
        writer.write_float_value("pg", self.pg)
        writer.write_enum_value("riskCategory", self.risk_category)
        writer.write_enum_value("snowZone", self.snow_zone)
        writer.write_enum_value("terrainCategory", self.terrain_category)
        writer.write_float_value("w2", self.w2)
    

