from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .detailed_mesh_spacing_option import DetailedMeshSpacingOption

@dataclass
class DetailedMeshOnSegment(Parsable):
    """
    Detailed mesh on segment options
    """
    from .detailed_mesh_spacing_option import DetailedMeshSpacingOption

    # Method of distribution of finite elementsDefault value : DetailedMeshSpacingOption.uniform
    spacing_option: Optional[DetailedMeshSpacingOption] = DetailedMeshSpacingOption("uniform")
    # Number of elementsUnit: no unitDefault value : 1
    number_of_elements: Optional[int] = None
    # Expected mesh size (0 corresponds to the global mesh size);Unit: mDefault value : 1.0
    size_of_elements: Optional[float] = None
    # Secondary mesh size, used for non-uniform distribution;Unit: mDefault value : 0.0
    spacing_factor: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DetailedMeshOnSegment:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DetailedMeshOnSegment
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DetailedMeshOnSegment()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .detailed_mesh_spacing_option import DetailedMeshSpacingOption

        from .detailed_mesh_spacing_option import DetailedMeshSpacingOption

        fields: dict[str, Callable[[Any], None]] = {
            "numberOfElements": lambda n : setattr(self, 'number_of_elements', n.get_int_value()),
            "sizeOfElements": lambda n : setattr(self, 'size_of_elements', n.get_float_value()),
            "spacingFactor": lambda n : setattr(self, 'spacing_factor', n.get_float_value()),
            "spacingOption": lambda n : setattr(self, 'spacing_option', n.get_enum_value(DetailedMeshSpacingOption)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("numberOfElements", self.number_of_elements)
        writer.write_float_value("sizeOfElements", self.size_of_elements)
        writer.write_float_value("spacingFactor", self.spacing_factor)
        writer.write_enum_value("spacingOption", self.spacing_option)
    

