from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .calcul_of_turbulence_factor_k_l_wind_e_n1991_1_4_a_p_i import CalculOfTurbulenceFactorKL_Wind_EN1991_1_4_API
    from .correlation_coefficient_type_wind_e_n1991_1_4_a_p_i import CorrelationCoefficientType_Wind_EN1991_1_4_API
    from .cs_cd_calc_mode_wind_e_n1991_1_4_a_p_i import CsCdCalcMode_Wind_EN1991_1_4_API
    from .placement_type_wind_e_n1991_1_4_a_p_i import PlacementType_Wind_EN1991_1_4_API

@dataclass
class BasePressureParameters_Wind_EN1991_1_4(Parsable):
    """
    Base pressure parameters for Wind EN 1991-1-4
    """
    from .calcul_of_turbulence_factor_k_l_wind_e_n1991_1_4_a_p_i import CalculOfTurbulenceFactorKL_Wind_EN1991_1_4_API

    # Calculation of turbulence factor KLUnit: -Default: WINDEC1_EN1991_1_4_KLFORMULA_OTHER
    calcul_of_turbulence_factor_k_l: Optional[CalculOfTurbulenceFactorKL_Wind_EN1991_1_4_API] = CalculOfTurbulenceFactorKL_Wind_EN1991_1_4_API("WINDEC1_EN1991_1_4_KLFORMULA_OTHER")
    from .correlation_coefficient_type_wind_e_n1991_1_4_a_p_i import CorrelationCoefficientType_Wind_EN1991_1_4_API

    # Correlation coefficient typeUnit: -Default: CORREL_AUTO
    correlation_coefficient_type: Optional[CorrelationCoefficientType_Wind_EN1991_1_4_API] = CorrelationCoefficientType_Wind_EN1991_1_4_API("CORREL_AUTO")
    from .cs_cd_calc_mode_wind_e_n1991_1_4_a_p_i import CsCdCalcMode_Wind_EN1991_1_4_API

    # Cs*Cd calculation modeUnit: -Default: CS_CD_AUTO
    cs_cd_calc_mode: Optional[CsCdCalcMode_Wind_EN1991_1_4_API] = CsCdCalcMode_Wind_EN1991_1_4_API("CS_CD_AUTO")
    from .placement_type_wind_e_n1991_1_4_a_p_i import PlacementType_Wind_EN1991_1_4_API

    # Placement type (terrain category)Unit: -Default: TERRAIN_CATEGORY_II
    placement_type: Optional[PlacementType_Wind_EN1991_1_4_API] = PlacementType_Wind_EN1991_1_4_API("TERRAIN_CATEGORY_II")
    # Direction coefficient cDirUnit: -Default: 1.0
    c_dir: Optional[float] = None
    # Season coefficient cSeasUnit: -Default: 1.0
    c_seas: Optional[float] = None
    # Correlation coefficient KdcUnit: -Default: 1.0
    correlation_coefficient_kdc: Optional[float] = None
    # Cs*Cd valueUnit: -Default: 1.0
    cs_cd_val: Optional[float] = None
    # Cs*Cd minimum valueUnit: -Default: 1.0
    cs_cd_val_min: Optional[float] = None
    # Logarithmic decrement deltaUnit: -Default: 0.1
    delta: Optional[float] = None
    #  Height of structure base considered from the groundUnit: mDefault: 0.0
    height_of_structure_base: Optional[float] = None
    # Height of structure base max for all computationsUnit: -Default: false
    height_of_structure_base_max_for_all_computations: Optional[bool] = None
    # Terrain factor KrUnit: -Default: 1.0
    kr: Optional[float] = None
    # Fundamental frequency NUnit: HzDefault: 0.0
    n: Optional[float] = None
    # Automatic N calculationUnit: -Default: true
    n_auto: Optional[bool] = None
    # Scaffolding factor phiUnit: -Default: 0.4
    phi_scaffolding: Optional[float] = None
    # Automatic phi scaffoldingUnit: -Default: true
    phi_scaffolding_auto: Optional[bool] = None
    # Wind pressureUnit: PaDefault: 0.0
    pressure: Optional[float] = None
    # Roughness length z0Unit: mDefault: 1.0
    rig_length: Optional[float] = None
    # Wind speedUnit: m/sDefault: 0.0
    speed: Optional[float] = None
    # Turbulence factor KLUnit: -Default: 1.0
    turbulence_factor_k_l: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> BasePressureParameters_Wind_EN1991_1_4:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: BasePressureParameters_Wind_EN1991_1_4
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return BasePressureParameters_Wind_EN1991_1_4()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .calcul_of_turbulence_factor_k_l_wind_e_n1991_1_4_a_p_i import CalculOfTurbulenceFactorKL_Wind_EN1991_1_4_API
        from .correlation_coefficient_type_wind_e_n1991_1_4_a_p_i import CorrelationCoefficientType_Wind_EN1991_1_4_API
        from .cs_cd_calc_mode_wind_e_n1991_1_4_a_p_i import CsCdCalcMode_Wind_EN1991_1_4_API
        from .placement_type_wind_e_n1991_1_4_a_p_i import PlacementType_Wind_EN1991_1_4_API

        from .calcul_of_turbulence_factor_k_l_wind_e_n1991_1_4_a_p_i import CalculOfTurbulenceFactorKL_Wind_EN1991_1_4_API
        from .correlation_coefficient_type_wind_e_n1991_1_4_a_p_i import CorrelationCoefficientType_Wind_EN1991_1_4_API
        from .cs_cd_calc_mode_wind_e_n1991_1_4_a_p_i import CsCdCalcMode_Wind_EN1991_1_4_API
        from .placement_type_wind_e_n1991_1_4_a_p_i import PlacementType_Wind_EN1991_1_4_API

        fields: dict[str, Callable[[Any], None]] = {
            "cDir": lambda n : setattr(self, 'c_dir', n.get_float_value()),
            "cSeas": lambda n : setattr(self, 'c_seas', n.get_float_value()),
            "calculOfTurbulenceFactorKL": lambda n : setattr(self, 'calcul_of_turbulence_factor_k_l', n.get_enum_value(CalculOfTurbulenceFactorKL_Wind_EN1991_1_4_API)),
            "correlationCoefficientKdc": lambda n : setattr(self, 'correlation_coefficient_kdc', n.get_float_value()),
            "correlationCoefficientType": lambda n : setattr(self, 'correlation_coefficient_type', n.get_enum_value(CorrelationCoefficientType_Wind_EN1991_1_4_API)),
            "csCdCalcMode": lambda n : setattr(self, 'cs_cd_calc_mode', n.get_enum_value(CsCdCalcMode_Wind_EN1991_1_4_API)),
            "csCdVal": lambda n : setattr(self, 'cs_cd_val', n.get_float_value()),
            "csCdValMin": lambda n : setattr(self, 'cs_cd_val_min', n.get_float_value()),
            "delta": lambda n : setattr(self, 'delta', n.get_float_value()),
            "heightOfStructureBase": lambda n : setattr(self, 'height_of_structure_base', n.get_float_value()),
            "heightOfStructureBaseMaxForAllComputations": lambda n : setattr(self, 'height_of_structure_base_max_for_all_computations', n.get_bool_value()),
            "kr": lambda n : setattr(self, 'kr', n.get_float_value()),
            "n": lambda n : setattr(self, 'n', n.get_float_value()),
            "nAuto": lambda n : setattr(self, 'n_auto', n.get_bool_value()),
            "phiScaffolding": lambda n : setattr(self, 'phi_scaffolding', n.get_float_value()),
            "phiScaffoldingAuto": lambda n : setattr(self, 'phi_scaffolding_auto', n.get_bool_value()),
            "placementType": lambda n : setattr(self, 'placement_type', n.get_enum_value(PlacementType_Wind_EN1991_1_4_API)),
            "pressure": lambda n : setattr(self, 'pressure', n.get_float_value()),
            "rigLength": lambda n : setattr(self, 'rig_length', n.get_float_value()),
            "speed": lambda n : setattr(self, 'speed', n.get_float_value()),
            "turbulenceFactorKL": lambda n : setattr(self, 'turbulence_factor_k_l', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("cDir", self.c_dir)
        writer.write_float_value("cSeas", self.c_seas)
        writer.write_enum_value("calculOfTurbulenceFactorKL", self.calcul_of_turbulence_factor_k_l)
        writer.write_float_value("correlationCoefficientKdc", self.correlation_coefficient_kdc)
        writer.write_enum_value("correlationCoefficientType", self.correlation_coefficient_type)
        writer.write_enum_value("csCdCalcMode", self.cs_cd_calc_mode)
        writer.write_float_value("csCdVal", self.cs_cd_val)
        writer.write_float_value("csCdValMin", self.cs_cd_val_min)
        writer.write_float_value("delta", self.delta)
        writer.write_float_value("heightOfStructureBase", self.height_of_structure_base)
        writer.write_bool_value("heightOfStructureBaseMaxForAllComputations", self.height_of_structure_base_max_for_all_computations)
        writer.write_float_value("kr", self.kr)
        writer.write_float_value("n", self.n)
        writer.write_bool_value("nAuto", self.n_auto)
        writer.write_float_value("phiScaffolding", self.phi_scaffolding)
        writer.write_bool_value("phiScaffoldingAuto", self.phi_scaffolding_auto)
        writer.write_enum_value("placementType", self.placement_type)
        writer.write_float_value("pressure", self.pressure)
        writer.write_float_value("rigLength", self.rig_length)
        writer.write_float_value("speed", self.speed)
        writer.write_float_value("turbulenceFactorKL", self.turbulence_factor_k_l)
    

