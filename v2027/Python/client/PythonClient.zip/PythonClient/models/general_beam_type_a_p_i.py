from enum import Enum

class GeneralBeamType_API(str, Enum):
    Bar = "bar",
    BeamWStandardBending = "beamWStandardBending",
    Sbeam = "sbeam",
    Variablebeam = "variablebeam",
    Tie = "tie",
    Strut = "strut",
    Cable = "cable",
    Rigid = "rigid",
    CompositeBeamSimpleBeam = "CompositeBeamSimpleBeam",
    CompositeBeamSbeam = "CompositeBeamSbeam",
    CompositeBeamVariable = "CompositeBeamVariable",

