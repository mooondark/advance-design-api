from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .material import Material
    from .material_behaviour_type import MaterialBehaviourType

from .material import Material

@dataclass
class MaterialWoodNorthAmerica(Material, AdditionalDataHolder, Parsable):
    """
    Wood material properties (North America)
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .material_behaviour_type import MaterialBehaviourType

    # Material behavior type Default value: MaterialBehaviourType.isotropic_behavior
    behavior_type: Optional[MaterialBehaviourType] = MaterialBehaviourType("isotropic_behavior")
    # Thermal dilatation (α)Unit: 1/°CDefault value: 0.000005 (5E-6)
    alpha: Optional[float] = None
    # Burning ratio coefficient (used for fire design)Unit: mm/minDefault value: 0.7
    burning_ratio_coeff: Optional[float] = None
    # Color (angle in degrees)Unit: degreesDefault value: 1.2566370614359172 (72 degrees in radians)
    color: Optional[float] = None
    # Damping coefficient (% of critical damping)Unit: no unitDefault value: 0.05 (5%)
    damping: Optional[float] = None
    # Longitudinal rigidity (E)Unit: PaDefault value: 11000000000.0 (11 GPa)
    e: Optional[float] = None
    # 5th percentile Young's modulus (E0.05)Unit: PaDefault value: 7400000000.0 (7.4 GPa)
    e0_05: Optional[float] = None
    # Characteristic compressive strength parallel to grain (fc,0,k)Unit: PaDefault value: 21000000.0 (21 MPa)
    fc0k: Optional[float] = None
    # Characteristic compressive strength perpendicular to grain (fc,90,k)Unit: PaDefault value: 2500000.0 (2.5 MPa)
    fc90k: Optional[float] = None
    # Characteristic bending strength (fm,k)Unit: PaDefault value: 24000000.0 (24 MPa)
    fmk: Optional[float] = None
    # Characteristic tensile strength parallel to grain (ft,0,k)Unit: PaDefault value: 14000000.0 (14 MPa)
    ft0k: Optional[float] = None
    # Characteristic tensile strength perpendicular to grain (ft,90,k)Unit: PaDefault value: 400000.0 (0.4 MPa)
    ft90k: Optional[float] = None
    # Characteristic shear strength (fv,k)Unit: PaDefault value: 2500000.0 (2.5 MPa)
    fvk: Optional[float] = None
    # Transverse rigidity (G)Unit: PaDefault value: 690000000.0 (690 MPa)
    g: Optional[float] = None
    # 5th percentile shear modulus (G0.05)Unit: PaDefault value: 460000000.0 (460 MPa)
    g0_05: Optional[float] = None
    # Partial factor for material properties (γM)Unit: no unitDefault value: 1.3
    gamma_m: Optional[float] = None
    # Poisson's ratio (ν)Unit: no unitDefault value: 0.3
    nu: Optional[float] = None
    # Density (ρ)Unit: kg/m³Default value: 380.0
    ro: Optional[float] = None
    # Elastic limit stress (σe)Unit: PaDefault value: 24000000.0 (24 MPa)
    sigma_e: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> MaterialWoodNorthAmerica:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: MaterialWoodNorthAmerica
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return MaterialWoodNorthAmerica()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .material import Material
        from .material_behaviour_type import MaterialBehaviourType

        from .material import Material
        from .material_behaviour_type import MaterialBehaviourType

        fields: dict[str, Callable[[Any], None]] = {
            "alpha": lambda n : setattr(self, 'alpha', n.get_float_value()),
            "behaviorType": lambda n : setattr(self, 'behavior_type', n.get_enum_value(MaterialBehaviourType)),
            "burningRatioCoeff": lambda n : setattr(self, 'burning_ratio_coeff', n.get_float_value()),
            "color": lambda n : setattr(self, 'color', n.get_float_value()),
            "damping": lambda n : setattr(self, 'damping', n.get_float_value()),
            "e": lambda n : setattr(self, 'e', n.get_float_value()),
            "e0_05": lambda n : setattr(self, 'e0_05', n.get_float_value()),
            "fc0k": lambda n : setattr(self, 'fc0k', n.get_float_value()),
            "fc90k": lambda n : setattr(self, 'fc90k', n.get_float_value()),
            "fmk": lambda n : setattr(self, 'fmk', n.get_float_value()),
            "ft0k": lambda n : setattr(self, 'ft0k', n.get_float_value()),
            "ft90k": lambda n : setattr(self, 'ft90k', n.get_float_value()),
            "fvk": lambda n : setattr(self, 'fvk', n.get_float_value()),
            "g": lambda n : setattr(self, 'g', n.get_float_value()),
            "g0_05": lambda n : setattr(self, 'g0_05', n.get_float_value()),
            "gammaM": lambda n : setattr(self, 'gamma_m', n.get_float_value()),
            "nu": lambda n : setattr(self, 'nu', n.get_float_value()),
            "ro": lambda n : setattr(self, 'ro', n.get_float_value()),
            "sigmaE": lambda n : setattr(self, 'sigma_e', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_float_value("alpha", self.alpha)
        writer.write_enum_value("behaviorType", self.behavior_type)
        writer.write_float_value("burningRatioCoeff", self.burning_ratio_coeff)
        writer.write_float_value("color", self.color)
        writer.write_float_value("damping", self.damping)
        writer.write_float_value("e", self.e)
        writer.write_float_value("e0_05", self.e0_05)
        writer.write_float_value("fc0k", self.fc0k)
        writer.write_float_value("fc90k", self.fc90k)
        writer.write_float_value("fmk", self.fmk)
        writer.write_float_value("ft0k", self.ft0k)
        writer.write_float_value("ft90k", self.ft90k)
        writer.write_float_value("fvk", self.fvk)
        writer.write_float_value("g", self.g)
        writer.write_float_value("g0_05", self.g0_05)
        writer.write_float_value("gammaM", self.gamma_m)
        writer.write_float_value("nu", self.nu)
        writer.write_float_value("ro", self.ro)
        writer.write_float_value("sigmaE", self.sigma_e)
        writer.write_additional_data_value(self.additional_data)
    

