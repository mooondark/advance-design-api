from enum import Enum

class TopographicCategoryNTC_API(str, Enum):
    T1 = "T1",
    T2 = "T2",
    T3 = "T3",
    T4 = "T4",

