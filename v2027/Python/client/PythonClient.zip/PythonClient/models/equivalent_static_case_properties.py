from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EquivalentStaticCaseProperties(Parsable):
    """
    Time interval definition for temporal analysis
    """
    # Start time for temporal analysisUnit: s (seconds)Default: 0.0
    begin: Optional[float] = None
    # Static case type for result extraction0 = CASE_MAX_DISPLACEMENT1 = CASE_INSTANT_IMPOSE2 = CASE_INTERVALS_REGULARUnit: dimensionlessDefault: 0 (CASE_MAX_DISPLACEMENT)
    case: Optional[int] = None
    # End time for temporal analysisUnit: s (seconds)Default: 10.0
    end: Optional[float] = None
    # Time interval step for temporal analysisUnit: s (seconds)Default: 0.1
    interval: Optional[float] = None
    # Interval for T in regular intervals caseUnit: s (seconds)Default: 1.0
    interval_t: Optional[float] = None
    # Type of result to extract0 = RESULTAT_DISPLACEMENTUnit: dimensionlessDefault: 0 (RESULTAT_DISPLACEMENT)
    result_type: Optional[int] = None
    # Number of time subdivisionsUnit: dimensionlessDefault: 10
    subdivision_of_time: Optional[int] = None
    # Value of T for instant impose caseUnit: s (seconds)Default: 1.0
    value_t: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EquivalentStaticCaseProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EquivalentStaticCaseProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EquivalentStaticCaseProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "begin": lambda n : setattr(self, 'begin', n.get_float_value()),
            "case": lambda n : setattr(self, 'case', n.get_int_value()),
            "end": lambda n : setattr(self, 'end', n.get_float_value()),
            "interval": lambda n : setattr(self, 'interval', n.get_float_value()),
            "intervalT": lambda n : setattr(self, 'interval_t', n.get_float_value()),
            "resultType": lambda n : setattr(self, 'result_type', n.get_int_value()),
            "subdivisionOfTime": lambda n : setattr(self, 'subdivision_of_time', n.get_int_value()),
            "valueT": lambda n : setattr(self, 'value_t', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("begin", self.begin)
        writer.write_int_value("case", self.case)
        writer.write_float_value("end", self.end)
        writer.write_float_value("interval", self.interval)
        writer.write_float_value("intervalT", self.interval_t)
        writer.write_int_value("resultType", self.result_type)
        writer.write_int_value("subdivisionOfTime", self.subdivision_of_time)
        writer.write_float_value("valueT", self.value_t)
    

