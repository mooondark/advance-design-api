from enum import Enum

class WindDirection_Wind_EN1991_1_4_API(str, Enum):
    WIND_X_PLUS = "WIND_X_PLUS",
    WIND_X_MINUS = "WIND_X_MINUS",
    WIND_Y_PLUS = "WIND_Y_PLUS",
    WIND_Y_MINUS = "WIND_Y_MINUS",

