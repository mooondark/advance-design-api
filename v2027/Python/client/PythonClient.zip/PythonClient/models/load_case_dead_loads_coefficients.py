from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LoadCaseDeadLoadsCoefficients(Parsable):
    """
    Dead loads (self weight) favourable / unfavourable partial safety factors container (dimensionless).
    """
    # Maximum coefficient for American / other code combinations (if applicable)Unit : -Default value : 1.0
    coeff_max: Optional[float] = None
    # Medium coefficient for American / other code combinations (if applicable)Unit : -Default value : 1.0
    coeff_med: Optional[float] = None
    # Minimum coefficient for American / other code combinations (if applicable)Unit : -Default value : 1.0
    coeff_min: Optional[float] = None
    # Unfavourable partial safety factor for gravity (EQU combinations)Unit : -Default value : 1.10 (typical value – change if national annex differs)
    gamma_defav_e_q_u: Optional[float] = None
    # Unfavourable partial safety factor for gravity (STR/GEO combinations)Unit : -Default value : 1.35 (set to 1.35 typical Eurocode value – change if needed)
    gamma_defav_s_t_r_g_e_o: Optional[float] = None
    # Favourable partial safety factor for gravity (EQU combinations)Unit : -Default value : 1.0
    gamma_fav_e_q_u: Optional[float] = None
    # Favourable partial safety factor for gravity (STR/GEO combinations)Unit : -Default value : 1.0
    gamma_fav_s_t_r_g_e_o: Optional[float] = None
    # Gravity load category (code dependent – 0 standard, other values implementation specific)Unit : -Default value : 0
    gravity_category: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseDeadLoadsCoefficients:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseDeadLoadsCoefficients
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseDeadLoadsCoefficients()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "coeffMax": lambda n : setattr(self, 'coeff_max', n.get_float_value()),
            "coeffMed": lambda n : setattr(self, 'coeff_med', n.get_float_value()),
            "coeffMin": lambda n : setattr(self, 'coeff_min', n.get_float_value()),
            "gammaDefavEQU": lambda n : setattr(self, 'gamma_defav_e_q_u', n.get_float_value()),
            "gammaDefavSTRGEO": lambda n : setattr(self, 'gamma_defav_s_t_r_g_e_o', n.get_float_value()),
            "gammaFavEQU": lambda n : setattr(self, 'gamma_fav_e_q_u', n.get_float_value()),
            "gammaFavSTRGEO": lambda n : setattr(self, 'gamma_fav_s_t_r_g_e_o', n.get_float_value()),
            "gravityCategory": lambda n : setattr(self, 'gravity_category', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("coeffMax", self.coeff_max)
        writer.write_float_value("coeffMed", self.coeff_med)
        writer.write_float_value("coeffMin", self.coeff_min)
        writer.write_float_value("gammaDefavEQU", self.gamma_defav_e_q_u)
        writer.write_float_value("gammaDefavSTRGEO", self.gamma_defav_s_t_r_g_e_o)
        writer.write_float_value("gammaFavEQU", self.gamma_fav_e_q_u)
        writer.write_float_value("gammaFavSTRGEO", self.gamma_fav_s_t_r_g_e_o)
        writer.write_int_value("gravityCategory", self.gravity_category)
    

