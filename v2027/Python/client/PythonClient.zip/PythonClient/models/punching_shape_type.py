from enum import Enum

class PunchingShapeType(str, Enum):
    Rectangular = "Rectangular",
    Square = "Square",
    Circular = "Circular",

