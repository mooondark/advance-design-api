from enum import Enum

class TypeStructure_API(str, Enum):
    StructureResistMomentFrame = "StructureResistMomentFrame",
    StructureResistShearWall = "StructureResistShearWall",
    StructureResistBracedFrame = "StructureResistBracedFrame",
    StructureResistDualSystem = "StructureResistDualSystem",
    StructureResistOther = "StructureResistOther",

