from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResPlanarStresses(Parsable):
    """
    PlanarStresses result container
    """
    # Principal stress angle Alpha at inferior face
    alpha_inf: Optional[float] = None
    # Principal stress angle Alpha at mid-plane
    alpha_mid: Optional[float] = None
    # Principal stress angle Alpha at top face
    alpha_top: Optional[float] = None
    # Supplemental principal stress S1 at inferior face
    res_planar_stresses_s1_inf: Optional[float] = None
    # Supplemental principal stress S1 at mid-plane
    res_planar_stresses_s1_mid: Optional[float] = None
    # Supplemental principal stress S1 at top face
    res_planar_stresses_s1_top: Optional[float] = None
    # Supplemental principal stress S2 at inferior face
    res_planar_stresses_s2_inf: Optional[float] = None
    # Supplemental principal stress S2 at mid-plane
    res_planar_stresses_s2_mid: Optional[float] = None
    # Supplemental principal stress S2 at top face
    res_planar_stresses_s2_top: Optional[float] = None
    # Principal stress S1 at inferior face
    s1_inf: Optional[float] = None
    # Principal stress S1 at mid-plane
    s1_mid: Optional[float] = None
    # Principal stress S1 at top face
    s1_top: Optional[float] = None
    # Principal stress S2 at inferior face
    s2_inf: Optional[float] = None
    # Principal stress S2 at mid-plane
    s2_mid: Optional[float] = None
    # Principal stress S2 at top face
    s2_top: Optional[float] = None
    # Von Mises equivalent stress at inferior face
    sv_inf: Optional[float] = None
    # Von Mises equivalent stress at mid-plane
    sv_mid: Optional[float] = None
    # Von Mises equivalent stress at top face
    sv_top: Optional[float] = None
    # Normal stress Sxx at inferior face
    sxx_inf: Optional[float] = None
    # Normal stress Sxx at mid-plane
    sxx_mid: Optional[float] = None
    # Normal stress Sxx at top face
    sxx_top: Optional[float] = None
    # In-plane shear stress Sxy at inferior face
    sxy_inf: Optional[float] = None
    # In-plane shear stress Sxy at mid-plane
    sxy_mid: Optional[float] = None
    # In-plane shear stress Sxy at top face
    sxy_top: Optional[float] = None
    # Transverse shear stress Sxz at inferior face
    sxz_inf: Optional[float] = None
    # Transverse shear stress Sxz at mid-plane
    sxz_mid: Optional[float] = None
    # Transverse shear stress Sxz at top face
    sxz_top: Optional[float] = None
    # Normal stress Syy at inferior face
    syy_inf: Optional[float] = None
    # Normal stress Syy at mid-plane
    syy_mid: Optional[float] = None
    # Normal stress Syy at top face
    syy_top: Optional[float] = None
    # Transverse shear stress Syz at inferior face
    syz_inf: Optional[float] = None
    # Transverse shear stress Syz at mid-plane
    syz_mid: Optional[float] = None
    # Transverse shear stress Syz at top face
    syz_top: Optional[float] = None
    # Normal stress Szz at inferior face
    szz_inf: Optional[float] = None
    # Normal stress Szz at mid-plane
    szz_mid: Optional[float] = None
    # Normal stress Szz at top face
    szz_top: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResPlanarStresses:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResPlanarStresses
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResPlanarStresses()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "alphaInf": lambda n : setattr(self, 'alpha_inf', n.get_float_value()),
            "alphaMid": lambda n : setattr(self, 'alpha_mid', n.get_float_value()),
            "alphaTop": lambda n : setattr(self, 'alpha_top', n.get_float_value()),
            "_S1Inf": lambda n : setattr(self, 'res_planar_stresses_s1_inf', n.get_float_value()),
            "_S1Mid": lambda n : setattr(self, 'res_planar_stresses_s1_mid', n.get_float_value()),
            "_S1Top": lambda n : setattr(self, 'res_planar_stresses_s1_top', n.get_float_value()),
            "_S2Inf": lambda n : setattr(self, 'res_planar_stresses_s2_inf', n.get_float_value()),
            "_S2Mid": lambda n : setattr(self, 'res_planar_stresses_s2_mid', n.get_float_value()),
            "_S2Top": lambda n : setattr(self, 'res_planar_stresses_s2_top', n.get_float_value()),
            "s1Inf": lambda n : setattr(self, 's1_inf', n.get_float_value()),
            "s1Mid": lambda n : setattr(self, 's1_mid', n.get_float_value()),
            "s1Top": lambda n : setattr(self, 's1_top', n.get_float_value()),
            "s2Inf": lambda n : setattr(self, 's2_inf', n.get_float_value()),
            "s2Mid": lambda n : setattr(self, 's2_mid', n.get_float_value()),
            "s2Top": lambda n : setattr(self, 's2_top', n.get_float_value()),
            "svInf": lambda n : setattr(self, 'sv_inf', n.get_float_value()),
            "svMid": lambda n : setattr(self, 'sv_mid', n.get_float_value()),
            "svTop": lambda n : setattr(self, 'sv_top', n.get_float_value()),
            "sxxInf": lambda n : setattr(self, 'sxx_inf', n.get_float_value()),
            "sxxMid": lambda n : setattr(self, 'sxx_mid', n.get_float_value()),
            "sxxTop": lambda n : setattr(self, 'sxx_top', n.get_float_value()),
            "sxyInf": lambda n : setattr(self, 'sxy_inf', n.get_float_value()),
            "sxyMid": lambda n : setattr(self, 'sxy_mid', n.get_float_value()),
            "sxyTop": lambda n : setattr(self, 'sxy_top', n.get_float_value()),
            "sxzInf": lambda n : setattr(self, 'sxz_inf', n.get_float_value()),
            "sxzMid": lambda n : setattr(self, 'sxz_mid', n.get_float_value()),
            "sxzTop": lambda n : setattr(self, 'sxz_top', n.get_float_value()),
            "syyInf": lambda n : setattr(self, 'syy_inf', n.get_float_value()),
            "syyMid": lambda n : setattr(self, 'syy_mid', n.get_float_value()),
            "syyTop": lambda n : setattr(self, 'syy_top', n.get_float_value()),
            "syzInf": lambda n : setattr(self, 'syz_inf', n.get_float_value()),
            "syzMid": lambda n : setattr(self, 'syz_mid', n.get_float_value()),
            "syzTop": lambda n : setattr(self, 'syz_top', n.get_float_value()),
            "szzInf": lambda n : setattr(self, 'szz_inf', n.get_float_value()),
            "szzMid": lambda n : setattr(self, 'szz_mid', n.get_float_value()),
            "szzTop": lambda n : setattr(self, 'szz_top', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("alphaInf", self.alpha_inf)
        writer.write_float_value("alphaMid", self.alpha_mid)
        writer.write_float_value("alphaTop", self.alpha_top)
        writer.write_float_value("_S1Inf", self.res_planar_stresses_s1_inf)
        writer.write_float_value("_S1Mid", self.res_planar_stresses_s1_mid)
        writer.write_float_value("_S1Top", self.res_planar_stresses_s1_top)
        writer.write_float_value("_S2Inf", self.res_planar_stresses_s2_inf)
        writer.write_float_value("_S2Mid", self.res_planar_stresses_s2_mid)
        writer.write_float_value("_S2Top", self.res_planar_stresses_s2_top)
        writer.write_float_value("s1Inf", self.s1_inf)
        writer.write_float_value("s1Mid", self.s1_mid)
        writer.write_float_value("s1Top", self.s1_top)
        writer.write_float_value("s2Inf", self.s2_inf)
        writer.write_float_value("s2Mid", self.s2_mid)
        writer.write_float_value("s2Top", self.s2_top)
        writer.write_float_value("svInf", self.sv_inf)
        writer.write_float_value("svMid", self.sv_mid)
        writer.write_float_value("svTop", self.sv_top)
        writer.write_float_value("sxxInf", self.sxx_inf)
        writer.write_float_value("sxxMid", self.sxx_mid)
        writer.write_float_value("sxxTop", self.sxx_top)
        writer.write_float_value("sxyInf", self.sxy_inf)
        writer.write_float_value("sxyMid", self.sxy_mid)
        writer.write_float_value("sxyTop", self.sxy_top)
        writer.write_float_value("sxzInf", self.sxz_inf)
        writer.write_float_value("sxzMid", self.sxz_mid)
        writer.write_float_value("sxzTop", self.sxz_top)
        writer.write_float_value("syyInf", self.syy_inf)
        writer.write_float_value("syyMid", self.syy_mid)
        writer.write_float_value("syyTop", self.syy_top)
        writer.write_float_value("syzInf", self.syz_inf)
        writer.write_float_value("syzMid", self.syz_mid)
        writer.write_float_value("syzTop", self.syz_top)
        writer.write_float_value("szzInf", self.szz_inf)
        writer.write_float_value("szzMid", self.szz_mid)
        writer.write_float_value("szzTop", self.szz_top)
    

