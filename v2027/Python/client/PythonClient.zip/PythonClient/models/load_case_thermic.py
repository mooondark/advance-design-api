from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case import LoadCase
    from .load_case_thermic_coefficients import LoadCaseThermicCoefficients
    from .system_selection import SystemSelection
    from .temperature_field_definition import TemperatureFieldDefinition

from .load_case import LoadCase

@dataclass
class LoadCase_Thermic(LoadCase, AdditionalDataHolder, Parsable):
    """
    Thermic load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Temperature field definition (dilatation and gradients).Default value: all components set to 0.0
    field: Optional[TemperatureFieldDefinition] = None
    # System selection for applying this thermic load case to specific systems or all systems.Set to null to apply to all systems by default.
    system_selection: Optional[SystemSelection] = None
    # Thermic load coefficients for combinations.Set to null to allow engine defaults per national annex / standard.
    thermic_coefficients: Optional[LoadCaseThermicCoefficients] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_Thermic:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_Thermic
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_Thermic()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case import LoadCase
        from .load_case_thermic_coefficients import LoadCaseThermicCoefficients
        from .system_selection import SystemSelection
        from .temperature_field_definition import TemperatureFieldDefinition

        from .load_case import LoadCase
        from .load_case_thermic_coefficients import LoadCaseThermicCoefficients
        from .system_selection import SystemSelection
        from .temperature_field_definition import TemperatureFieldDefinition

        fields: dict[str, Callable[[Any], None]] = {
            "field": lambda n : setattr(self, 'field', n.get_object_value(TemperatureFieldDefinition)),
            "systemSelection": lambda n : setattr(self, 'system_selection', n.get_object_value(SystemSelection)),
            "thermicCoefficients": lambda n : setattr(self, 'thermic_coefficients', n.get_object_value(LoadCaseThermicCoefficients)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("field", self.field)
        writer.write_object_value("systemSelection", self.system_selection)
        writer.write_object_value("thermicCoefficients", self.thermic_coefficients)
        writer.write_additional_data_value(self.additional_data)
    

