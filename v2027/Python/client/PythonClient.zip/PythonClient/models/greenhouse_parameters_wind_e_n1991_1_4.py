from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .computing_probability_coeff_wind_e_n1991_1_4_a_p_i import ComputingProbabilityCoeff_Wind_EN1991_1_4_API
    from .computing_type_wind_e_n1991_1_4_a_p_i import ComputingType_Wind_EN1991_1_4_API
    from .greenhouse_class_wind_e_n1991_1_4_a_p_i import GreenhouseClass_Wind_EN1991_1_4_API

@dataclass
class GreenhouseParameters_Wind_EN1991_1_4(Parsable):
    """
    Greenhouse parameters for Wind EN 1991-1-4
    """
    from .computing_probability_coeff_wind_e_n1991_1_4_a_p_i import ComputingProbabilityCoeff_Wind_EN1991_1_4_API

    # Computing probability coefficient modeUnit: -Default: eWindComputingProbabilityCoeffByKParameter
    computing_probability_coeff: Optional[ComputingProbabilityCoeff_Wind_EN1991_1_4_API] = ComputingProbabilityCoeff_Wind_EN1991_1_4_API("eWindComputingProbabilityCoeffByKParameter")
    from .computing_type_wind_e_n1991_1_4_a_p_i import ComputingType_Wind_EN1991_1_4_API

    # Computing wind speed vb,0 modeUnit: -Default: eComputingTypeAuto
    computing_wind_speed_vb0: Optional[ComputingType_Wind_EN1991_1_4_API] = ComputingType_Wind_EN1991_1_4_API("eComputingTypeAuto")
    from .greenhouse_class_wind_e_n1991_1_4_a_p_i import GreenhouseClass_Wind_EN1991_1_4_API

    # Greenhouse classUnit: -Default: eWindGreenhouseClassB
    greenhouse_class: Optional[GreenhouseClass_Wind_EN1991_1_4_API] = GreenhouseClass_Wind_EN1991_1_4_API("eWindGreenhouseClassB")
    # Air densityUnit: kg/m³Default: 1.25
    air_density: Optional[float] = None
    # Dynamic factor CdUnit: -Default: 1.0
    dynamic_factor_cd: Optional[float] = None
    # Minimum height zminUnit: mDefault: 0.0
    minimum_height_zmin: Optional[float] = None
    # Shape parameter KUnit: -Default: 0.2
    param_forme_k: Optional[float] = None
    # Probability coefficient CpUnit: -Default: 1.0
    probability_coeff_cp: Optional[float] = None
    # Probability exponent n1Unit: -Default: 0.5
    probability_exponent_n1: Optional[float] = None
    # Return period (in years)Unit: yearsDefault: 50
    return_period_n: Optional[int] = None
    # Roughness length for category IIUnit: mDefault: 0.05
    roughness_length_cat_i_i: Optional[float] = None
    # Wind speed vb,0Unit: m/sDefault: 0.0
    wind_speed_vb0: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GreenhouseParameters_Wind_EN1991_1_4:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GreenhouseParameters_Wind_EN1991_1_4
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return GreenhouseParameters_Wind_EN1991_1_4()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .computing_probability_coeff_wind_e_n1991_1_4_a_p_i import ComputingProbabilityCoeff_Wind_EN1991_1_4_API
        from .computing_type_wind_e_n1991_1_4_a_p_i import ComputingType_Wind_EN1991_1_4_API
        from .greenhouse_class_wind_e_n1991_1_4_a_p_i import GreenhouseClass_Wind_EN1991_1_4_API

        from .computing_probability_coeff_wind_e_n1991_1_4_a_p_i import ComputingProbabilityCoeff_Wind_EN1991_1_4_API
        from .computing_type_wind_e_n1991_1_4_a_p_i import ComputingType_Wind_EN1991_1_4_API
        from .greenhouse_class_wind_e_n1991_1_4_a_p_i import GreenhouseClass_Wind_EN1991_1_4_API

        fields: dict[str, Callable[[Any], None]] = {
            "airDensity": lambda n : setattr(self, 'air_density', n.get_float_value()),
            "computingProbabilityCoeff": lambda n : setattr(self, 'computing_probability_coeff', n.get_enum_value(ComputingProbabilityCoeff_Wind_EN1991_1_4_API)),
            "computingWindSpeedVb0": lambda n : setattr(self, 'computing_wind_speed_vb0', n.get_enum_value(ComputingType_Wind_EN1991_1_4_API)),
            "dynamicFactorCd": lambda n : setattr(self, 'dynamic_factor_cd', n.get_float_value()),
            "greenhouseClass": lambda n : setattr(self, 'greenhouse_class', n.get_enum_value(GreenhouseClass_Wind_EN1991_1_4_API)),
            "minimumHeightZmin": lambda n : setattr(self, 'minimum_height_zmin', n.get_float_value()),
            "paramFormeK": lambda n : setattr(self, 'param_forme_k', n.get_float_value()),
            "probabilityCoeffCp": lambda n : setattr(self, 'probability_coeff_cp', n.get_float_value()),
            "probabilityExponent_n1": lambda n : setattr(self, 'probability_exponent_n1', n.get_float_value()),
            "returnPeriod_n": lambda n : setattr(self, 'return_period_n', n.get_int_value()),
            "roughnessLengthCatII": lambda n : setattr(self, 'roughness_length_cat_i_i', n.get_float_value()),
            "windSpeedVb0": lambda n : setattr(self, 'wind_speed_vb0', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("airDensity", self.air_density)
        writer.write_enum_value("computingProbabilityCoeff", self.computing_probability_coeff)
        writer.write_enum_value("computingWindSpeedVb0", self.computing_wind_speed_vb0)
        writer.write_float_value("dynamicFactorCd", self.dynamic_factor_cd)
        writer.write_enum_value("greenhouseClass", self.greenhouse_class)
        writer.write_float_value("minimumHeightZmin", self.minimum_height_zmin)
        writer.write_float_value("paramFormeK", self.param_forme_k)
        writer.write_float_value("probabilityCoeffCp", self.probability_coeff_cp)
        writer.write_float_value("probabilityExponent_n1", self.probability_exponent_n1)
        writer.write_int_value("returnPeriod_n", self.return_period_n)
        writer.write_float_value("roughnessLengthCatII", self.roughness_length_cat_i_i)
        writer.write_float_value("windSpeedVb0", self.wind_speed_vb0)
    

