from enum import Enum

class SiteClass_API(str, Enum):
    A = "A",
    B = "B",
    C = "C",
    D = "D",
    E = "E",
    F = "F",

