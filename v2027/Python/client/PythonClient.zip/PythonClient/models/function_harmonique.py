from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class FunctionHarmonique(Parsable):
    """
    Harmonic function parameters for temporal analysisCorresponds to som.FunctionHarmonique in the SOM model
    """
    # Harmonic intensity coefficientUnit: dimensionlessDefault: 0.0
    h_intensite: Optional[float] = None
    # Harmonic phase angleUnit: radDefault: 0.0
    h_phase: Optional[float] = None
    # Harmonic pulsation (angular frequency)Unit: rad/sDefault: 0.0
    h_pulsation: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FunctionHarmonique:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FunctionHarmonique
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return FunctionHarmonique()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "hIntensite": lambda n : setattr(self, 'h_intensite', n.get_float_value()),
            "hPhase": lambda n : setattr(self, 'h_phase', n.get_float_value()),
            "hPulsation": lambda n : setattr(self, 'h_pulsation', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("hIntensite", self.h_intensite)
        writer.write_float_value("hPhase", self.h_phase)
        writer.write_float_value("hPulsation", self.h_pulsation)
    

