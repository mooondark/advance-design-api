from enum import Enum

class PlanarMeshType(str, Enum):
    Complete = "complete",
    Triangulation = "triangulation",
    None_ = "none",

