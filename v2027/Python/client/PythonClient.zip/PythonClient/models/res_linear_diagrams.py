from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_diagram_displacements import ResDiagramDisplacements
    from .res_diagram_forces import ResDiagramForces
    from .res_diagram_stresses import ResDiagramStresses

@dataclass
class ResLinearDiagrams(Parsable):
    """
    Represents a result defined by an abscissa (position along an element) and a corresponding value.
    """
    # Displacements diagrams
    res_displacements: Optional[ResDiagramDisplacements] = None
    # Forces diagrams
    res_forces: Optional[ResDiagramForces] = None
    # Forces diagrams
    res_stresses: Optional[ResDiagramStresses] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResLinearDiagrams:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResLinearDiagrams
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResLinearDiagrams()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_diagram_displacements import ResDiagramDisplacements
        from .res_diagram_forces import ResDiagramForces
        from .res_diagram_stresses import ResDiagramStresses

        from .res_diagram_displacements import ResDiagramDisplacements
        from .res_diagram_forces import ResDiagramForces
        from .res_diagram_stresses import ResDiagramStresses

        fields: dict[str, Callable[[Any], None]] = {
            "resDisplacements": lambda n : setattr(self, 'res_displacements', n.get_object_value(ResDiagramDisplacements)),
            "resForces": lambda n : setattr(self, 'res_forces', n.get_object_value(ResDiagramForces)),
            "resStresses": lambda n : setattr(self, 'res_stresses', n.get_object_value(ResDiagramStresses)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("resDisplacements", self.res_displacements)
        writer.write_object_value("resForces", self.res_forces)
        writer.write_object_value("resStresses", self.res_stresses)
    

