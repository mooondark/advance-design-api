from enum import Enum

class GreenhouseClass_Wind_EN1991_1_4_API(str, Enum):
    EWindGreenhouseClassA = "eWindGreenhouseClassA",
    EWindGreenhouseClassB = "eWindGreenhouseClassB",

