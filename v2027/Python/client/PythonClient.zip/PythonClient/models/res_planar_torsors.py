from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResPlanarTorsors(Parsable):
    """
    Represents planar torsor resultants, including moments, forces, and twisting/warping values for structural analysison different faces, groups, and story levels.
    """
    # Story-level resultant moment around global X
    m_x_e_t_a_g_e: Optional[float] = None
    # Group-level resultant moment around global X
    m_x_g_r_o_u_p: Optional[float] = None
    # Story-level resultant moment around global Y
    m_y_e_t_a_g_e: Optional[float] = None
    # Group-level resultant moment around global Y
    m_y_g_r_o_u_p: Optional[float] = None
    # Resultant flexural/torsional moment on bottom→top face
    mf_bottom_top: Optional[float] = None
    # Resultant flexural/torsional moment on left→right face
    mf_left_right: Optional[float] = None
    # Bending moment around global Z on bottom→top face
    mz_bottom_top: Optional[float] = None
    # Bending moment around global Z on left→right face
    mz_left_right: Optional[float] = None
    # Axial normal force on bottom→top face
    n_bottom_top: Optional[float] = None
    # Axial normal force on left→right face
    n_left_right: Optional[float] = None
    # Story-level axial normal force along global Z
    n_z_e_t_a_g_e: Optional[float] = None
    # Group-level axial normal force along global Z
    n_z_g_r_o_u_p: Optional[float] = None
    # Twisting/warping resultant length for bottom→top
    t_w_length_b_t: Optional[float] = None
    # Twisting/warping resultant length for left→right
    t_w_length_l_r: Optional[float] = None
    # Twisting/warping offset for bottom→top
    t_w_offset_b_t: Optional[float] = None
    # Twisting/warping offset for left→right
    t_w_offset_l_r: Optional[float] = None
    # Story-level shear force along global X
    t_x_e_t_a_g_e: Optional[float] = None
    # Group-level shear force along global X
    t_x_g_r_o_u_p: Optional[float] = None
    # Story-level shear force along global Y
    t_y_e_t_a_g_e: Optional[float] = None
    # Group-level shear force along global Y
    t_y_g_r_o_u_p: Optional[float] = None
    # In-plane shear force Txy on bottom→top face
    txy_bottom_top: Optional[float] = None
    # In-plane shear force Txy on left→right face
    txy_left_right: Optional[float] = None
    # Transverse shear force Tyz on bottom→top face
    tyz_bottom_top: Optional[float] = None
    # Transverse shear force Tyz on left→right face
    tyz_left_right: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResPlanarTorsors:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResPlanarTorsors
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResPlanarTorsors()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "mX_ETAGE": lambda n : setattr(self, 'm_x_e_t_a_g_e', n.get_float_value()),
            "mX_GROUP": lambda n : setattr(self, 'm_x_g_r_o_u_p', n.get_float_value()),
            "mY_ETAGE": lambda n : setattr(self, 'm_y_e_t_a_g_e', n.get_float_value()),
            "mY_GROUP": lambda n : setattr(self, 'm_y_g_r_o_u_p', n.get_float_value()),
            "mf_BottomTop": lambda n : setattr(self, 'mf_bottom_top', n.get_float_value()),
            "mf_LeftRight": lambda n : setattr(self, 'mf_left_right', n.get_float_value()),
            "mz_BottomTop": lambda n : setattr(self, 'mz_bottom_top', n.get_float_value()),
            "mz_LeftRight": lambda n : setattr(self, 'mz_left_right', n.get_float_value()),
            "n_BottomTop": lambda n : setattr(self, 'n_bottom_top', n.get_float_value()),
            "n_LeftRight": lambda n : setattr(self, 'n_left_right', n.get_float_value()),
            "nZ_ETAGE": lambda n : setattr(self, 'n_z_e_t_a_g_e', n.get_float_value()),
            "nZ_GROUP": lambda n : setattr(self, 'n_z_g_r_o_u_p', n.get_float_value()),
            "tW_Length_BT": lambda n : setattr(self, 't_w_length_b_t', n.get_float_value()),
            "tW_Length_LR": lambda n : setattr(self, 't_w_length_l_r', n.get_float_value()),
            "tW_Offset_BT": lambda n : setattr(self, 't_w_offset_b_t', n.get_float_value()),
            "tW_Offset_LR": lambda n : setattr(self, 't_w_offset_l_r', n.get_float_value()),
            "tX_ETAGE": lambda n : setattr(self, 't_x_e_t_a_g_e', n.get_float_value()),
            "tX_GROUP": lambda n : setattr(self, 't_x_g_r_o_u_p', n.get_float_value()),
            "tY_ETAGE": lambda n : setattr(self, 't_y_e_t_a_g_e', n.get_float_value()),
            "tY_GROUP": lambda n : setattr(self, 't_y_g_r_o_u_p', n.get_float_value()),
            "txy_BottomTop": lambda n : setattr(self, 'txy_bottom_top', n.get_float_value()),
            "txy_LeftRight": lambda n : setattr(self, 'txy_left_right', n.get_float_value()),
            "tyz_BottomTop": lambda n : setattr(self, 'tyz_bottom_top', n.get_float_value()),
            "tyz_LeftRight": lambda n : setattr(self, 'tyz_left_right', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("mX_ETAGE", self.m_x_e_t_a_g_e)
        writer.write_float_value("mX_GROUP", self.m_x_g_r_o_u_p)
        writer.write_float_value("mY_ETAGE", self.m_y_e_t_a_g_e)
        writer.write_float_value("mY_GROUP", self.m_y_g_r_o_u_p)
        writer.write_float_value("mf_BottomTop", self.mf_bottom_top)
        writer.write_float_value("mf_LeftRight", self.mf_left_right)
        writer.write_float_value("mz_BottomTop", self.mz_bottom_top)
        writer.write_float_value("mz_LeftRight", self.mz_left_right)
        writer.write_float_value("n_BottomTop", self.n_bottom_top)
        writer.write_float_value("n_LeftRight", self.n_left_right)
        writer.write_float_value("nZ_ETAGE", self.n_z_e_t_a_g_e)
        writer.write_float_value("nZ_GROUP", self.n_z_g_r_o_u_p)
        writer.write_float_value("tW_Length_BT", self.t_w_length_b_t)
        writer.write_float_value("tW_Length_LR", self.t_w_length_l_r)
        writer.write_float_value("tW_Offset_BT", self.t_w_offset_b_t)
        writer.write_float_value("tW_Offset_LR", self.t_w_offset_l_r)
        writer.write_float_value("tX_ETAGE", self.t_x_e_t_a_g_e)
        writer.write_float_value("tX_GROUP", self.t_x_g_r_o_u_p)
        writer.write_float_value("tY_ETAGE", self.t_y_e_t_a_g_e)
        writer.write_float_value("tY_GROUP", self.t_y_g_r_o_u_p)
        writer.write_float_value("txy_BottomTop", self.txy_bottom_top)
        writer.write_float_value("txy_LeftRight", self.txy_left_right)
        writer.write_float_value("tyz_BottomTop", self.tyz_bottom_top)
        writer.write_float_value("tyz_LeftRight", self.tyz_left_right)
    

