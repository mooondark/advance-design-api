from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .soil import Soil

@dataclass
class SoilLayer(Parsable):
    """
    Soil Layer properties 
    """
    # Angle of friction between soil layers [deg]Unit: degreesDefault value: 0.0
    delta: Optional[float] = None
    # Coefficient for horizontal subgrade reaction [N/m3]Unit: N/m3Default value: 10000.0
    k_coeff: Optional[float] = None
    # Coefficient for vertical subgrade reaction [N/m3]Unit: N/m3Default value: 10000.0
    k_prim_coeff: Optional[float] = None
    # Soil propertiesUnit: no unitDefault value: null
    soil: Optional[Soil] = None
    # Thickness of the soil layer [m]Unit: mDefault value: 1.0
    thickness: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SoilLayer:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SoilLayer
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SoilLayer()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .soil import Soil

        from .soil import Soil

        fields: dict[str, Callable[[Any], None]] = {
            "delta": lambda n : setattr(self, 'delta', n.get_float_value()),
            "kCoeff": lambda n : setattr(self, 'k_coeff', n.get_float_value()),
            "kPrimCoeff": lambda n : setattr(self, 'k_prim_coeff', n.get_float_value()),
            "soil": lambda n : setattr(self, 'soil', n.get_object_value(Soil)),
            "thickness": lambda n : setattr(self, 'thickness', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("delta", self.delta)
        writer.write_float_value("kCoeff", self.k_coeff)
        writer.write_float_value("kPrimCoeff", self.k_prim_coeff)
        writer.write_object_value("soil", self.soil)
        writer.write_float_value("thickness", self.thickness)
    

