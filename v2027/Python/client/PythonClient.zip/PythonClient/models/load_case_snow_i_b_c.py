from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case_snow import LoadCase_Snow
    from .snow_effect_a_s_c_e722_parameters import SnowEffectASCE722Parameters
    from .snow_load_category_a_p_i import SnowLoadCategory_API

from .load_case_snow import LoadCase_Snow

@dataclass
class LoadCase_SnowIBC(LoadCase_Snow, AdditionalDataHolder, Parsable):
    """
    Snow load case for ASCE 7-22 / IBC
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Effect-specific parameters
    effect_parameters: Optional[SnowEffectASCE722Parameters] = None
    # Snow load category for this specific caseUnit: -Default: null
    snow_load_category: Optional[SnowLoadCategory_API] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_SnowIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_SnowIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_SnowIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case_snow import LoadCase_Snow
        from .snow_effect_a_s_c_e722_parameters import SnowEffectASCE722Parameters
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        from .load_case_snow import LoadCase_Snow
        from .snow_effect_a_s_c_e722_parameters import SnowEffectASCE722Parameters
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        fields: dict[str, Callable[[Any], None]] = {
            "effectParameters": lambda n : setattr(self, 'effect_parameters', n.get_object_value(SnowEffectASCE722Parameters)),
            "snowLoadCategory": lambda n : setattr(self, 'snow_load_category', n.get_enum_value(SnowLoadCategory_API)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("effectParameters", self.effect_parameters)
        writer.write_enum_value("snowLoadCategory", self.snow_load_category)
        writer.write_additional_data_value(self.additional_data)
    

