from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .adjust_factor_option_snow_n_f_e_c1_a_p_i import AdjustFactorOption_SnowNF_EC1_API
    from .exposure_coefficient_snow_n_f_e_c1_a_p_i import ExposureCoefficient_SnowNF_EC1_API

@dataclass
class EurocodeGeneralParametersSnowNF_EC1(Parsable):
    """
    Eurocode general parameters for Snow NF EC1 (EN 1991-1-3)
    """
    from .adjust_factor_option_snow_n_f_e_c1_a_p_i import AdjustFactorOption_SnowNF_EC1_API

    # Adjust factor optionUnit: -Default: e_Option_A_U_auto
    adjust_factor_option: Optional[AdjustFactorOption_SnowNF_EC1_API] = AdjustFactorOption_SnowNF_EC1_API("e_Option_A_U_auto")
    from .exposure_coefficient_snow_n_f_e_c1_a_p_i import ExposureCoefficient_SnowNF_EC1_API

    # Exposure coefficient (Ce)Unit: -Default: GRCG_SNOWNF_NE_1991_1_3_UNDER_WIND_08
    coefficient_exp_eu_gen: Optional[ExposureCoefficient_SnowNF_EC1_API] = ExposureCoefficient_SnowNF_EC1_API("GRCG_SNOWNF_NE_1991_1_3_UNDER_WIND_08")
    from .adjust_factor_option_snow_n_f_e_c1_a_p_i import AdjustFactorOption_SnowNF_EC1_API

    # Computing pressure option for n-yearsUnit: -Default: e_Option_A_U_auto
    computing_presure_n_years: Optional[AdjustFactorOption_SnowNF_EC1_API] = AdjustFactorOption_SnowNF_EC1_API("e_Option_A_U_auto")
    # Adjust factor (fs)Unit: -Default: 1.0
    adjust_factor: Optional[float] = None
    # AltitudeUnit: Length (m)Default: 0.0
    altitude_eu_gen: Optional[float] = None
    # Thermal coefficient (Ct)Unit: -Default: 1.0
    coefficient_termic_eu_gen: Optional[float] = None
    # Exceptional snow coefficient (Sad)Unit: Pressure (Pa or kN/m²)Default: 0.0
    except_coef_eu_gen: Optional[float] = None
    # Exceptional snow coefficient for n-years (SAdn)Unit: Pressure (Pa or kN/m²)Default: 0.0
    except_coef_eu_gen_s_adn: Optional[float] = None
    # Return period N (years)Unit: YearsDefault: 50
    period_n: Optional[int] = None
    # Characteristic snow load on the ground (Sk)Unit: Pressure (Pa or kN/m²)Default: 450.0
    pressure_eu_gen: Optional[float] = None
    # Snow pressure for n-years (Sn)Unit: Pressure (Pa or kN/m²)Default: 450.0
    pressure_eu_gen_sn: Optional[float] = None
    # Coefficient of variation VUnit: -Default: 0.0
    variation_coeff_v: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EurocodeGeneralParametersSnowNF_EC1:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EurocodeGeneralParametersSnowNF_EC1
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EurocodeGeneralParametersSnowNF_EC1()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .adjust_factor_option_snow_n_f_e_c1_a_p_i import AdjustFactorOption_SnowNF_EC1_API
        from .exposure_coefficient_snow_n_f_e_c1_a_p_i import ExposureCoefficient_SnowNF_EC1_API

        from .adjust_factor_option_snow_n_f_e_c1_a_p_i import AdjustFactorOption_SnowNF_EC1_API
        from .exposure_coefficient_snow_n_f_e_c1_a_p_i import ExposureCoefficient_SnowNF_EC1_API

        fields: dict[str, Callable[[Any], None]] = {
            "adjustFactor": lambda n : setattr(self, 'adjust_factor', n.get_float_value()),
            "adjustFactorOption": lambda n : setattr(self, 'adjust_factor_option', n.get_enum_value(AdjustFactorOption_SnowNF_EC1_API)),
            "altitudeEuGen": lambda n : setattr(self, 'altitude_eu_gen', n.get_float_value()),
            "coefficientExpEuGen": lambda n : setattr(self, 'coefficient_exp_eu_gen', n.get_enum_value(ExposureCoefficient_SnowNF_EC1_API)),
            "coefficientTermicEuGen": lambda n : setattr(self, 'coefficient_termic_eu_gen', n.get_float_value()),
            "computingPresure_n_years": lambda n : setattr(self, 'computing_presure_n_years', n.get_enum_value(AdjustFactorOption_SnowNF_EC1_API)),
            "exceptCoefEuGen": lambda n : setattr(self, 'except_coef_eu_gen', n.get_float_value()),
            "exceptCoefEuGenSAdn": lambda n : setattr(self, 'except_coef_eu_gen_s_adn', n.get_float_value()),
            "periodN": lambda n : setattr(self, 'period_n', n.get_int_value()),
            "pressureEuGen": lambda n : setattr(self, 'pressure_eu_gen', n.get_float_value()),
            "pressureEuGenSn": lambda n : setattr(self, 'pressure_eu_gen_sn', n.get_float_value()),
            "variationCoeffV": lambda n : setattr(self, 'variation_coeff_v', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("adjustFactor", self.adjust_factor)
        writer.write_enum_value("adjustFactorOption", self.adjust_factor_option)
        writer.write_float_value("altitudeEuGen", self.altitude_eu_gen)
        writer.write_enum_value("coefficientExpEuGen", self.coefficient_exp_eu_gen)
        writer.write_float_value("coefficientTermicEuGen", self.coefficient_termic_eu_gen)
        writer.write_enum_value("computingPresure_n_years", self.computing_presure_n_years)
        writer.write_float_value("exceptCoefEuGen", self.except_coef_eu_gen)
        writer.write_float_value("exceptCoefEuGenSAdn", self.except_coef_eu_gen_s_adn)
        writer.write_int_value("periodN", self.period_n)
        writer.write_float_value("pressureEuGen", self.pressure_eu_gen)
        writer.write_float_value("pressureEuGenSn", self.pressure_eu_gen_sn)
        writer.write_float_value("variationCoeffV", self.variation_coeff_v)
    

