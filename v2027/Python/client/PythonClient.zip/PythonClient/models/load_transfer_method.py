from enum import Enum

class LoadTransferMethod(str, Enum):
    ELoadTransferMethodFailureLines = "eLoadTransferMethodFailureLines",
    ELoadTransferMethodFemTransfer = "eLoadTransferMethodFemTransfer",
    ELoadTransferMethodAuto = "eLoadTransferMethodAuto",

