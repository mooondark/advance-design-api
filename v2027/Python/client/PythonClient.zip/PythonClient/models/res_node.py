from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_base import ResBase
    from .res_displacements import ResDisplacements
    from .res_forces import ResForces
    from .res_stresses import ResStresses

from .res_base import ResBase

@dataclass
class ResNode(ResBase, AdditionalDataHolder, Parsable):
    """
    Result on node
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Displacements result container
    res_displacements: Optional[ResDisplacements] = None
    # Forces result container
    res_forces: Optional[ResForces] = None
    # Stresses result container
    res_stresses: Optional[ResStresses] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResNode:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResNode
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResNode()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_base import ResBase
        from .res_displacements import ResDisplacements
        from .res_forces import ResForces
        from .res_stresses import ResStresses

        from .res_base import ResBase
        from .res_displacements import ResDisplacements
        from .res_forces import ResForces
        from .res_stresses import ResStresses

        fields: dict[str, Callable[[Any], None]] = {
            "resDisplacements": lambda n : setattr(self, 'res_displacements', n.get_object_value(ResDisplacements)),
            "resForces": lambda n : setattr(self, 'res_forces', n.get_object_value(ResForces)),
            "resStresses": lambda n : setattr(self, 'res_stresses', n.get_object_value(ResStresses)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("resDisplacements", self.res_displacements)
        writer.write_object_value("resForces", self.res_forces)
        writer.write_object_value("resStresses", self.res_stresses)
        writer.write_additional_data_value(self.additional_data)
    

