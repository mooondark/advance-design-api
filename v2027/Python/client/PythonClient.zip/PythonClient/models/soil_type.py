from enum import Enum

class SoilType(str, Enum):
    ESoilType_Peat = "eSoilType_Peat",
    ESoilType_Mud_clay_good_cohesion = "eSoilType_Mud_clay_good_cohesion",
    ESoilType_Clay_squishy = "eSoilType_Clay_squishy",
    ESoilType_Clay_soft = "eSoilType_Clay_soft",
    ESoilType_Mud_clay_bad_cohesion = "eSoilType_Mud_clay_bad_cohesion",
    ESoilType_Clay_hard = "eSoilType_Clay_hard",
    ESoilType_Silt = "eSoilType_Silt",
    ESoilType_Loess = "eSoilType_Loess",
    ESoilType_Clay_semi_solid = "eSoilType_Clay_semi_solid",
    ESoilType_Loam_sand_silt_and_clay = "eSoilType_Loam_sand_silt_and_clay",
    ESoilType_Clay_solid = "eSoilType_Clay_solid",
    ESoilType_Sand_loose_round = "eSoilType_Sand_loose_round",
    ESoilType_Sand_loose_angular = "eSoilType_Sand_loose_angular",
    ESoilType_Sand_medium_round = "eSoilType_Sand_medium_round",
    ESoilType_Sand_compact_angular = "eSoilType_Sand_compact_angular",
    ESoilType_Gravel_no_sand = "eSoilType_Gravel_no_sand",
    ESoilType_Stone = "eSoilType_Stone",

