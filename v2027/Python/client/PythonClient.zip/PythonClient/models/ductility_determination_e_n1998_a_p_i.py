from enum import Enum

class DuctilityDeterminationEN1998_API(str, Enum):
    Q_CALCULATED = "Q_CALCULATED",
    Q_IMPOSE = "Q_IMPOSE",

