from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case import LoadCase
    from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
    from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
    from .load_case_seismic_i_b_c import LoadCase_SeismicIBC

from .load_case import LoadCase

@dataclass
class LoadCase_Seismic(LoadCase, AdditionalDataHolder, Parsable):
    """
    Seismic load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_Seismic:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_Seismic
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicCBN".casefold():
            from .load_case_seismic_c_b_n import LoadCase_SeismicCBN

            return LoadCase_SeismicCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicEN_1998_1".casefold():
            from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1

            return LoadCase_SeismicEN_1998_1()
        if mapping_value and mapping_value.casefold() == "LoadCase_SeismicIBC".casefold():
            from .load_case_seismic_i_b_c import LoadCase_SeismicIBC

            return LoadCase_SeismicIBC()
        return LoadCase_Seismic()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case import LoadCase
        from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
        from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
        from .load_case_seismic_i_b_c import LoadCase_SeismicIBC

        from .load_case import LoadCase
        from .load_case_seismic_c_b_n import LoadCase_SeismicCBN
        from .load_case_seismic_e_n_1998_1 import LoadCase_SeismicEN_1998_1
        from .load_case_seismic_i_b_c import LoadCase_SeismicIBC

        fields: dict[str, Callable[[Any], None]] = {
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_additional_data_value(self.additional_data)
    

