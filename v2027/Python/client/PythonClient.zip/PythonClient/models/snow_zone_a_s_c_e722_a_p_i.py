from enum import Enum

class SnowZone_ASCE722_API(str, Enum):
    GRCG_ASCE_ZONE_0_OTHER = "GRCG_ASCE_ZONE_0_OTHER",

