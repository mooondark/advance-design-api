from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SupportingElementDimensionsLinear(Parsable):
    """
    Defines a generic supporting element and its overall dimensions.
    """
    # Height h of the supported element along global Z (m).Unit: m Default value : 0.3
    height_of_supp_elem_h: Optional[float] = None
    # Width of the supported element (m).Unit: m Default value : 0.3
    width_of_supp_elem_a: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SupportingElementDimensionsLinear:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SupportingElementDimensionsLinear
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SupportingElementDimensionsLinear()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "heightOfSuppElem_h": lambda n : setattr(self, 'height_of_supp_elem_h', n.get_float_value()),
            "widthOfSuppElem_a": lambda n : setattr(self, 'width_of_supp_elem_a', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("heightOfSuppElem_h", self.height_of_supp_elem_h)
        writer.write_float_value("widthOfSuppElem_a", self.width_of_supp_elem_a)
    

