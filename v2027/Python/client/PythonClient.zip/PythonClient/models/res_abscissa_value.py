from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResAbscissaValue(Parsable):
    """
    Represents a result defined by an abscissa (position along an element) and a corresponding value.
    """
    # Gets or sets the abscissa (position along the element)
    abscissa: Optional[float] = None
    # Gets or sets the result values at the corresponding abscissa.
    value: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResAbscissaValue:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResAbscissaValue
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResAbscissaValue()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "abscissa": lambda n : setattr(self, 'abscissa', n.get_float_value()),
            "value": lambda n : setattr(self, 'value', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("abscissa", self.abscissa)
        writer.write_float_value("value", self.value)
    

