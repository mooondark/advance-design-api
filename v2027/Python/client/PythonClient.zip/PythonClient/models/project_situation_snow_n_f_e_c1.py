from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ProjectSituationSnowNF_EC1(Parsable):
    """
    Project situation parameters for Snow NF EC1 (EN 1991-1-3)
    """
    # Snow exceptional accumulationUnit: -Default: false
    snow_exp_acc: Optional[bool] = None
    # Snow exceptional fallUnit: -Default: false
    snow_exp_fall: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectSituationSnowNF_EC1:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectSituationSnowNF_EC1
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectSituationSnowNF_EC1()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "snowExpAcc": lambda n : setattr(self, 'snow_exp_acc', n.get_bool_value()),
            "snowExpFall": lambda n : setattr(self, 'snow_exp_fall', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("snowExpAcc", self.snow_exp_acc)
        writer.write_bool_value("snowExpFall", self.snow_exp_fall)
    

