from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .advanced_restraints_diagram_definitions import AdvancedRestraintsDiagramDefinitions
    from .element_base import ElementBase
    from .e_i_d import EID
    from .pile_bearing import PileBearing
    from .pile_restraints_options import PileRestraintsOptions
    from .pt3_d import Pt3D

from .element_base import ElementBase

@dataclass
class ElementSinglePile(ElementBase, AdditionalDataHolder, Parsable):
    """
    Single pile
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Pile bearing propertiesUnit: no unit Default value : optional nullable object
    bearing: Optional[PileBearing] = None
    # EID of the section already created for the cross-section of the pile
    cross_section: Optional[EID] = None
    # Indicates whether the element is active in the analysis.Unit: no unit Default value : true
    element_active: Optional[bool] = None
    # Point in 3D space expressed in global axes.Unit: m Default value : (0, 0, 0)
    geom_pt: Optional[Pt3D] = None
    # EID of the material already created
    material: Optional[EID] = None
    # Advanced restraints diagram definitions, taken into account if RestraintsOptions is defined tooUnit: no unit Default value : optional nullable object
    restraints_diagrams: Optional[AdvancedRestraintsDiagramDefinitions] = None
    # Advanced restraints optionsUnit: no unit Default value : optional nullable object
    restraints_options: Optional[PileRestraintsOptions] = None
    # total length of the pile (m)Unit: m Default value : 10.0
    total_length: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementSinglePile:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementSinglePile
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementSinglePile()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .advanced_restraints_diagram_definitions import AdvancedRestraintsDiagramDefinitions
        from .element_base import ElementBase
        from .e_i_d import EID
        from .pile_bearing import PileBearing
        from .pile_restraints_options import PileRestraintsOptions
        from .pt3_d import Pt3D

        from .advanced_restraints_diagram_definitions import AdvancedRestraintsDiagramDefinitions
        from .element_base import ElementBase
        from .e_i_d import EID
        from .pile_bearing import PileBearing
        from .pile_restraints_options import PileRestraintsOptions
        from .pt3_d import Pt3D

        fields: dict[str, Callable[[Any], None]] = {
            "bearing": lambda n : setattr(self, 'bearing', n.get_object_value(PileBearing)),
            "crossSection": lambda n : setattr(self, 'cross_section', n.get_object_value(EID)),
            "elementActive": lambda n : setattr(self, 'element_active', n.get_bool_value()),
            "geomPt": lambda n : setattr(self, 'geom_pt', n.get_object_value(Pt3D)),
            "material": lambda n : setattr(self, 'material', n.get_object_value(EID)),
            "restraintsDiagrams": lambda n : setattr(self, 'restraints_diagrams', n.get_object_value(AdvancedRestraintsDiagramDefinitions)),
            "restraintsOptions": lambda n : setattr(self, 'restraints_options', n.get_object_value(PileRestraintsOptions)),
            "totalLength": lambda n : setattr(self, 'total_length', n.get_float_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("bearing", self.bearing)
        writer.write_object_value("crossSection", self.cross_section)
        writer.write_bool_value("elementActive", self.element_active)
        writer.write_object_value("geomPt", self.geom_pt)
        writer.write_object_value("material", self.material)
        writer.write_object_value("restraintsDiagrams", self.restraints_diagrams)
        writer.write_object_value("restraintsOptions", self.restraints_options)
        writer.write_float_value("totalLength", self.total_length)
        writer.write_additional_data_value(self.additional_data)
    

