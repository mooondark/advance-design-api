from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .degree_of_freedom_restraints import DegreeOfFreedomRestraints
    from .family_support_linear import FamilySupportLinear
    from .rigid_support_constraint import RigidSupportConstraint

from .family_support_linear import FamilySupportLinear

@dataclass
class ElementRigidLinearSupport(FamilySupportLinear, AdditionalDataHolder, Parsable):
    """
    Element Rigid Linear Support
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .rigid_support_constraint import RigidSupportConstraint

    # Rigid Support Constraint type Default value : RigidSupportConstraint.fix
    constraints_type: Optional[RigidSupportConstraint] = RigidSupportConstraint("fix")
    # Degree of freedom constraints (true=locked)    Default value : optional nullable object
    restraints: Optional[DegreeOfFreedomRestraints] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementRigidLinearSupport:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementRigidLinearSupport
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementRigidLinearSupport()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .degree_of_freedom_restraints import DegreeOfFreedomRestraints
        from .family_support_linear import FamilySupportLinear
        from .rigid_support_constraint import RigidSupportConstraint

        from .degree_of_freedom_restraints import DegreeOfFreedomRestraints
        from .family_support_linear import FamilySupportLinear
        from .rigid_support_constraint import RigidSupportConstraint

        fields: dict[str, Callable[[Any], None]] = {
            "constraintsType": lambda n : setattr(self, 'constraints_type', n.get_enum_value(RigidSupportConstraint)),
            "restraints": lambda n : setattr(self, 'restraints', n.get_object_value(DegreeOfFreedomRestraints)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("constraintsType", self.constraints_type)
        writer.write_object_value("restraints", self.restraints)
        writer.write_additional_data_value(self.additional_data)
    

