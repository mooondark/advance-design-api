from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LoadCaseFamilyDeadLoadsCoefficients(Parsable):
    """
    Dead loads (self weight) favourable / unfavourable partial safety factors container (dimensionless).
    """
    # Gamma unfavourable EQU coefficient (destabilizing).Unit: -Default value: 1.1
    gamma_defav_e_q_u: Optional[float] = None
    # Gamma unfavourable STR/GEO coefficient (γ_G,sup for STR/GEO).Unit: -Default value: 1.35
    gamma_defav_s_t_r_g_e_o: Optional[float] = None
    # Gamma favourable EQU coefficient (stabilizing).Unit: -Default value: 0.9
    gamma_fav_e_q_u: Optional[float] = None
    # Gamma favourable STR/GEO coefficient (γ_G,inf for STR/GEO).Unit: -Default value: 1.0
    gamma_fav_s_t_r_g_e_o: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamilyDeadLoadsCoefficients:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamilyDeadLoadsCoefficients
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamilyDeadLoadsCoefficients()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "gammaDefavEQU": lambda n : setattr(self, 'gamma_defav_e_q_u', n.get_float_value()),
            "gammaDefavSTRGEO": lambda n : setattr(self, 'gamma_defav_s_t_r_g_e_o', n.get_float_value()),
            "gammaFavEQU": lambda n : setattr(self, 'gamma_fav_e_q_u', n.get_float_value()),
            "gammaFavSTRGEO": lambda n : setattr(self, 'gamma_fav_s_t_r_g_e_o', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("gammaDefavEQU", self.gamma_defav_e_q_u)
        writer.write_float_value("gammaDefavSTRGEO", self.gamma_defav_s_t_r_g_e_o)
        writer.write_float_value("gammaFavEQU", self.gamma_fav_e_q_u)
        writer.write_float_value("gammaFavSTRGEO", self.gamma_fav_s_t_r_g_e_o)
    

