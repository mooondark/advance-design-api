from enum import Enum

class DirectionChoiceEN1998_API(str, Enum):
    X = "X",
    Y = "Y",
    Z = "Z",
    XY = "XY",

