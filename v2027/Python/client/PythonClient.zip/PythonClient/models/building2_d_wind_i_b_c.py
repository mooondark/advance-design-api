from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .portal_opening_position_wind import PortalOpeningPosition_Wind
    from .wind2_d_loads_determination_method_wind_e_n1991_1_4_a_p_i import Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API

@dataclass
class Building2DWindIBC(Parsable):
    """
    2D Building parameters for Wind IBC/ASCE 7-22
    """
    from .portal_opening_position_wind import PortalOpeningPosition_Wind

    # Opening positionUnit: -Default: WINDEC1_OP_NONE
    opening_position: Optional[PortalOpeningPosition_Wind] = PortalOpeningPosition_Wind("CG_WINDEC1_OPENING2D_NONE")
    from .wind2_d_loads_determination_method_wind_e_n1991_1_4_a_p_i import Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API

    # Wind 2D loads determination methodUnit: -Default: eWind2DRealLoadsInSpan
    wind2_d_loads_determination_method: Optional[Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API] = Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API("eWind2DRealLoadsInSpan")
    # Building length for 2D analysisUnit: lengthDefault: 30.0
    building_length: Optional[float] = None
    # Portal position for 2D analysisUnit: lengthDefault: 5.0
    portal_position: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Building2DWindIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Building2DWindIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Building2DWindIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .portal_opening_position_wind import PortalOpeningPosition_Wind
        from .wind2_d_loads_determination_method_wind_e_n1991_1_4_a_p_i import Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API

        from .portal_opening_position_wind import PortalOpeningPosition_Wind
        from .wind2_d_loads_determination_method_wind_e_n1991_1_4_a_p_i import Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API

        fields: dict[str, Callable[[Any], None]] = {
            "buildingLength": lambda n : setattr(self, 'building_length', n.get_float_value()),
            "openingPosition": lambda n : setattr(self, 'opening_position', n.get_enum_value(PortalOpeningPosition_Wind)),
            "portalPosition": lambda n : setattr(self, 'portal_position', n.get_float_value()),
            "wind2DLoadsDeterminationMethod": lambda n : setattr(self, 'wind2_d_loads_determination_method', n.get_enum_value(Wind2DLoadsDeterminationMethod_Wind_EN1991_1_4_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("buildingLength", self.building_length)
        writer.write_enum_value("openingPosition", self.opening_position)
        writer.write_float_value("portalPosition", self.portal_position)
        writer.write_enum_value("wind2DLoadsDeterminationMethod", self.wind2_d_loads_determination_method)
    

