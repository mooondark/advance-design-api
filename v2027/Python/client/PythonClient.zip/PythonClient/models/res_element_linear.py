from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_base import ResBase
    from .res_linear_diagrams import ResLinearDiagrams
    from .res_node import ResNode

from .res_base import ResBase

@dataclass
class ResElementLinear(ResBase, AdditionalDataHolder, Parsable):
    """
    Represents a linear finite element within a structural analysis model.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Gets or sets the collection of results in Abscissa associated with this element.
    res_diagrams: Optional[ResLinearDiagrams] = None
    # Gets or sets the collection of results nodes associated with this element.
    res_nodes: Optional[list[ResNode]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResElementLinear:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResElementLinear
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResElementLinear()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_base import ResBase
        from .res_linear_diagrams import ResLinearDiagrams
        from .res_node import ResNode

        from .res_base import ResBase
        from .res_linear_diagrams import ResLinearDiagrams
        from .res_node import ResNode

        fields: dict[str, Callable[[Any], None]] = {
            "resDiagrams": lambda n : setattr(self, 'res_diagrams', n.get_object_value(ResLinearDiagrams)),
            "resNodes": lambda n : setattr(self, 'res_nodes', n.get_collection_of_object_values(ResNode)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("resDiagrams", self.res_diagrams)
        writer.write_collection_of_object_values("resNodes", self.res_nodes)
        writer.write_additional_data_value(self.additional_data)
    

