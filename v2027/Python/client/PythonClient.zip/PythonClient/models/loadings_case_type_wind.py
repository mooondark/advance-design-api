from enum import Enum

class LoadingsCaseType_Wind(str, Enum):
    NORMAL_TYPE_WIND = "NORMAL_TYPE_WIND",
    ACCIDENTAL_TYPE_WIND = "ACCIDENTAL_TYPE_WIND",

