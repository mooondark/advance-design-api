from enum import Enum

class AdjustFactorOption_SnowNF_EC1_API(str, Enum):
    E_Option_A_U_auto = "e_Option_A_U_auto",
    E_Option_A_U_imposed = "e_Option_A_U_imposed",

