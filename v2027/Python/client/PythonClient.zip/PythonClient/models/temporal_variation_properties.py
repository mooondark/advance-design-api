from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class TemporalVariationProperties(Parsable):
    """
    Temporal load variation properties
    """
    # Direct integration coefficient alpha (Newmark method)Unit: dimensionlessDefault: 0.25
    accelerogram_direct_integration_coeff_alpha: Optional[float] = None
    # Direct integration coefficient gamma (Newmark method)Unit: dimensionlessDefault: 0.5
    accelerogram_direct_integration_coeff_gamma: Optional[float] = None
    # Direction of accelerogram application (for ACCELEROGRAM_VARIATION)0 = eAccelerogramDirectionX1 = eAccelerogramDirectionY2 = eAccelerogramDirectionZUnit: dimensionlessDefault: 0 (eAccelerogramDirectionX)
    accelerogram_direction: Optional[int] = None
    # Scale factor for accelerogram amplitudeUnit: dimensionlessDefault: 1.0
    accelerogram_scale_factor: Optional[float] = None
    # Kind of variation for temporal loading0 = NON_HARMONIC_VARIATION1 = HARMONIC_VARIATION2 = ACCELEROGRAM_VARIATIONUnit: dimensionlessDefault: 0 (NON_HARMONIC_VARIATION)
    kind_of_variation: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TemporalVariationProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TemporalVariationProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TemporalVariationProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "accelerogramDirectIntegrationCoeffAlpha": lambda n : setattr(self, 'accelerogram_direct_integration_coeff_alpha', n.get_float_value()),
            "accelerogramDirectIntegrationCoeffGamma": lambda n : setattr(self, 'accelerogram_direct_integration_coeff_gamma', n.get_float_value()),
            "accelerogramDirection": lambda n : setattr(self, 'accelerogram_direction', n.get_int_value()),
            "accelerogramScaleFactor": lambda n : setattr(self, 'accelerogram_scale_factor', n.get_float_value()),
            "kindOfVariation": lambda n : setattr(self, 'kind_of_variation', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("accelerogramDirectIntegrationCoeffAlpha", self.accelerogram_direct_integration_coeff_alpha)
        writer.write_float_value("accelerogramDirectIntegrationCoeffGamma", self.accelerogram_direct_integration_coeff_gamma)
        writer.write_int_value("accelerogramDirection", self.accelerogram_direction)
        writer.write_float_value("accelerogramScaleFactor", self.accelerogram_scale_factor)
        writer.write_int_value("kindOfVariation", self.kind_of_variation)
    

