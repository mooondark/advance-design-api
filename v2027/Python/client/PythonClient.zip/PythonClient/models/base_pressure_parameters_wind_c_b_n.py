from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ce_mode_wind_c_b_n_a_p_i import CeMode_WindCBN_API
    from .external_pressure_article_wind_c_b_n_a_p_i import ExternalPressureArticle_WindCBN_API
    from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API

@dataclass
class BasePressureParametersWindCBN(Parsable):
    """
    Base pressure parameters for Wind CBN
    """
    from .ce_mode_wind_c_b_n_a_p_i import CeMode_WindCBN_API

    # Ce coefficient calculation modeUnit: -Default: WindCBNWd2010_CE_C_MANUAL
    ce_mode: Optional[CeMode_WindCBN_API] = CeMode_WindCBN_API("WindCBNWd2010_CE_C_MANUAL")
    from .external_pressure_article_wind_c_b_n_a_p_i import ExternalPressureArticle_WindCBN_API

    # External pressure article used for low buildingsUnit: -Default: cp_zones_cornersenvelope_using_4_1_7_6__2
    external_pressure_article_used_for_low_buildings: Optional[ExternalPressureArticle_WindCBN_API] = ExternalPressureArticle_WindCBN_API("cp_zones_cornersenvelope_using_4_1_7_6__2")
    from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API

    # Importance factor IEUnit: -Default: SNOWCBNSn2010_IE_NORMAL
    importance_factor_i_e: Optional[ImportanceFactorIE_SnowCBN_API] = ImportanceFactorIE_SnowCBN_API("SNOWCBNSn2010_IE_NORMAL")
    # Zone identifier hash stringUnit: -Default: " "
    zone_hash: Optional[str] = " "
    # Ce exposure factorUnit: -Default: 1.0
    ce: Optional[float] = None
    # Cei internal exposure factorUnit: -Default: 1.0
    cei: Optional[float] = None
    # Cg gust effect factor (external)Unit: -Default: 2.5
    cg: Optional[float] = None
    # Cgi gust effect factor (internal)Unit: -Default: 2.0
    cgi: Optional[float] = None
    # Ct topographic factorUnit: -Default: 1.0
    ct: Optional[float] = None
    #  Height of structure base considered from the groundUnit: lengthDefault: 0.0
    height_of_structure_base: Optional[float] = None
    # Base pressure value (from database for location)Unit: pressureDefault: 420.0
    pressure: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> BasePressureParametersWindCBN:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: BasePressureParametersWindCBN
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return BasePressureParametersWindCBN()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .ce_mode_wind_c_b_n_a_p_i import CeMode_WindCBN_API
        from .external_pressure_article_wind_c_b_n_a_p_i import ExternalPressureArticle_WindCBN_API
        from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API

        from .ce_mode_wind_c_b_n_a_p_i import CeMode_WindCBN_API
        from .external_pressure_article_wind_c_b_n_a_p_i import ExternalPressureArticle_WindCBN_API
        from .importance_factor_i_e_snow_c_b_n_a_p_i import ImportanceFactorIE_SnowCBN_API

        fields: dict[str, Callable[[Any], None]] = {
            "ce": lambda n : setattr(self, 'ce', n.get_float_value()),
            "ceMode": lambda n : setattr(self, 'ce_mode', n.get_enum_value(CeMode_WindCBN_API)),
            "cei": lambda n : setattr(self, 'cei', n.get_float_value()),
            "cg": lambda n : setattr(self, 'cg', n.get_float_value()),
            "cgi": lambda n : setattr(self, 'cgi', n.get_float_value()),
            "ct": lambda n : setattr(self, 'ct', n.get_float_value()),
            "externalPressureArticleUsedForLowBuildings": lambda n : setattr(self, 'external_pressure_article_used_for_low_buildings', n.get_enum_value(ExternalPressureArticle_WindCBN_API)),
            "heightOfStructureBase": lambda n : setattr(self, 'height_of_structure_base', n.get_float_value()),
            "importanceFactorIE": lambda n : setattr(self, 'importance_factor_i_e', n.get_enum_value(ImportanceFactorIE_SnowCBN_API)),
            "pressure": lambda n : setattr(self, 'pressure', n.get_float_value()),
            "zoneHash": lambda n : setattr(self, 'zone_hash', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("ce", self.ce)
        writer.write_enum_value("ceMode", self.ce_mode)
        writer.write_float_value("cei", self.cei)
        writer.write_float_value("cg", self.cg)
        writer.write_float_value("cgi", self.cgi)
        writer.write_float_value("ct", self.ct)
        writer.write_enum_value("externalPressureArticleUsedForLowBuildings", self.external_pressure_article_used_for_low_buildings)
        writer.write_float_value("heightOfStructureBase", self.height_of_structure_base)
        writer.write_enum_value("importanceFactorIE", self.importance_factor_i_e)
        writer.write_float_value("pressure", self.pressure)
        writer.write_str_value("zoneHash", self.zone_hash)
    

