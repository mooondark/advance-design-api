from enum import Enum

class SFRSTimber_API(str, Enum):
    DuctileShearWall = "DuctileShearWall",
    ModeratelyDuctileShearWall = "ModeratelyDuctileShearWall",
    ConventionalConstruction = "ConventionalConstruction",

