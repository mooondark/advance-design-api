from enum import Enum

class MaterialSRFS_API(str, Enum):
    Concrete = "Concrete",
    Steel = "Steel",
    Masonry = "Masonry",
    Timber = "Timber",

