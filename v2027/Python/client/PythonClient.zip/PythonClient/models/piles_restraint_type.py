from enum import Enum

class PilesRestraintType(str, Enum):
    EPileSupportRestraintTypeFree = "ePileSupportRestraintTypeFree",
    EPileSupportRestraintTypeElastic = "ePileSupportRestraintTypeElastic",
    EPileSupportRestraintTypeFixed = "ePileSupportRestraintTypeFixed",

