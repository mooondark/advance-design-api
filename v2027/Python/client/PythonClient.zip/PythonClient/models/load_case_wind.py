from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case import LoadCase
    from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
    from .load_case_wind_c_b_n import LoadCase_WindCBN
    from .load_case_wind_i_b_c import LoadCase_WindIBC

from .load_case import LoadCase

@dataclass
class LoadCase_Wind(LoadCase, AdditionalDataHolder, Parsable):
    """
    Wind load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_Wind:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_Wind
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "LoadCase_Wind_1991_1_4".casefold():
            from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4

            return LoadCase_Wind_1991_1_4()
        if mapping_value and mapping_value.casefold() == "LoadCase_WindCBN".casefold():
            from .load_case_wind_c_b_n import LoadCase_WindCBN

            return LoadCase_WindCBN()
        if mapping_value and mapping_value.casefold() == "LoadCase_WindIBC".casefold():
            from .load_case_wind_i_b_c import LoadCase_WindIBC

            return LoadCase_WindIBC()
        return LoadCase_Wind()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case import LoadCase
        from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
        from .load_case_wind_c_b_n import LoadCase_WindCBN
        from .load_case_wind_i_b_c import LoadCase_WindIBC

        from .load_case import LoadCase
        from .load_case_wind_1991_1_4 import LoadCase_Wind_1991_1_4
        from .load_case_wind_c_b_n import LoadCase_WindCBN
        from .load_case_wind_i_b_c import LoadCase_WindIBC

        fields: dict[str, Callable[[Any], None]] = {
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_additional_data_value(self.additional_data)
    

