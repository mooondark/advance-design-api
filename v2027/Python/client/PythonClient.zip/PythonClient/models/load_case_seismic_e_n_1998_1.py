from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .direction_config_e_n1998 import DirectionConfigEN1998
    from .ductility_config_e_n1998 import DuctilityConfigEN1998
    from .load_case_seismic import LoadCase_Seismic

from .load_case_seismic import LoadCase_Seismic

@dataclass
class LoadCase_SeismicEN_1998_1(LoadCase_Seismic, AdditionalDataHolder, Parsable):
    """
    Seismic EN 1998-1 load case
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Direction configuration for the seismic effect
    direction: Optional[DirectionConfigEN1998] = None
    # Ductility configuration for the seismic effect
    ductility: Optional[DuctilityConfigEN1998] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_SeismicEN_1998_1:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_SeismicEN_1998_1
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_SeismicEN_1998_1()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .direction_config_e_n1998 import DirectionConfigEN1998
        from .ductility_config_e_n1998 import DuctilityConfigEN1998
        from .load_case_seismic import LoadCase_Seismic

        from .direction_config_e_n1998 import DirectionConfigEN1998
        from .ductility_config_e_n1998 import DuctilityConfigEN1998
        from .load_case_seismic import LoadCase_Seismic

        fields: dict[str, Callable[[Any], None]] = {
            "direction": lambda n : setattr(self, 'direction', n.get_object_value(DirectionConfigEN1998)),
            "ductility": lambda n : setattr(self, 'ductility', n.get_object_value(DuctilityConfigEN1998)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("direction", self.direction)
        writer.write_object_value("ductility", self.ductility)
        writer.write_additional_data_value(self.additional_data)
    

