from enum import Enum

class CoordinateSystemForLinearOrPlanarGeometry(str, Enum):
    Global_or_user = "global_or_user",
    Local_frame = "local_frame",
    Projected_frame = "projected_frame",

