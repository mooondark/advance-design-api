from enum import Enum

class HaunchPosition_API(str, Enum):
    No_haunch = "no_haunch",
    Haut_et_bas = "haut_et_bas",
    Haut = "haut",
    Bas = "bas",

