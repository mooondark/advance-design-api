from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .linear_element_stresses import LinearElementStresses
    from .support_stresses import SupportStresses

@dataclass
class ResStresses(Parsable):
    """
    Stresses result container
    """
    # Stresses specific to linear finite elements.
    linear_element: Optional[LinearElementStresses] = None
    # Stresses specific to supports (linear/planar/punctual).
    support: Optional[SupportStresses] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResStresses:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResStresses
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResStresses()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .linear_element_stresses import LinearElementStresses
        from .support_stresses import SupportStresses

        from .linear_element_stresses import LinearElementStresses
        from .support_stresses import SupportStresses

        fields: dict[str, Callable[[Any], None]] = {
            "linearElement": lambda n : setattr(self, 'linear_element', n.get_object_value(LinearElementStresses)),
            "support": lambda n : setattr(self, 'support', n.get_object_value(SupportStresses)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("linearElement", self.linear_element)
        writer.write_object_value("support", self.support)
    

