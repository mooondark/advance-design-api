from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .coordinate_system_for_punctual_geometry import CoordinateSystemForPunctualGeometry
    from .element_base import ElementBase
    from .e_i_d import EID
    from .impacting_surface import ImpactingSurface
    from .moment_components import MomentComponents
    from .pt3_d import Pt3D
    from .punching_properties import PunchingProperties

from .element_base import ElementBase

@dataclass
class ElementLoadPunctual(ElementBase, AdditionalDataHolder, Parsable):
    """
    Punctual load
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .coordinate_system_for_punctual_geometry import CoordinateSystemForPunctualGeometry

    # Loads coordinate system type (raw enum value).Unit: no unit Default value : 0
    coordinate_system_type: Optional[CoordinateSystemForPunctualGeometry] = CoordinateSystemForPunctualGeometry("global_or_user")
    # Force component FX (N), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N Default value : 0.0
    fx: Optional[float] = None
    # Force component FY (N), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N Default value : 0.0
    fy: Optional[float] = None
    # Force component FZ (N), at least one of FX, FY, FZ, MX, MY or MZ must not be 0. Unit: N Default value : 0.0
    fz: Optional[float] = None
    # gemetry point 3D (global repere).Unit: m Default value : (0, 0, 0)
    geom_pt: Optional[Pt3D] = None
    # Impacting surface dimensions.Default value : optional nullable object
    impacting_surface: Optional[ImpactingSurface] = None
    # EID of the load case already created
    load_case: Optional[EID] = None
    # Moment components, optional if any of FX, FY or FZ is not 0 Default value : optional nullable object
    moment: Optional[MomentComponents] = None
    # Punching object properties.Default value : optional nullable object
    punching: Optional[PunchingProperties] = None
    # User comment for the load element.Default value : null
    user_comment: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementLoadPunctual:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementLoadPunctual
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ElementLoadPunctual()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .coordinate_system_for_punctual_geometry import CoordinateSystemForPunctualGeometry
        from .element_base import ElementBase
        from .e_i_d import EID
        from .impacting_surface import ImpactingSurface
        from .moment_components import MomentComponents
        from .pt3_d import Pt3D
        from .punching_properties import PunchingProperties

        from .coordinate_system_for_punctual_geometry import CoordinateSystemForPunctualGeometry
        from .element_base import ElementBase
        from .e_i_d import EID
        from .impacting_surface import ImpactingSurface
        from .moment_components import MomentComponents
        from .pt3_d import Pt3D
        from .punching_properties import PunchingProperties

        fields: dict[str, Callable[[Any], None]] = {
            "coordinateSystemType": lambda n : setattr(self, 'coordinate_system_type', n.get_enum_value(CoordinateSystemForPunctualGeometry)),
            "fx": lambda n : setattr(self, 'fx', n.get_float_value()),
            "fy": lambda n : setattr(self, 'fy', n.get_float_value()),
            "fz": lambda n : setattr(self, 'fz', n.get_float_value()),
            "geomPt": lambda n : setattr(self, 'geom_pt', n.get_object_value(Pt3D)),
            "impactingSurface": lambda n : setattr(self, 'impacting_surface', n.get_object_value(ImpactingSurface)),
            "loadCase": lambda n : setattr(self, 'load_case', n.get_object_value(EID)),
            "moment": lambda n : setattr(self, 'moment', n.get_object_value(MomentComponents)),
            "punching": lambda n : setattr(self, 'punching', n.get_object_value(PunchingProperties)),
            "userComment": lambda n : setattr(self, 'user_comment', n.get_str_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("coordinateSystemType", self.coordinate_system_type)
        writer.write_float_value("fx", self.fx)
        writer.write_float_value("fy", self.fy)
        writer.write_float_value("fz", self.fz)
        writer.write_object_value("geomPt", self.geom_pt)
        writer.write_object_value("impactingSurface", self.impacting_surface)
        writer.write_object_value("loadCase", self.load_case)
        writer.write_object_value("moment", self.moment)
        writer.write_object_value("punching", self.punching)
        writer.write_str_value("userComment", self.user_comment)
        writer.write_additional_data_value(self.additional_data)
    

