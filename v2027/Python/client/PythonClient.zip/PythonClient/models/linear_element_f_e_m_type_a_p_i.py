from enum import Enum

class LinearElementFEMType_API(str, Enum):
    ELinearElementFEMTypeGeneral = "eLinearElementFEMTypeGeneral",
    ELinearElementFEMTypeCompositeBeam = "eLinearElementFEMTypeCompositeBeam",

