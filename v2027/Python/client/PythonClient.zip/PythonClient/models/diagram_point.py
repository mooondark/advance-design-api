from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class DiagramPoint(Parsable):
    """
    Represents a point of a piecewise stiffness diagram.
    """
    # Generalized displacement or rotation value at the point.Unit: m or rad Default value : 0.0
    d_val: Optional[float] = None
    # Stiffness value associated with the displacement/rotation at the point.Unit: N/m or N·m/rad Default value : 0.0
    k_val: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DiagramPoint:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DiagramPoint
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DiagramPoint()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "dVal": lambda n : setattr(self, 'd_val', n.get_float_value()),
            "kVal": lambda n : setattr(self, 'k_val', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("dVal", self.d_val)
        writer.write_float_value("kVal", self.k_val)
    

