from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LinearElementStresses(Parsable):
    """
    Stresses container for linear elements (min/max etc.).
    """
    # Von Mises
    sv: Optional[float] = None
    # Sxx max
    sxx_max: Optional[float] = None
    # Sxx min
    sxx_min: Optional[float] = None
    # Sxy max
    sxy_max: Optional[float] = None
    # Sxy min
    sxy_min: Optional[float] = None
    # Sxz max
    sxz_max: Optional[float] = None
    # Sxz min
    sxz_min: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LinearElementStresses:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LinearElementStresses
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LinearElementStresses()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "sv": lambda n : setattr(self, 'sv', n.get_float_value()),
            "sxxMax": lambda n : setattr(self, 'sxx_max', n.get_float_value()),
            "sxxMin": lambda n : setattr(self, 'sxx_min', n.get_float_value()),
            "sxyMax": lambda n : setattr(self, 'sxy_max', n.get_float_value()),
            "sxyMin": lambda n : setattr(self, 'sxy_min', n.get_float_value()),
            "sxzMax": lambda n : setattr(self, 'sxz_max', n.get_float_value()),
            "sxzMin": lambda n : setattr(self, 'sxz_min', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("sv", self.sv)
        writer.write_float_value("sxxMax", self.sxx_max)
        writer.write_float_value("sxxMin", self.sxx_min)
        writer.write_float_value("sxyMax", self.sxy_max)
        writer.write_float_value("sxyMin", self.sxy_min)
        writer.write_float_value("sxzMax", self.sxz_max)
        writer.write_float_value("sxzMin", self.sxz_min)
    

