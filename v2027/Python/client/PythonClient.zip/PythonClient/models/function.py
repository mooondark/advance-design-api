from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .function_point import FunctionPoint

@dataclass
class Function(Parsable):
    """
    Function definition
    """
    # Abscissa type (integer)
    abscissa_type: Optional[int] = None
    # Name of the function
    name: Optional[str] = None
    # Ordinate type (integer)
    ordinate_type: Optional[int] = None
    # List of function points
    points: Optional[list[FunctionPoint]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Function:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Function
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Function()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .function_point import FunctionPoint

        from .function_point import FunctionPoint

        fields: dict[str, Callable[[Any], None]] = {
            "abscissaType": lambda n : setattr(self, 'abscissa_type', n.get_int_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "ordinateType": lambda n : setattr(self, 'ordinate_type', n.get_int_value()),
            "points": lambda n : setattr(self, 'points', n.get_collection_of_object_values(FunctionPoint)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("abscissaType", self.abscissa_type)
        writer.write_str_value("name", self.name)
        writer.write_int_value("ordinateType", self.ordinate_type)
        writer.write_collection_of_object_values("points", self.points)
    

