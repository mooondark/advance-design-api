from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_area_span_direction import LoadAreaSpanDirection
    from .load_transfer_method import LoadTransferMethod

@dataclass
class LoadAreaLoadTransfer(Parsable):
    """
    Load area load transfer(to suporting elements) properties
    """
    from .load_transfer_method import LoadTransferMethod

    # Load transfer method: The failure lines method is appropriate for quadrilateral load areas with uniform distributed load. In other scenarios, is advisable to use the FEM transfer method. This method relies on a background FEM analysis on a shell with geometry equivalent to load area, made of rigid material, with general mesh settings and with supporting edges.Default value : LoadTransferMethod.eLoadTransferMethodAuto
    load_transfer_method_type: Optional[LoadTransferMethod] = LoadTransferMethod("eLoadTransferMethodAuto")
    from .load_area_span_direction import LoadAreaSpanDirection

    # Load area Span loads discharging direction in local axes of the load areaDefault value : LoadAreaSpanDirection.eFloorDeckLoadSpanDirectionXY
    load_transfer_span_direction_type: Optional[LoadAreaSpanDirection] = LoadAreaSpanDirection("eFloorDeckLoadSpanDirectionXY")
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadAreaLoadTransfer:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadAreaLoadTransfer
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadAreaLoadTransfer()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_area_span_direction import LoadAreaSpanDirection
        from .load_transfer_method import LoadTransferMethod

        from .load_area_span_direction import LoadAreaSpanDirection
        from .load_transfer_method import LoadTransferMethod

        fields: dict[str, Callable[[Any], None]] = {
            "loadTransferMethodType": lambda n : setattr(self, 'load_transfer_method_type', n.get_enum_value(LoadTransferMethod)),
            "loadTransferSpanDirectionType": lambda n : setattr(self, 'load_transfer_span_direction_type', n.get_enum_value(LoadAreaSpanDirection)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("loadTransferMethodType", self.load_transfer_method_type)
        writer.write_enum_value("loadTransferSpanDirectionType", self.load_transfer_span_direction_type)
    

