from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PushOverDirections(Parsable):
    """
    Push over load directions configuration
    """
    # Enable X- directionDefault: false
    x_minus: Optional[bool] = None
    # Enable X+ directionDefault: false
    x_plus: Optional[bool] = None
    # Enable Y- directionDefault: false
    y_minus: Optional[bool] = None
    # Enable Y+ directionDefault: false
    y_plus: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverDirections:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverDirections
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverDirections()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "xMinus": lambda n : setattr(self, 'x_minus', n.get_bool_value()),
            "xPlus": lambda n : setattr(self, 'x_plus', n.get_bool_value()),
            "yMinus": lambda n : setattr(self, 'y_minus', n.get_bool_value()),
            "yPlus": lambda n : setattr(self, 'y_plus', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("xMinus", self.x_minus)
        writer.write_bool_value("xPlus", self.x_plus)
        writer.write_bool_value("yMinus", self.y_minus)
        writer.write_bool_value("yPlus", self.y_plus)
    

