from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class StructureSeismicIBC(Parsable):
    """
    Structure parameters for IBC seismic load case family
    """
    # Accidental torsionUnit: adimensionalDefault: 0.0
    accidental_torsion: Optional[float] = None
    # Number of floorsUnit: integerDefault: 0
    floors_no: Optional[int] = None
    # Regular structure flagDefault: true
    regular_structure: Optional[bool] = None
    # SFRS Check flagDefault: false
    sfsr_check: Optional[bool] = None
    # Total height of structureUnit: lengthRange: 0 to 2000Default: 0.0
    total_height: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> StructureSeismicIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: StructureSeismicIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return StructureSeismicIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "accidentalTorsion": lambda n : setattr(self, 'accidental_torsion', n.get_float_value()),
            "floorsNo": lambda n : setattr(self, 'floors_no', n.get_int_value()),
            "regularStructure": lambda n : setattr(self, 'regular_structure', n.get_bool_value()),
            "sfsrCheck": lambda n : setattr(self, 'sfsr_check', n.get_bool_value()),
            "totalHeight": lambda n : setattr(self, 'total_height', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("accidentalTorsion", self.accidental_torsion)
        writer.write_int_value("floorsNo", self.floors_no)
        writer.write_bool_value("regularStructure", self.regular_structure)
        writer.write_bool_value("sfsrCheck", self.sfsr_check)
        writer.write_float_value("totalHeight", self.total_height)
    

