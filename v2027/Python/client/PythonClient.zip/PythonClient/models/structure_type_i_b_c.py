from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .type_structure_i_b_c_a_p_i import TypeStructureIBC_API

@dataclass
class StructureTypeIBC(Parsable):
    """
    Structure type and SFRS configuration for IBC effect
    """
    from .type_structure_i_b_c_a_p_i import TypeStructureIBC_API

    # Type of structureDefault: TypeStructureIBC_API.StructureResistMomentFrame
    type_structure: Optional[TypeStructureIBC_API] = TypeStructureIBC_API("StructureResistMomentFrame")
    # Type of SFRS (material-based selection)Default: 0
    type_s_r_f_s: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> StructureTypeIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: StructureTypeIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return StructureTypeIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .type_structure_i_b_c_a_p_i import TypeStructureIBC_API

        from .type_structure_i_b_c_a_p_i import TypeStructureIBC_API

        fields: dict[str, Callable[[Any], None]] = {
            "typeSRFS": lambda n : setattr(self, 'type_s_r_f_s', n.get_int_value()),
            "typeStructure": lambda n : setattr(self, 'type_structure', n.get_enum_value(TypeStructureIBC_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("typeSRFS", self.type_s_r_f_s)
        writer.write_enum_value("typeStructure", self.type_structure)
    

