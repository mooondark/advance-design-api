from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .material_other import MaterialOther
    from .material_reinforced_concrete import MaterialReinforcedConcrete
    from .material_rigid import MaterialRigid
    from .material_steel import MaterialSteel
    from .material_wood import MaterialWood
    from .material_wood_north_america import MaterialWoodNorthAmerica

@dataclass
class Material(Parsable):
    """
    Base class for all material objects. Requires the `$type` discriminator when serialized for the API.
    """
    # Material nameDefault value: empty string
    name: Optional[str] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Material:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Material
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "MaterialOther".casefold():
            from .material_other import MaterialOther

            return MaterialOther()
        if mapping_value and mapping_value.casefold() == "MaterialReinforcedConcrete".casefold():
            from .material_reinforced_concrete import MaterialReinforcedConcrete

            return MaterialReinforcedConcrete()
        if mapping_value and mapping_value.casefold() == "MaterialRigid".casefold():
            from .material_rigid import MaterialRigid

            return MaterialRigid()
        if mapping_value and mapping_value.casefold() == "MaterialSteel".casefold():
            from .material_steel import MaterialSteel

            return MaterialSteel()
        if mapping_value and mapping_value.casefold() == "MaterialWood".casefold():
            from .material_wood import MaterialWood

            return MaterialWood()
        if mapping_value and mapping_value.casefold() == "MaterialWoodNorthAmerica".casefold():
            from .material_wood_north_america import MaterialWoodNorthAmerica

            return MaterialWoodNorthAmerica()
        return Material()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .material_other import MaterialOther
        from .material_reinforced_concrete import MaterialReinforcedConcrete
        from .material_rigid import MaterialRigid
        from .material_steel import MaterialSteel
        from .material_wood import MaterialWood
        from .material_wood_north_america import MaterialWoodNorthAmerica

        from .material_other import MaterialOther
        from .material_reinforced_concrete import MaterialReinforcedConcrete
        from .material_rigid import MaterialRigid
        from .material_steel import MaterialSteel
        from .material_wood import MaterialWood
        from .material_wood_north_america import MaterialWoodNorthAmerica

        fields: dict[str, Callable[[Any], None]] = {
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("name", self.name)
        writer.write_str_value("$type", self.type)
    

