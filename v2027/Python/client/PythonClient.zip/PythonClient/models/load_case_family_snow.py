from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .load_case_family import LoadCaseFamily
    from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
    from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
    from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC

from .load_case_family import LoadCaseFamily

@dataclass
class LoadCaseFamily_Snow(LoadCaseFamily, AdditionalDataHolder, Parsable):
    """
    Snow loads case family, load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_Snow:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_Snow
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_Snow_1991_1_3".casefold():
            from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3

            return LoadCaseFamily_Snow_1991_1_3()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowCBN".casefold():
            from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN

            return LoadCaseFamily_SnowCBN()
        if mapping_value and mapping_value.casefold() == "LoadCaseFamily_SnowIBC".casefold():
            from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC

            return LoadCaseFamily_SnowIBC()
        return LoadCaseFamily_Snow()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .load_case_family import LoadCaseFamily
        from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
        from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
        from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC

        from .load_case_family import LoadCaseFamily
        from .load_case_family_snow_1991_1_3 import LoadCaseFamily_Snow_1991_1_3
        from .load_case_family_snow_c_b_n import LoadCaseFamily_SnowCBN
        from .load_case_family_snow_i_b_c import LoadCaseFamily_SnowIBC

        fields: dict[str, Callable[[Any], None]] = {
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_additional_data_value(self.additional_data)
    

