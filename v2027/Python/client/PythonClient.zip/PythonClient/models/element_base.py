from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_advanced_linear_support import ElementAdvancedLinearSupport
    from .element_advanced_planar_support import ElementAdvancedPlanarSupport
    from .element_advanced_punctual_support import ElementAdvancedPunctualSupport
    from .element_elastic_linear_support import ElementElasticLinearSupport
    from .element_elastic_planar_support import ElementElasticPlanarSupport
    from .element_elastic_punctual_support import ElementElasticPunctualSupport
    from .element_imposed_displacement import ElementImposedDisplacement
    from .element_linear import ElementLinear
    from .element_load_area import ElementLoadArea
    from .element_load_linear import ElementLoadLinear
    from .element_load_planar import ElementLoadPlanar
    from .element_load_punctual import ElementLoadPunctual
    from .element_mass import ElementMass
    from .element_planar import ElementPlanar
    from .element_rigid_linear_support import ElementRigidLinearSupport
    from .element_rigid_planar_support import ElementRigidPlanarSupport
    from .element_rigid_punctual_support import ElementRigidPunctualSupport
    from .element_single_pile import ElementSinglePile
    from .element_t_c_linear_support import ElementTCLinearSupport
    from .element_t_c_planar_support import ElementTCPlanarSupport
    from .element_t_c_punctual_support import ElementTCPunctualSupport
    from .family_support_linear import FamilySupportLinear
    from .family_support_planar import FamilySupportPlanar
    from .family_support_punctual import FamilySupportPunctual

@dataclass
class ElementBase(Parsable):
    """
    Base class for all geometric/model objects. Requires the `type_class` discriminator when serialized for the API.
    """
    # The Type property
    type: Optional[str] = None
    # user name of the element used for additional identification
    user_name: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ElementBase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ElementBase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "ElementAdvancedLinearSupport".casefold():
            from .element_advanced_linear_support import ElementAdvancedLinearSupport

            return ElementAdvancedLinearSupport()
        if mapping_value and mapping_value.casefold() == "ElementAdvancedPlanarSupport".casefold():
            from .element_advanced_planar_support import ElementAdvancedPlanarSupport

            return ElementAdvancedPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ElementAdvancedPunctualSupport".casefold():
            from .element_advanced_punctual_support import ElementAdvancedPunctualSupport

            return ElementAdvancedPunctualSupport()
        if mapping_value and mapping_value.casefold() == "ElementElasticLinearSupport".casefold():
            from .element_elastic_linear_support import ElementElasticLinearSupport

            return ElementElasticLinearSupport()
        if mapping_value and mapping_value.casefold() == "ElementElasticPlanarSupport".casefold():
            from .element_elastic_planar_support import ElementElasticPlanarSupport

            return ElementElasticPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ElementElasticPunctualSupport".casefold():
            from .element_elastic_punctual_support import ElementElasticPunctualSupport

            return ElementElasticPunctualSupport()
        if mapping_value and mapping_value.casefold() == "ElementImposedDisplacement".casefold():
            from .element_imposed_displacement import ElementImposedDisplacement

            return ElementImposedDisplacement()
        if mapping_value and mapping_value.casefold() == "ElementLinear".casefold():
            from .element_linear import ElementLinear

            return ElementLinear()
        if mapping_value and mapping_value.casefold() == "ElementLoadArea".casefold():
            from .element_load_area import ElementLoadArea

            return ElementLoadArea()
        if mapping_value and mapping_value.casefold() == "ElementLoadLinear".casefold():
            from .element_load_linear import ElementLoadLinear

            return ElementLoadLinear()
        if mapping_value and mapping_value.casefold() == "ElementLoadPlanar".casefold():
            from .element_load_planar import ElementLoadPlanar

            return ElementLoadPlanar()
        if mapping_value and mapping_value.casefold() == "ElementLoadPunctual".casefold():
            from .element_load_punctual import ElementLoadPunctual

            return ElementLoadPunctual()
        if mapping_value and mapping_value.casefold() == "ElementMass".casefold():
            from .element_mass import ElementMass

            return ElementMass()
        if mapping_value and mapping_value.casefold() == "ElementPlanar".casefold():
            from .element_planar import ElementPlanar

            return ElementPlanar()
        if mapping_value and mapping_value.casefold() == "ElementRigidLinearSupport".casefold():
            from .element_rigid_linear_support import ElementRigidLinearSupport

            return ElementRigidLinearSupport()
        if mapping_value and mapping_value.casefold() == "ElementRigidPlanarSupport".casefold():
            from .element_rigid_planar_support import ElementRigidPlanarSupport

            return ElementRigidPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ElementRigidPunctualSupport".casefold():
            from .element_rigid_punctual_support import ElementRigidPunctualSupport

            return ElementRigidPunctualSupport()
        if mapping_value and mapping_value.casefold() == "ElementSinglePile".casefold():
            from .element_single_pile import ElementSinglePile

            return ElementSinglePile()
        if mapping_value and mapping_value.casefold() == "ElementTCLinearSupport".casefold():
            from .element_t_c_linear_support import ElementTCLinearSupport

            return ElementTCLinearSupport()
        if mapping_value and mapping_value.casefold() == "ElementTCPlanarSupport".casefold():
            from .element_t_c_planar_support import ElementTCPlanarSupport

            return ElementTCPlanarSupport()
        if mapping_value and mapping_value.casefold() == "ElementTCPunctualSupport".casefold():
            from .element_t_c_punctual_support import ElementTCPunctualSupport

            return ElementTCPunctualSupport()
        if mapping_value and mapping_value.casefold() == "FamilySupportLinear".casefold():
            from .family_support_linear import FamilySupportLinear

            return FamilySupportLinear()
        if mapping_value and mapping_value.casefold() == "FamilySupportPlanar".casefold():
            from .family_support_planar import FamilySupportPlanar

            return FamilySupportPlanar()
        if mapping_value and mapping_value.casefold() == "FamilySupportPunctual".casefold():
            from .family_support_punctual import FamilySupportPunctual

            return FamilySupportPunctual()
        return ElementBase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_advanced_linear_support import ElementAdvancedLinearSupport
        from .element_advanced_planar_support import ElementAdvancedPlanarSupport
        from .element_advanced_punctual_support import ElementAdvancedPunctualSupport
        from .element_elastic_linear_support import ElementElasticLinearSupport
        from .element_elastic_planar_support import ElementElasticPlanarSupport
        from .element_elastic_punctual_support import ElementElasticPunctualSupport
        from .element_imposed_displacement import ElementImposedDisplacement
        from .element_linear import ElementLinear
        from .element_load_area import ElementLoadArea
        from .element_load_linear import ElementLoadLinear
        from .element_load_planar import ElementLoadPlanar
        from .element_load_punctual import ElementLoadPunctual
        from .element_mass import ElementMass
        from .element_planar import ElementPlanar
        from .element_rigid_linear_support import ElementRigidLinearSupport
        from .element_rigid_planar_support import ElementRigidPlanarSupport
        from .element_rigid_punctual_support import ElementRigidPunctualSupport
        from .element_single_pile import ElementSinglePile
        from .element_t_c_linear_support import ElementTCLinearSupport
        from .element_t_c_planar_support import ElementTCPlanarSupport
        from .element_t_c_punctual_support import ElementTCPunctualSupport
        from .family_support_linear import FamilySupportLinear
        from .family_support_planar import FamilySupportPlanar
        from .family_support_punctual import FamilySupportPunctual

        from .element_advanced_linear_support import ElementAdvancedLinearSupport
        from .element_advanced_planar_support import ElementAdvancedPlanarSupport
        from .element_advanced_punctual_support import ElementAdvancedPunctualSupport
        from .element_elastic_linear_support import ElementElasticLinearSupport
        from .element_elastic_planar_support import ElementElasticPlanarSupport
        from .element_elastic_punctual_support import ElementElasticPunctualSupport
        from .element_imposed_displacement import ElementImposedDisplacement
        from .element_linear import ElementLinear
        from .element_load_area import ElementLoadArea
        from .element_load_linear import ElementLoadLinear
        from .element_load_planar import ElementLoadPlanar
        from .element_load_punctual import ElementLoadPunctual
        from .element_mass import ElementMass
        from .element_planar import ElementPlanar
        from .element_rigid_linear_support import ElementRigidLinearSupport
        from .element_rigid_planar_support import ElementRigidPlanarSupport
        from .element_rigid_punctual_support import ElementRigidPunctualSupport
        from .element_single_pile import ElementSinglePile
        from .element_t_c_linear_support import ElementTCLinearSupport
        from .element_t_c_planar_support import ElementTCPlanarSupport
        from .element_t_c_punctual_support import ElementTCPunctualSupport
        from .family_support_linear import FamilySupportLinear
        from .family_support_planar import FamilySupportPlanar
        from .family_support_punctual import FamilySupportPunctual

        fields: dict[str, Callable[[Any], None]] = {
            "$type": lambda n : setattr(self, 'type', n.get_str_value()),
            "userName": lambda n : setattr(self, 'user_name', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("$type", self.type)
        writer.write_int_value("userName", self.user_name)
    

