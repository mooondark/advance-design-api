from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_base import ResBase
    from .res_element_linear import ResElementLinear
    from .res_element_planar import ResElementPlanar
    from .res_linear_support import ResLinearSupport
    from .res_node import ResNode
    from .res_planar_node import ResPlanarNode
    from .res_planar_support import ResPlanarSupport
    from .res_punctual_support import ResPunctualSupport

@dataclass
class ResBaseListApiResponse_data(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ResBase, ResElementLinear, ResElementPlanar, ResLinearSupport, ResNode, ResPlanarNode, ResPlanarSupport, ResPunctualSupport
    """
    # Composed type representation for type ResBase
    res_base: Optional[ResBase] = None
    # Composed type representation for type ResElementLinear
    res_element_linear: Optional[ResElementLinear] = None
    # Composed type representation for type ResElementPlanar
    res_element_planar: Optional[ResElementPlanar] = None
    # Composed type representation for type ResLinearSupport
    res_linear_support: Optional[ResLinearSupport] = None
    # Composed type representation for type ResNode
    res_node: Optional[ResNode] = None
    # Composed type representation for type ResPlanarNode
    res_planar_node: Optional[ResPlanarNode] = None
    # Composed type representation for type ResPlanarSupport
    res_planar_support: Optional[ResPlanarSupport] = None
    # Composed type representation for type ResPunctualSupport
    res_punctual_support: Optional[ResPunctualSupport] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResBaseListApiResponse_data:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResBaseListApiResponse_data
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ResBaseListApiResponse_data()
        if mapping_value and mapping_value.casefold() == "ResBase".casefold():
            from .res_base import ResBase

            result.res_base = ResBase()
        elif mapping_value and mapping_value.casefold() == "ResElementLinear".casefold():
            from .res_element_linear import ResElementLinear

            result.res_element_linear = ResElementLinear()
        elif mapping_value and mapping_value.casefold() == "ResElementPlanar".casefold():
            from .res_element_planar import ResElementPlanar

            result.res_element_planar = ResElementPlanar()
        elif mapping_value and mapping_value.casefold() == "ResLinearSupport".casefold():
            from .res_linear_support import ResLinearSupport

            result.res_linear_support = ResLinearSupport()
        elif mapping_value and mapping_value.casefold() == "ResNode".casefold():
            from .res_node import ResNode

            result.res_node = ResNode()
        elif mapping_value and mapping_value.casefold() == "ResPlanarNode".casefold():
            from .res_planar_node import ResPlanarNode

            result.res_planar_node = ResPlanarNode()
        elif mapping_value and mapping_value.casefold() == "ResPlanarSupport".casefold():
            from .res_planar_support import ResPlanarSupport

            result.res_planar_support = ResPlanarSupport()
        elif mapping_value and mapping_value.casefold() == "ResPunctualSupport".casefold():
            from .res_punctual_support import ResPunctualSupport

            result.res_punctual_support = ResPunctualSupport()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_base import ResBase
        from .res_element_linear import ResElementLinear
        from .res_element_planar import ResElementPlanar
        from .res_linear_support import ResLinearSupport
        from .res_node import ResNode
        from .res_planar_node import ResPlanarNode
        from .res_planar_support import ResPlanarSupport
        from .res_punctual_support import ResPunctualSupport

        if self.res_base:
            return self.res_base.get_field_deserializers()
        if self.res_element_linear:
            return self.res_element_linear.get_field_deserializers()
        if self.res_element_planar:
            return self.res_element_planar.get_field_deserializers()
        if self.res_linear_support:
            return self.res_linear_support.get_field_deserializers()
        if self.res_node:
            return self.res_node.get_field_deserializers()
        if self.res_planar_node:
            return self.res_planar_node.get_field_deserializers()
        if self.res_planar_support:
            return self.res_planar_support.get_field_deserializers()
        if self.res_punctual_support:
            return self.res_punctual_support.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.res_base:
            writer.write_object_value(None, self.res_base)
        elif self.res_element_linear:
            writer.write_object_value(None, self.res_element_linear)
        elif self.res_element_planar:
            writer.write_object_value(None, self.res_element_planar)
        elif self.res_linear_support:
            writer.write_object_value(None, self.res_linear_support)
        elif self.res_node:
            writer.write_object_value(None, self.res_node)
        elif self.res_planar_node:
            writer.write_object_value(None, self.res_planar_node)
        elif self.res_planar_support:
            writer.write_object_value(None, self.res_planar_support)
        elif self.res_punctual_support:
            writer.write_object_value(None, self.res_punctual_support)
    

