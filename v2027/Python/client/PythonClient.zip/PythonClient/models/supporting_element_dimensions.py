from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .footing_template import FootingTemplate

@dataclass
class SupportingElementDimensions(Parsable):
    """
    Defines a generic supporting element and its overall dimensions.
    """
    from .footing_template import FootingTemplate

    # Application-specific type identifier of the supporting element.Unit: no unit Default value : FootingTemplate.TypeAuto
    supporting_element_type: Optional[FootingTemplate] = FootingTemplate("TypeAuto")
    # Height h of the supported element along global Z (m).Unit: m Default value : 0.3
    height_of_supp_elem_h: Optional[float] = None
    # Length b (only for punctual supports) of the supported element along global Y (m).Unit: m Default value : 0.3
    length_of_supp_elem_b: Optional[float] = None
    # Width a of the supported element along global X (m).Unit: m Default value : 0.3
    width_of_supp_elem_a: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SupportingElementDimensions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SupportingElementDimensions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SupportingElementDimensions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .footing_template import FootingTemplate

        from .footing_template import FootingTemplate

        fields: dict[str, Callable[[Any], None]] = {
            "heightOfSuppElem_h": lambda n : setattr(self, 'height_of_supp_elem_h', n.get_float_value()),
            "lengthOfSuppElem_b": lambda n : setattr(self, 'length_of_supp_elem_b', n.get_float_value()),
            "supportingElementType": lambda n : setattr(self, 'supporting_element_type', n.get_enum_value(FootingTemplate)),
            "widthOfSuppElem_a": lambda n : setattr(self, 'width_of_supp_elem_a', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("heightOfSuppElem_h", self.height_of_supp_elem_h)
        writer.write_float_value("lengthOfSuppElem_b", self.length_of_supp_elem_b)
        writer.write_enum_value("supportingElementType", self.supporting_element_type)
        writer.write_float_value("widthOfSuppElem_a", self.width_of_supp_elem_a)
    

