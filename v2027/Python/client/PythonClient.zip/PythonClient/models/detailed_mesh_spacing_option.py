from enum import Enum

class DetailedMeshSpacingOption(str, Enum):
    Uniform = "uniform",
    Beginning = "beginning",
    End = "end",
    Center = "center",
    Both_sides = "both_sides",

