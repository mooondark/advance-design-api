from enum import Enum

class PlanarElementType(str, Enum):
    Membrane = "membrane",
    Plate = "plate",
    Shell = "shell",
    Deformation_plane = "deformation_plane",
    Steeldeck = "steeldeck",
    LayeredShell = "layeredShell",
    Slabonsteeldeck = "slabonsteeldeck",
    Planar_no_of_types = "planar_no_of_types",

