from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .informational_element_type_enum import InformationalElementTypeEnum
    from .query_base import QueryBase
    from .query_info_load_case import QueryInfoLoadCase

from .query_base import QueryBase

@dataclass
class QueryInfoModel(QueryBase, AdditionalDataHolder, Parsable):
    """
    Query definition for informational elements by type.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    from .informational_element_type_enum import InformationalElementTypeEnum

    # Type of the informational element to query.
    informational_element_type: Optional[InformationalElementTypeEnum] = InformationalElementTypeEnum("InfoObjBase")
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> QueryInfoModel:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: QueryInfoModel
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "QueryInfoLoadCase".casefold():
            from .query_info_load_case import QueryInfoLoadCase

            return QueryInfoLoadCase()
        return QueryInfoModel()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .informational_element_type_enum import InformationalElementTypeEnum
        from .query_base import QueryBase
        from .query_info_load_case import QueryInfoLoadCase

        from .informational_element_type_enum import InformationalElementTypeEnum
        from .query_base import QueryBase
        from .query_info_load_case import QueryInfoLoadCase

        fields: dict[str, Callable[[Any], None]] = {
            "informationalElementType": lambda n : setattr(self, 'informational_element_type', n.get_enum_value(InformationalElementTypeEnum)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_enum_value("informationalElementType", self.informational_element_type)
        writer.write_additional_data_value(self.additional_data)
    

