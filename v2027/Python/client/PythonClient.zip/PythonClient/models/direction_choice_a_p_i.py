from enum import Enum

class DirectionChoice_API(str, Enum):
    X = "X",
    Y = "Y",
    Z = "Z",
    XY = "XY",

