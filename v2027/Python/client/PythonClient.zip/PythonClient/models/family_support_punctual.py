from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .element_advanced_punctual_support import ElementAdvancedPunctualSupport
    from .element_base import ElementBase
    from .element_elastic_punctual_support import ElementElasticPunctualSupport
    from .element_rigid_punctual_support import ElementRigidPunctualSupport
    from .element_t_c_punctual_support import ElementTCPunctualSupport
    from .e_i_d import EID
    from .footing_dimensions import FootingDimensions
    from .pt3_d import Pt3D
    from .punching_properties import PunchingProperties
    from .supporting_element_dimensions import SupportingElementDimensions

from .element_base import ElementBase

@dataclass
class FamilySupportPunctual(ElementBase, AdditionalDataHolder, Parsable):
    """
    Punctual support
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Indicates whether the element is active in the analysis.Unit: no unit Default value : true
    element_active: Optional[bool] = None
    # Footing dimensions for the support.Default value : optional nullable object
    footing: Optional[FootingDimensions] = None
    # Point in 3D space expressed in global axes.Unit: m Default value : (0, 0, 0)
    geom_pt: Optional[Pt3D] = None
    # EID of the material already created
    material: Optional[EID] = None
    # Punching object properties for the support.    Default value : optional nullable object
    punching: Optional[PunchingProperties] = None
    # Supporting element information.Default value : optional nullable object
    supp_element: Optional[SupportingElementDimensions] = None
    # The Type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FamilySupportPunctual:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FamilySupportPunctual
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("$type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        if mapping_value and mapping_value.casefold() == "ElementAdvancedPunctualSupport".casefold():
            from .element_advanced_punctual_support import ElementAdvancedPunctualSupport

            return ElementAdvancedPunctualSupport()
        if mapping_value and mapping_value.casefold() == "ElementElasticPunctualSupport".casefold():
            from .element_elastic_punctual_support import ElementElasticPunctualSupport

            return ElementElasticPunctualSupport()
        if mapping_value and mapping_value.casefold() == "ElementRigidPunctualSupport".casefold():
            from .element_rigid_punctual_support import ElementRigidPunctualSupport

            return ElementRigidPunctualSupport()
        if mapping_value and mapping_value.casefold() == "ElementTCPunctualSupport".casefold():
            from .element_t_c_punctual_support import ElementTCPunctualSupport

            return ElementTCPunctualSupport()
        return FamilySupportPunctual()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .element_advanced_punctual_support import ElementAdvancedPunctualSupport
        from .element_base import ElementBase
        from .element_elastic_punctual_support import ElementElasticPunctualSupport
        from .element_rigid_punctual_support import ElementRigidPunctualSupport
        from .element_t_c_punctual_support import ElementTCPunctualSupport
        from .e_i_d import EID
        from .footing_dimensions import FootingDimensions
        from .pt3_d import Pt3D
        from .punching_properties import PunchingProperties
        from .supporting_element_dimensions import SupportingElementDimensions

        from .element_advanced_punctual_support import ElementAdvancedPunctualSupport
        from .element_base import ElementBase
        from .element_elastic_punctual_support import ElementElasticPunctualSupport
        from .element_rigid_punctual_support import ElementRigidPunctualSupport
        from .element_t_c_punctual_support import ElementTCPunctualSupport
        from .e_i_d import EID
        from .footing_dimensions import FootingDimensions
        from .pt3_d import Pt3D
        from .punching_properties import PunchingProperties
        from .supporting_element_dimensions import SupportingElementDimensions

        fields: dict[str, Callable[[Any], None]] = {
            "elementActive": lambda n : setattr(self, 'element_active', n.get_bool_value()),
            "footing": lambda n : setattr(self, 'footing', n.get_object_value(FootingDimensions)),
            "geomPt": lambda n : setattr(self, 'geom_pt', n.get_object_value(Pt3D)),
            "material": lambda n : setattr(self, 'material', n.get_object_value(EID)),
            "punching": lambda n : setattr(self, 'punching', n.get_object_value(PunchingProperties)),
            "suppElement": lambda n : setattr(self, 'supp_element', n.get_object_value(SupportingElementDimensions)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_bool_value("elementActive", self.element_active)
        writer.write_object_value("footing", self.footing)
        writer.write_object_value("geomPt", self.geom_pt)
        writer.write_object_value("material", self.material)
        writer.write_object_value("punching", self.punching)
        writer.write_object_value("suppElement", self.supp_element)
        writer.write_additional_data_value(self.additional_data)
    

