from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .imposed_cpe_type_wind_e_n1991_1_4_a_p_i import ImposedCpeType_Wind_EN1991_1_4_API
    from .pitch_type_wind_e_n1991_1_4_a_p_i import PitchType_Wind_EN1991_1_4_API

@dataclass
class AutoGenerationParameters_Wind_EN1991_1_4(Parsable):
    """
    Auto generation parameters for Wind EN 1991-1-4
    """
    from .imposed_cpe_type_wind_e_n1991_1_4_a_p_i import ImposedCpeType_Wind_EN1991_1_4_API

    # Imposed CPE typeUnit: -Default: e_CPE_MODE_default
    imposed_cpe_type: Optional[ImposedCpeType_Wind_EN1991_1_4_API] = ImposedCpeType_Wind_EN1991_1_4_API("e_CPE_MODE_default")
    from .pitch_type_wind_e_n1991_1_4_a_p_i import PitchType_Wind_EN1991_1_4_API

    # Pitch typeUnit: -Default: PITCH_TYPE_MONO
    pitch_type: Optional[PitchType_Wind_EN1991_1_4_API] = PitchType_Wind_EN1991_1_4_API("PITCH_TYPE_MONO")
    # Automatic calculation of Cpe/CpiUnit: -Default: true
    auto_calculation_cpe_cpi: Optional[bool] = None
    # Load generationUnit: -Default: true
    load_generation: Optional[bool] = None
    # Pressure coefficientUnit: -Default: true
    pressure_coeff: Optional[bool] = None
    # Split wind wallsUnit: -Default: false
    split_wind_walls: Optional[bool] = None
    # Use CTICM code updatesUnit: -Default: true
    use_c_t_i_c_m_code_updates: Optional[bool] = None
    # Wind wall statusUnit: -Default: true
    wind_wall_status: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AutoGenerationParameters_Wind_EN1991_1_4:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AutoGenerationParameters_Wind_EN1991_1_4
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AutoGenerationParameters_Wind_EN1991_1_4()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .imposed_cpe_type_wind_e_n1991_1_4_a_p_i import ImposedCpeType_Wind_EN1991_1_4_API
        from .pitch_type_wind_e_n1991_1_4_a_p_i import PitchType_Wind_EN1991_1_4_API

        from .imposed_cpe_type_wind_e_n1991_1_4_a_p_i import ImposedCpeType_Wind_EN1991_1_4_API
        from .pitch_type_wind_e_n1991_1_4_a_p_i import PitchType_Wind_EN1991_1_4_API

        fields: dict[str, Callable[[Any], None]] = {
            "autoCalculationCpeCpi": lambda n : setattr(self, 'auto_calculation_cpe_cpi', n.get_bool_value()),
            "imposedCpeType": lambda n : setattr(self, 'imposed_cpe_type', n.get_enum_value(ImposedCpeType_Wind_EN1991_1_4_API)),
            "loadGeneration": lambda n : setattr(self, 'load_generation', n.get_bool_value()),
            "pitchType": lambda n : setattr(self, 'pitch_type', n.get_enum_value(PitchType_Wind_EN1991_1_4_API)),
            "pressureCoeff": lambda n : setattr(self, 'pressure_coeff', n.get_bool_value()),
            "splitWindWalls": lambda n : setattr(self, 'split_wind_walls', n.get_bool_value()),
            "useCTICMCodeUpdates": lambda n : setattr(self, 'use_c_t_i_c_m_code_updates', n.get_bool_value()),
            "windWallStatus": lambda n : setattr(self, 'wind_wall_status', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("autoCalculationCpeCpi", self.auto_calculation_cpe_cpi)
        writer.write_enum_value("imposedCpeType", self.imposed_cpe_type)
        writer.write_bool_value("loadGeneration", self.load_generation)
        writer.write_enum_value("pitchType", self.pitch_type)
        writer.write_bool_value("pressureCoeff", self.pressure_coeff)
        writer.write_bool_value("splitWindWalls", self.split_wind_walls)
        writer.write_bool_value("useCTICMCodeUpdates", self.use_c_t_i_c_m_code_updates)
        writer.write_bool_value("windWallStatus", self.wind_wall_status)
    

