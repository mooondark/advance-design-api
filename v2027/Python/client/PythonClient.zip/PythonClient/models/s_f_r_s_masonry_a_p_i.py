from enum import Enum

class SFRSMasonry_API(str, Enum):
    DuctileShearWall = "DuctileShearWall",
    ModeratelyDuctileShearWall = "ModeratelyDuctileShearWall",
    ConventionalConstruction = "ConventionalConstruction",

