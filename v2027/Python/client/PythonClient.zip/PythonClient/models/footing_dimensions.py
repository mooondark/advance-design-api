from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class FootingDimensions(Parsable):
    """
    Describes the geometric dimensions of a footing (pad) for a punctual support.All distances are expressed in meters and oriented along the global axes.
    """
    # Overall plan dimension of the footing measured along the global X axis (m).Unit: m Default value : 1.0
    dimension_along_x: Optional[float] = None
    # Overall plan dimension of the footing measured along the global Y axis (m).Unit: m Default value : 1.0
    dimension_along_y: Optional[float] = None
    # Eccentricity of the resultant along the footing length direction (m). Positive = +Y.Unit: m Default value : 0.0
    eccentricity_along_length: Optional[float] = None
    # Eccentricity of the resultant along the footing width direction (m). Positive = +X.Unit: m Default value : 0.0
    eccentricity_along_width: Optional[float] = None
    # Thickness/height of the footing along the global Z axis (m).Unit: m Default value : 0.3
    height: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FootingDimensions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FootingDimensions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return FootingDimensions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "dimensionAlongX": lambda n : setattr(self, 'dimension_along_x', n.get_float_value()),
            "dimensionAlongY": lambda n : setattr(self, 'dimension_along_y', n.get_float_value()),
            "eccentricityAlongLength": lambda n : setattr(self, 'eccentricity_along_length', n.get_float_value()),
            "eccentricityAlongWidth": lambda n : setattr(self, 'eccentricity_along_width', n.get_float_value()),
            "height": lambda n : setattr(self, 'height', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("dimensionAlongX", self.dimension_along_x)
        writer.write_float_value("dimensionAlongY", self.dimension_along_y)
        writer.write_float_value("eccentricityAlongLength", self.eccentricity_along_length)
        writer.write_float_value("eccentricityAlongWidth", self.eccentricity_along_width)
        writer.write_float_value("height", self.height)
    

