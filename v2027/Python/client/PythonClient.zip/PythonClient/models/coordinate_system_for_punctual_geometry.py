from enum import Enum

class CoordinateSystemForPunctualGeometry(str, Enum):
    Global_or_user = "global_or_user",
    Local_frame = "local_frame",

