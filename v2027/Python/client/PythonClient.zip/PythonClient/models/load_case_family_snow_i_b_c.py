from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .building2_d_snow_a_s_c_e722 import Building2DSnowASCE722
    from .implantation_snow_a_s_c_e722 import ImplantationSnowASCE722
    from .load_case_family_snow import LoadCaseFamily_Snow
    from .snow_load_category_a_p_i import SnowLoadCategory_API

from .load_case_family_snow import LoadCaseFamily_Snow

@dataclass
class LoadCaseFamily_SnowIBC(LoadCaseFamily_Snow, AdditionalDataHolder, Parsable):
    """
    Snow loads case family for ASCE 7-22 / IBC, load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # 2D Building parameters (length, portal position)
    building2_d: Optional[Building2DSnowASCE722] = None
    # Implantation parameters (snow zone, terrain, exposure)
    implantation: Optional[ImplantationSnowASCE722] = None
    # Snow load categoryUnit: -Default: null
    snow_load_category: Optional[SnowLoadCategory_API] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_SnowIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_SnowIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamily_SnowIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .building2_d_snow_a_s_c_e722 import Building2DSnowASCE722
        from .implantation_snow_a_s_c_e722 import ImplantationSnowASCE722
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        from .building2_d_snow_a_s_c_e722 import Building2DSnowASCE722
        from .implantation_snow_a_s_c_e722 import ImplantationSnowASCE722
        from .load_case_family_snow import LoadCaseFamily_Snow
        from .snow_load_category_a_p_i import SnowLoadCategory_API

        fields: dict[str, Callable[[Any], None]] = {
            "building2D": lambda n : setattr(self, 'building2_d', n.get_object_value(Building2DSnowASCE722)),
            "implantation": lambda n : setattr(self, 'implantation', n.get_object_value(ImplantationSnowASCE722)),
            "snowLoadCategory": lambda n : setattr(self, 'snow_load_category', n.get_enum_value(SnowLoadCategory_API)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("building2D", self.building2_d)
        writer.write_object_value("implantation", self.implantation)
        writer.write_enum_value("snowLoadCategory", self.snow_load_category)
        writer.write_additional_data_value(self.additional_data)
    

