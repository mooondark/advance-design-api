from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ResponseCoefficientsParameters_Wind_EN1991_1_4(Parsable):
    """
    Response coefficients parameters for Wind EN 1991-1-4
    """
    # Adjustment factor Fw (for greenhouses)Unit: -Default: 1.0
    adjustment_factor_fw: Optional[float] = None
    # Exposure factor Ce(z)Unit: -Default: 1.0
    exposure_factor_ce_z: Optional[float] = None
    # Peak velocity pressure qp(z)Unit: PaDefault: 1.0
    peak_velocity_pressure_qp_z: Optional[float] = None
    # Rig factorUnit: -Default: 1.0
    rig_factor: Optional[float] = None
    # Turbulence intensityUnit: -Default: 1.0
    turbulence_intensity: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResponseCoefficientsParameters_Wind_EN1991_1_4:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResponseCoefficientsParameters_Wind_EN1991_1_4
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResponseCoefficientsParameters_Wind_EN1991_1_4()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "adjustmentFactorFw": lambda n : setattr(self, 'adjustment_factor_fw', n.get_float_value()),
            "exposureFactorCeZ": lambda n : setattr(self, 'exposure_factor_ce_z', n.get_float_value()),
            "peakVelocityPressureQpZ": lambda n : setattr(self, 'peak_velocity_pressure_qp_z', n.get_float_value()),
            "rigFactor": lambda n : setattr(self, 'rig_factor', n.get_float_value()),
            "turbulenceIntensity": lambda n : setattr(self, 'turbulence_intensity', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("adjustmentFactorFw", self.adjustment_factor_fw)
        writer.write_float_value("exposureFactorCeZ", self.exposure_factor_ce_z)
        writer.write_float_value("peakVelocityPressureQpZ", self.peak_velocity_pressure_qp_z)
        writer.write_float_value("rigFactor", self.rig_factor)
        writer.write_float_value("turbulenceIntensity", self.turbulence_intensity)
    

