from enum import Enum

class No_AutoYES_Imposed_Options(str, Enum):
    E_Option_No = "e_Option_No",
    E_Option_Auto = "e_Option_Auto",
    E_Option_UserImposed = "e_Option_UserImposed",

