from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .ductility_class_e_n1998_a_p_i import DuctilityClassEN1998_API
    from .importance_category_e_n1998_a_p_i import ImportanceCategoryEN1998_API

@dataclass
class StructureSeismicEN1998(Parsable):
    """
    Structure parameters for seismic EN 1998-1
    """
    from .ductility_class_e_n1998_a_p_i import DuctilityClassEN1998_API

    # Ductility class type (NTC 2008/2018 and some annexes)Values: 0=LOW, 1=MEDIUM, 2=HIGHDefault: MEDIUM (1)
    ductility_class: Optional[DuctilityClassEN1998_API] = DuctilityClassEN1998_API("MEDIUM")
    from .importance_category_e_n1998_a_p_i import ImportanceCategoryEN1998_API

    # Importance class and gamma_I coefficient (FR only)Values: CAT_I, CAT_II, CAT_III, CAT_IVDefault: CAT_II (1)
    importance_category: Optional[ImportanceCategoryEN1998_API] = ImportanceCategoryEN1998_API("CAT_II")
    # Lower bound factor betaUnit: dimensionlessDefault: 0.2 (BETA_LIMINF_EN_1998_1)
    coef_beta: Optional[float] = None
    # Importance factor gamma_IUnit: dimensionlessDefault: calculated based on importance category
    coef_gamma_i: Optional[float] = None
    # Behavior factor q for horizontal direction XUnit: dimensionlessDefault: 1.5
    coef_q_horiz: Optional[float] = None
    # Behavior factor q for horizontal direction YUnit: dimensionlessDefault: 1.5
    coef_q_horiz_y: Optional[float] = None
    # Behavior factor q for vertical directionUnit: dimensionlessDefault: 1.5
    coef_q_vert: Optional[float] = None
    # Apply correction (lower bound factor beta)Default: false
    correction: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> StructureSeismicEN1998:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: StructureSeismicEN1998
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return StructureSeismicEN1998()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .ductility_class_e_n1998_a_p_i import DuctilityClassEN1998_API
        from .importance_category_e_n1998_a_p_i import ImportanceCategoryEN1998_API

        from .ductility_class_e_n1998_a_p_i import DuctilityClassEN1998_API
        from .importance_category_e_n1998_a_p_i import ImportanceCategoryEN1998_API

        fields: dict[str, Callable[[Any], None]] = {
            "coefBeta": lambda n : setattr(self, 'coef_beta', n.get_float_value()),
            "coefGammaI": lambda n : setattr(self, 'coef_gamma_i', n.get_float_value()),
            "coefQHoriz": lambda n : setattr(self, 'coef_q_horiz', n.get_float_value()),
            "coefQHorizY": lambda n : setattr(self, 'coef_q_horiz_y', n.get_float_value()),
            "coefQVert": lambda n : setattr(self, 'coef_q_vert', n.get_float_value()),
            "correction": lambda n : setattr(self, 'correction', n.get_bool_value()),
            "ductilityClass": lambda n : setattr(self, 'ductility_class', n.get_enum_value(DuctilityClassEN1998_API)),
            "importanceCategory": lambda n : setattr(self, 'importance_category', n.get_enum_value(ImportanceCategoryEN1998_API)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("coefBeta", self.coef_beta)
        writer.write_float_value("coefGammaI", self.coef_gamma_i)
        writer.write_float_value("coefQHoriz", self.coef_q_horiz)
        writer.write_float_value("coefQHorizY", self.coef_q_horiz_y)
        writer.write_float_value("coefQVert", self.coef_q_vert)
        writer.write_bool_value("correction", self.correction)
        writer.write_enum_value("ductilityClass", self.ductility_class)
        writer.write_enum_value("importanceCategory", self.importance_category)
    

