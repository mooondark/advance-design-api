from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .clipping_calculation_type_a_p_i import ClippingCalculationType_API

@dataclass
class ClippingExtremity(Parsable):
    """
    Clipping extremity properties
    """
    from .clipping_calculation_type_a_p_i import ClippingCalculationType_API

    # Plan XYDefault value: ClippingCalculationType_API.clipping_auto
    plan_x_y: Optional[ClippingCalculationType_API] = ClippingCalculationType_API("clipping_auto")
    from .clipping_calculation_type_a_p_i import ClippingCalculationType_API

    # Plan XZDefault value: ClippingCalculationType_API.clipping_auto
    plan_x_z: Optional[ClippingCalculationType_API] = ClippingCalculationType_API("clipping_auto")
    # Value XYUnit: mDefault value: 0.25
    value_x_y: Optional[float] = None
    # Value XZUnit: mDefault value: 0.20
    value_x_z: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ClippingExtremity:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ClippingExtremity
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ClippingExtremity()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .clipping_calculation_type_a_p_i import ClippingCalculationType_API

        from .clipping_calculation_type_a_p_i import ClippingCalculationType_API

        fields: dict[str, Callable[[Any], None]] = {
            "planXY": lambda n : setattr(self, 'plan_x_y', n.get_enum_value(ClippingCalculationType_API)),
            "planXZ": lambda n : setattr(self, 'plan_x_z', n.get_enum_value(ClippingCalculationType_API)),
            "valueXY": lambda n : setattr(self, 'value_x_y', n.get_float_value()),
            "valueXZ": lambda n : setattr(self, 'value_x_z', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("planXY", self.plan_x_y)
        writer.write_enum_value("planXZ", self.plan_x_z)
        writer.write_float_value("valueXY", self.value_x_y)
        writer.write_float_value("valueXZ", self.value_x_z)
    

