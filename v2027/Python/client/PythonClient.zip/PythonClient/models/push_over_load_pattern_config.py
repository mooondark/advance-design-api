from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class PushOverLoadPatternConfig(Parsable):
    """
    Push over load pattern configuration
    """
    # Load distribution typeePushOverLoadConcentrated = 0, ePushOverLoadUniformDistributed = 1, ePushOverLoadTriangularDistributed = 2,  ePushOverLoadCodeDistributed = 3, ePushOverLoadModeShapeDistributed = 4Default: Concentrated (0)
    load_distribution: Optional[int] = None
    # Mode number for mode shape distributionDefault: 1
    mode_nb: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PushOverLoadPatternConfig:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PushOverLoadPatternConfig
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PushOverLoadPatternConfig()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "loadDistribution": lambda n : setattr(self, 'load_distribution', n.get_int_value()),
            "modeNb": lambda n : setattr(self, 'mode_nb', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("loadDistribution", self.load_distribution)
        writer.write_int_value("modeNb", self.mode_nb)
    

