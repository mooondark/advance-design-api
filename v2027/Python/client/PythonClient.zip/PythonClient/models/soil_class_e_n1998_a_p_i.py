from enum import Enum

class SoilClassEN1998_API(str, Enum):
    A = "A",
    B = "B",
    C = "C",
    D = "D",
    E = "E",

