from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .res_base import ResBase
    from .res_planar_node import ResPlanarNode
    from .res_planar_torsors import ResPlanarTorsors

from .res_base import ResBase

@dataclass
class ResElementPlanar(ResBase, AdditionalDataHolder, Parsable):
    """
    Represents a planar finite element within a structural analysis model.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Gets or sets the collection of resource nodes associated with this element.
    res_nodes: Optional[list[ResPlanarNode]] = None
    # Gets or sets the collection of planar torsor results.
    res_torsors: Optional[list[ResPlanarTorsors]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResElementPlanar:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResElementPlanar
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResElementPlanar()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .res_base import ResBase
        from .res_planar_node import ResPlanarNode
        from .res_planar_torsors import ResPlanarTorsors

        from .res_base import ResBase
        from .res_planar_node import ResPlanarNode
        from .res_planar_torsors import ResPlanarTorsors

        fields: dict[str, Callable[[Any], None]] = {
            "resNodes": lambda n : setattr(self, 'res_nodes', n.get_collection_of_object_values(ResPlanarNode)),
            "resTorsors": lambda n : setattr(self, 'res_torsors', n.get_collection_of_object_values(ResPlanarTorsors)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_collection_of_object_values("resNodes", self.res_nodes)
        writer.write_collection_of_object_values("resTorsors", self.res_torsors)
        writer.write_additional_data_value(self.additional_data)
    

