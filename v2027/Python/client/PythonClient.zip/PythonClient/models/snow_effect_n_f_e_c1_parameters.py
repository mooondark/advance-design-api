from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .loadings_case_type_snow import LoadingsCaseType_Snow

@dataclass
class SnowEffectNF_EC1Parameters(Parsable):
    """
    Effect-specific parameters for Snow EN 1991-1-3
    """
    from .loadings_case_type_snow import LoadingsCaseType_Snow

    # Type of loadings caseUnit: -Default: NORMAL_SNOW
    type_of_loadings_case: Optional[LoadingsCaseType_Snow] = LoadingsCaseType_Snow("NORMAL_SNOW")
    # Is automatic generationUnit: -Default: false
    is_automatic: Optional[bool] = None
    # Is updatedUnit: -Default: false
    is_updated: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SnowEffectNF_EC1Parameters:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SnowEffectNF_EC1Parameters
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SnowEffectNF_EC1Parameters()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .loadings_case_type_snow import LoadingsCaseType_Snow

        from .loadings_case_type_snow import LoadingsCaseType_Snow

        fields: dict[str, Callable[[Any], None]] = {
            "isAutomatic": lambda n : setattr(self, 'is_automatic', n.get_bool_value()),
            "isUpdated": lambda n : setattr(self, 'is_updated', n.get_bool_value()),
            "typeOfLoadingsCase": lambda n : setattr(self, 'type_of_loadings_case', n.get_enum_value(LoadingsCaseType_Snow)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("isAutomatic", self.is_automatic)
        writer.write_bool_value("isUpdated", self.is_updated)
        writer.write_enum_value("typeOfLoadingsCase", self.type_of_loadings_case)
    

