from enum import Enum

class ECombinationType(str, Enum):
    EComboProjectSituationEluStrgeo = "eComboProjectSituationEluStrgeo",
    EComboProjectSituationEluEqu = "eComboProjectSituationEluEqu",
    EComboProjectSituationElsCharacteristic = "eComboProjectSituationElsCharacteristic",
    EComboProjectSituationElsFrecvent = "eComboProjectSituationElsFrecvent",
    EComboProjectSituationElsQuasiPermanent = "eComboProjectSituationElsQuasiPermanent",
    EComboProjectSituationELUA = "eComboProjectSituationELUA",
    EComboProjectSituationElsA = "eComboProjectSituationElsA",
    EComboProjectSituationNone = "eComboProjectSituationNone",

