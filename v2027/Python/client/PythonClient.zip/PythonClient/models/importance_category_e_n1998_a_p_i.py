from enum import Enum

class ImportanceCategoryEN1998_API(str, Enum):
    CAT_I = "CAT_I",
    CAT_II = "CAT_II",
    CAT_III = "CAT_III",
    CAT_IV = "CAT_IV",

