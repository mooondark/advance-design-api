from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .calculation_method_e_n1998 import CalculationMethodEN1998
    from .implantation_seismic_e_n1998 import ImplantationSeismicEN1998
    from .load_case_family_seismic import LoadCaseFamily_Seismic
    from .structure_seismic_e_n1998 import StructureSeismicEN1998

from .load_case_family_seismic import LoadCaseFamily_Seismic

@dataclass
class LoadCaseFamily_SeismicEN_1998_1(LoadCaseFamily_Seismic, AdditionalDataHolder, Parsable):
    """
    Seismic EN 1998-1 loads case family, load case parent
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Implantation parameters (site location and seismic zone)
    implantation: Optional[ImplantationSeismicEN1998] = None
    # Calculation method configuration
    method: Optional[CalculationMethodEN1998] = None
    # Structure parameters (importance, behavior factors)
    structure: Optional[StructureSeismicEN1998] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseFamily_SeismicEN_1998_1:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseFamily_SeismicEN_1998_1
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseFamily_SeismicEN_1998_1()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .calculation_method_e_n1998 import CalculationMethodEN1998
        from .implantation_seismic_e_n1998 import ImplantationSeismicEN1998
        from .load_case_family_seismic import LoadCaseFamily_Seismic
        from .structure_seismic_e_n1998 import StructureSeismicEN1998

        from .calculation_method_e_n1998 import CalculationMethodEN1998
        from .implantation_seismic_e_n1998 import ImplantationSeismicEN1998
        from .load_case_family_seismic import LoadCaseFamily_Seismic
        from .structure_seismic_e_n1998 import StructureSeismicEN1998

        fields: dict[str, Callable[[Any], None]] = {
            "implantation": lambda n : setattr(self, 'implantation', n.get_object_value(ImplantationSeismicEN1998)),
            "method": lambda n : setattr(self, 'method', n.get_object_value(CalculationMethodEN1998)),
            "structure": lambda n : setattr(self, 'structure', n.get_object_value(StructureSeismicEN1998)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("implantation", self.implantation)
        writer.write_object_value("method", self.method)
        writer.write_object_value("structure", self.structure)
        writer.write_additional_data_value(self.additional_data)
    

