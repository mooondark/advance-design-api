from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .advanced_restraint_type import AdvancedRestraintType

@dataclass
class AdvancedRestraintsOptions(Parsable):
    """
    Advanced restraints options
    """
    from .advanced_restraint_type import AdvancedRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : AdvancedRestraintType.eFixed
    rx: Optional[AdvancedRestraintType] = AdvancedRestraintType("eFixed")
    from .advanced_restraint_type import AdvancedRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : AdvancedRestraintType.eFixed
    ry: Optional[AdvancedRestraintType] = AdvancedRestraintType("eFixed")
    from .advanced_restraint_type import AdvancedRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : AdvancedRestraintType.eFixed
    rz: Optional[AdvancedRestraintType] = AdvancedRestraintType("eFixed")
    from .advanced_restraint_type import AdvancedRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : AdvancedRestraintType.eFixed
    tx: Optional[AdvancedRestraintType] = AdvancedRestraintType("eFixed")
    from .advanced_restraint_type import AdvancedRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : AdvancedRestraintType.eFixed
    ty: Optional[AdvancedRestraintType] = AdvancedRestraintType("eFixed")
    from .advanced_restraint_type import AdvancedRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : AdvancedRestraintType.eFixed
    tz: Optional[AdvancedRestraintType] = AdvancedRestraintType("eFixed")
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AdvancedRestraintsOptions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AdvancedRestraintsOptions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AdvancedRestraintsOptions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .advanced_restraint_type import AdvancedRestraintType

        from .advanced_restraint_type import AdvancedRestraintType

        fields: dict[str, Callable[[Any], None]] = {
            "rx": lambda n : setattr(self, 'rx', n.get_enum_value(AdvancedRestraintType)),
            "ry": lambda n : setattr(self, 'ry', n.get_enum_value(AdvancedRestraintType)),
            "rz": lambda n : setattr(self, 'rz', n.get_enum_value(AdvancedRestraintType)),
            "tx": lambda n : setattr(self, 'tx', n.get_enum_value(AdvancedRestraintType)),
            "ty": lambda n : setattr(self, 'ty', n.get_enum_value(AdvancedRestraintType)),
            "tz": lambda n : setattr(self, 'tz', n.get_enum_value(AdvancedRestraintType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("rx", self.rx)
        writer.write_enum_value("ry", self.ry)
        writer.write_enum_value("rz", self.rz)
        writer.write_enum_value("tx", self.tx)
        writer.write_enum_value("ty", self.ty)
        writer.write_enum_value("tz", self.tz)
    

