from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class LoadCaseThermicCoefficients(Parsable):
    """
    Thermic load case coefficients for combinations
    """
    # Maximum coefficient for American / Canadian combinations.Unit: -Default: varies by code (0.5 for US, 0.6 for Canada)
    coeff_max: Optional[float] = None
    # Medium coefficient for American / Canadian combinations.Unit: -Default: varies by code (0.5 for US, 0.6 for Canada)
    coeff_med: Optional[float] = None
    # Minimum coefficient for American / Canadian combinations.Unit: -Default: varies by code (0.5 for US, 0.6 for Canada)
    coeff_min: Optional[float] = None
    # Thermic category: standard T (0) or thermic dead loads Td (1).Unit: -Default: 0
    thermic_category: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCaseThermicCoefficients:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCaseThermicCoefficients
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCaseThermicCoefficients()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "coeffMax": lambda n : setattr(self, 'coeff_max', n.get_float_value()),
            "coeffMed": lambda n : setattr(self, 'coeff_med', n.get_float_value()),
            "coeffMin": lambda n : setattr(self, 'coeff_min', n.get_float_value()),
            "thermicCategory": lambda n : setattr(self, 'thermic_category', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("coeffMax", self.coeff_max)
        writer.write_float_value("coeffMed", self.coeff_med)
        writer.write_float_value("coeffMin", self.coeff_min)
        writer.write_int_value("thermicCategory", self.thermic_category)
    

