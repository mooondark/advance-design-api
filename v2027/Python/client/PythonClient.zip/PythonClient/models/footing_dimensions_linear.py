from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class FootingDimensionsLinear(Parsable):
    """
    Describes the geometric dimensions of a footing (pad) for a punctual support.All distances are expressed in meters and oriented along the global axes.
    """
    # Overall plan dimension of the footing measured along the global X axis (m).Unit: m Default value : 1.0
    dimension_along_width_a: Optional[float] = None
    # Eccentricity of the resultant along the footing (m). Positive = +X.Unit: m Default value : 0.0
    eccentricity_along_width_e: Optional[float] = None
    # Thickness/height of the footing along the global Z axis (m).Unit: m Default value : 0.3
    height: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FootingDimensionsLinear:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FootingDimensionsLinear
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return FootingDimensionsLinear()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "dimensionAlong_Width_A": lambda n : setattr(self, 'dimension_along_width_a', n.get_float_value()),
            "eccentricityAlongWidth_e": lambda n : setattr(self, 'eccentricity_along_width_e', n.get_float_value()),
            "height": lambda n : setattr(self, 'height', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("dimensionAlong_Width_A", self.dimension_along_width_a)
        writer.write_float_value("eccentricityAlongWidth_e", self.eccentricity_along_width_e)
        writer.write_float_value("height", self.height)
    

