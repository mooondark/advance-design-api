from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .piles_restraint_type import PilesRestraintType

@dataclass
class PileRestraintsOptions(Parsable):
    """
    Pile restraints options
    """
    from .piles_restraint_type import PilesRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : PilesRestraintType.ePileSupportRestraintTypeFixed
    rx: Optional[PilesRestraintType] = PilesRestraintType("ePileSupportRestraintTypeFixed")
    from .piles_restraint_type import PilesRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : PilesRestraintType.ePileSupportRestraintTypeFixed
    ry: Optional[PilesRestraintType] = PilesRestraintType("ePileSupportRestraintTypeFixed")
    from .piles_restraint_type import PilesRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : PilesRestraintType.ePileSupportRestraintTypeFixed
    rz: Optional[PilesRestraintType] = PilesRestraintType("ePileSupportRestraintTypeFixed")
    from .piles_restraint_type import PilesRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : PilesRestraintType.ePileSupportRestraintTypeFixed
    tx: Optional[PilesRestraintType] = PilesRestraintType("ePileSupportRestraintTypeFixed")
    from .piles_restraint_type import PilesRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : PilesRestraintType.ePileSupportRestraintTypeFixed
    ty: Optional[PilesRestraintType] = PilesRestraintType("ePileSupportRestraintTypeFixed")
    from .piles_restraint_type import PilesRestraintType

    # The parameters for this type of support are defined separately for each direction by using the list.The list contains several predefined types: Free, Fixed, Elastic, NL– Active for Compression, NL– Active for Tension, NL– Gap (limit in distance), NL– Hardening (limit in force), NL– Diagram.Unit: no unit Default value : PilesRestraintType.ePileSupportRestraintTypeFixed
    tz: Optional[PilesRestraintType] = PilesRestraintType("ePileSupportRestraintTypeFixed")
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PileRestraintsOptions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PileRestraintsOptions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PileRestraintsOptions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .piles_restraint_type import PilesRestraintType

        from .piles_restraint_type import PilesRestraintType

        fields: dict[str, Callable[[Any], None]] = {
            "rx": lambda n : setattr(self, 'rx', n.get_enum_value(PilesRestraintType)),
            "ry": lambda n : setattr(self, 'ry', n.get_enum_value(PilesRestraintType)),
            "rz": lambda n : setattr(self, 'rz', n.get_enum_value(PilesRestraintType)),
            "tx": lambda n : setattr(self, 'tx', n.get_enum_value(PilesRestraintType)),
            "ty": lambda n : setattr(self, 'ty', n.get_enum_value(PilesRestraintType)),
            "tz": lambda n : setattr(self, 'tz', n.get_enum_value(PilesRestraintType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("rx", self.rx)
        writer.write_enum_value("ry", self.ry)
        writer.write_enum_value("rz", self.rz)
        writer.write_enum_value("tx", self.tx)
        writer.write_enum_value("ty", self.ty)
        writer.write_enum_value("tz", self.tz)
    

