from enum import Enum

class SiteClassIBC_API(str, Enum):
    A = "A",
    B = "B",
    C = "C",
    D = "D",
    E = "E",
    F = "F",

