from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .effect_parameters_wind_i_b_c import EffectParametersWindIBC
    from .load_case_wind import LoadCase_Wind

from .load_case_wind import LoadCase_Wind

@dataclass
class LoadCase_WindIBC(LoadCase_Wind, AdditionalDataHolder, Parsable):
    """
    Wind load case for IBC/ASCE 7-22
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Effect-specific parameters
    effect_parameters: Optional[EffectParametersWindIBC] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> LoadCase_WindIBC:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: LoadCase_WindIBC
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return LoadCase_WindIBC()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .effect_parameters_wind_i_b_c import EffectParametersWindIBC
        from .load_case_wind import LoadCase_Wind

        from .effect_parameters_wind_i_b_c import EffectParametersWindIBC
        from .load_case_wind import LoadCase_Wind

        fields: dict[str, Callable[[Any], None]] = {
            "effectParameters": lambda n : setattr(self, 'effect_parameters', n.get_object_value(EffectParametersWindIBC)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("effectParameters", self.effect_parameters)
        writer.write_additional_data_value(self.additional_data)
    

