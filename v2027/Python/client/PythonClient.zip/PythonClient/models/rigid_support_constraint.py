from enum import Enum

class RigidSupportConstraint(str, Enum):
    Fix = "fix",
    SupportHinge = "SupportHinge",
    Other = "other",

